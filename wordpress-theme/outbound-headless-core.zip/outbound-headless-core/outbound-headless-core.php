<?php
/**
 * Plugin Name: Outbound Holidays Headless Core
 * Plugin URI: https://outboundholidays.co.zw
 * Description: Powers the Headless CMS, content delivery REST API, Outbound CRM Studio, and enquiry outbox engine for Outbound Holidays.
 * Version: 1.2.0
 * Author: Outbound Holidays
 * Author URI: https://outboundholidays.co.zw
 * License: Proprietary
 * Text Domain: outbound-headless
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'OUTBOUND_PLUGIN_VERSION' ) ) {
    define( 'OUTBOUND_PLUGIN_VERSION', '1.3.0' );
}
if ( ! defined( 'OUTBOUND_PLUGIN_PATH' ) ) {
    define( 'OUTBOUND_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'OUTBOUND_CORE_DIR' ) ) {
    define( 'OUTBOUND_CORE_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'OUTBOUND_CORE_URL' ) ) {
    define( 'OUTBOUND_CORE_URL', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'OUTBOUND_CORE_VERSION' ) ) {
    define( 'OUTBOUND_CORE_VERSION', '1.3.0' );
}

/**
 * Automatically deactivate any duplicate/renamed Outbound plugin folders
 * so only one authoritative copy is active and class/function collisions never occur.
 */
add_action( 'admin_init', function() {
    if ( ! function_exists( 'get_option' ) || ! function_exists( 'deactivate_plugins' ) ) {
        return;
    }
    $self_basename  = plugin_basename( __FILE__ );
    $active_plugins = (array) get_option( 'active_plugins', [] );
    $to_deactivate  = [];
    foreach ( $active_plugins as $plugin_file ) {
        if ( $plugin_file === $self_basename ) {
            continue;
        }
        if (
            false !== strpos( $plugin_file, 'outbound-holidays-studio' ) ||
            false !== strpos( $plugin_file, 'outbound-headless-core' )
        ) {
            $to_deactivate[] = $plugin_file;
        }
    }
    if ( ! empty( $to_deactivate ) ) {
        deactivate_plugins( $to_deactivate, true );
    }
}, 1 );

/**
 * Load Outbound Holidays CRM Module
 */
require_once OUTBOUND_PLUGIN_PATH . 'includes/class-crm-database.php';
require_once OUTBOUND_PLUGIN_PATH . 'includes/class-crm-customers.php';
require_once OUTBOUND_PLUGIN_PATH . 'includes/class-crm-enquiries.php';
require_once OUTBOUND_PLUGIN_PATH . 'includes/class-crm-pipeline.php';
require_once OUTBOUND_PLUGIN_PATH . 'includes/class-crm-quotations.php';
require_once OUTBOUND_PLUGIN_PATH . 'includes/class-crm-bookings.php';
require_once OUTBOUND_PLUGIN_PATH . 'includes/class-crm-payments.php';
require_once OUTBOUND_PLUGIN_PATH . 'includes/class-crm-reports.php';
require_once OUTBOUND_PLUGIN_PATH . 'includes/class-crm-roles.php';
require_once OUTBOUND_PLUGIN_PATH . 'includes/class-crm-export.php';
require_once OUTBOUND_PLUGIN_PATH . 'includes/class-crm-admin.php';
require_once OUTBOUND_PLUGIN_PATH . 'includes/class-cms-studio.php';

Outbound_CRM_Database::init();
Outbound_CRM_Admin::init();
Outbound_CRM_Roles::init();
Outbound_CRM_Export::init();
Outbound_CMS_Studio::init();

register_activation_hook( __FILE__, function() {
    Outbound_CRM_Database::install();
    Outbound_CRM_Roles::setup_roles_and_caps();
} );

/**
 * 1. Register Custom Post Types & Taxonomies
 */
if ( ! function_exists( 'outbound_register_post_types' ) ) :
add_action( 'init', 'outbound_register_post_types' );
function outbound_register_post_types() {
    // 1.1 Accommodations
    register_post_type( 'accommodation', [
        'labels' => [
            'name'          => __( 'Accommodations', 'outbound-headless' ),
            'singular_name' => __( 'Accommodation', 'outbound-headless' ),
            'add_new_item'  => __( 'Add New Accommodation', 'outbound-headless' ),
            'edit_item'     => __( 'Edit Accommodation', 'outbound-headless' ),
        ],
        'public'       => true,
        'has_archive'  => true,
        'show_in_rest' => true,
        'menu_icon'    => 'dashicons-building',
        'supports'     => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ],
        'rewrite'      => [ 'slug' => 'accommodation' ],
    ] );

    // 1.2 Experiences / Things to do
    register_post_type( 'experience', [
        'labels' => [
            'name'          => __( 'Experiences', 'outbound-headless' ),
            'singular_name' => __( 'Experience', 'outbound-headless' ),
            'add_new_item'  => __( 'Add New Experience', 'outbound-headless' ),
            'edit_item'     => __( 'Edit Experience', 'outbound-headless' ),
        ],
        'public'       => true,
        'has_archive'  => true,
        'show_in_rest' => true,
        'menu_icon'    => 'dashicons-palmtree',
        'supports'     => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ],
        'rewrite'      => [ 'slug' => 'things-to-do' ],
    ] );

    // Experience Category Taxonomy
    register_taxonomy( 'experience_category', [ 'experience' ], [
        'labels' => [
            'name'          => __( 'Experience Categories', 'outbound-headless' ),
            'singular_name' => __( 'Experience Category', 'outbound-headless' ),
        ],
        'public'       => true,
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite'      => [ 'slug' => 'things-to-do/category' ],
    ] );

    // 1.3 Holiday Packages
    register_post_type( 'package', [
        'labels' => [
            'name'          => __( 'Holiday Packages', 'outbound-headless' ),
            'singular_name' => __( 'Holiday Package', 'outbound-headless' ),
            'add_new_item'  => __( 'Add New Package', 'outbound-headless' ),
            'edit_item'     => __( 'Edit Package', 'outbound-headless' ),
        ],
        'public'       => true,
        'has_archive'  => true,
        'show_in_rest' => true,
        'menu_icon'    => 'dashicons-tickets-alt',
        'supports'     => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ],
        'rewrite'      => [ 'slug' => 'packages' ],
    ] );

    // 1.4 Travel Guides
    register_post_type( 'guide_article', [
        'labels' => [
            'name'          => __( 'Travel Guides', 'outbound-headless' ),
            'singular_name' => __( 'Travel Guide', 'outbound-headless' ),
            'add_new_item'  => __( 'Add New Guide', 'outbound-headless' ),
            'edit_item'     => __( 'Edit Guide', 'outbound-headless' ),
        ],
        'public'       => true,
        'has_archive'  => true,
        'show_in_rest' => true,
        'menu_icon'    => 'dashicons-book-alt',
        'supports'     => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ],
        'rewrite'      => [ 'slug' => 'victoria-falls-guide' ],
    ] );

    // 1.5 Enquiries (Private inbox for incoming bookings/leads)
    register_post_type( 'enquiry', [
        'labels' => [
            'name'          => __( 'Enquiries & Leads', 'outbound-headless' ),
            'singular_name' => __( 'Enquiry', 'outbound-headless' ),
        ],
        'public'          => false,
        'show_ui'         => true,
        'show_in_menu'    => true,
        'menu_icon'       => 'dashicons-email-alt',
        'capability_type' => 'post',
        'capabilities'    => [ 'create_posts' => false ], // Created via REST API
        'map_meta_cap'    => true,
        'supports'        => [ 'title' ],
    ] );
}

/**
 * 2. Custom Admin Columns for Enquiries
 */
add_filter( 'manage_enquiry_posts_columns', 'outbound_enquiry_columns' );
function outbound_enquiry_columns( $columns ) {
    return [
        'cb'        => $columns['cb'],
        'title'     => __( 'Reference & Name', 'outbound-headless' ),
        'email'     => __( 'Email', 'outbound-headless' ),
        'phone'     => __( 'Phone', 'outbound-headless' ),
        'trip_summary' => __( 'Trip Details', 'outbound-headless' ),
        'status'    => __( 'Status', 'outbound-headless' ),
        'date'      => __( 'Date', 'outbound-headless' ),
    ];
}

add_action( 'manage_enquiry_posts_custom_column', 'outbound_enquiry_column_content', 10, 2 );
function outbound_enquiry_column_content( $column, $post_id ) {
    switch ( $column ) {
        case 'email':
            echo esc_html( get_post_meta( $post_id, '_outbound_email', true ) );
            break;
        case 'phone':
            echo esc_html( get_post_meta( $post_id, '_outbound_phone', true ) ?: '—' );
            break;
        case 'trip_summary':
            $trip = get_post_meta( $post_id, '_outbound_trip', true );
            if ( is_array( $trip ) ) {
                $nights = isset( $trip['nights'] ) ? $trip['nights'] . ' nights' : '';
                $guests = isset( $trip['adults'] ) ? $trip['adults'] . ' adults' : '';
                echo esc_html( trim( "$guests, $nights", ', ' ) );
            } else {
                echo '—';
            }
            break;
        case 'status':
            $status = get_post_meta( $post_id, '_outbound_status', true ) ?: 'new';
            $badge_color = $status === 'new' ? '#0284c7' : ( $status === 'contacted' ? '#16a34a' : '#64748b' );
            echo '<span style="background:' . esc_attr( $badge_color ) . ';color:#fff;padding:3px 8px;border-radius:12px;font-size:11px;font-weight:600;text-transform:uppercase;">' . esc_html( $status ) . '</span>';
            break;
    }
}

/**
 * 2.1 Enquiry Detail Meta Box
 */
add_action( 'add_meta_boxes', 'outbound_add_enquiry_metabox' );
function outbound_add_enquiry_metabox() {
    add_meta_box(
        'outbound_enquiry_details',
        __( 'Traveller & Trip Details', 'outbound-headless' ),
        'outbound_render_enquiry_metabox',
        'enquiry',
        'normal',
        'high'
    );
}

function outbound_render_enquiry_metabox( $post ) {
    $ref       = get_post_meta( $post->ID, '_outbound_reference', true );
    $name      = get_post_meta( $post->ID, '_outbound_name', true );
    $email     = get_post_meta( $post->ID, '_outbound_email', true );
    $phone     = get_post_meta( $post->ID, '_outbound_phone', true );
    $message   = get_post_meta( $post->ID, '_outbound_message', true );
    $trip      = get_post_meta( $post->ID, '_outbound_trip', true );
    $selection = get_post_meta( $post->ID, '_outbound_selection', true );
    $status    = get_post_meta( $post->ID, '_outbound_status', true ) ?: 'new';

    wp_nonce_field( 'outbound_save_enquiry_meta', 'outbound_enquiry_nonce' );
    ?>
    <table class="form-table">
        <tr>
            <th><strong>Reference:</strong></th>
            <td><code><?php echo esc_html( $ref ); ?></code></td>
        </tr>
        <tr>
            <th><strong>Status:</strong></th>
            <td>
                <select name="outbound_enquiry_status">
                    <option value="new" <?php selected( $status, 'new' ); ?>>New</option>
                    <option value="contacted" <?php selected( $status, 'contacted' ); ?>>Contacted</option>
                    <option value="confirmed" <?php selected( $status, 'confirmed' ); ?>>Confirmed</option>
                    <option value="closed" <?php selected( $status, 'closed' ); ?>>Closed</option>
                </select>
            </td>
        </tr>
        <tr>
            <th><strong>Traveller Name:</strong></th>
            <td><?php echo esc_html( $name ); ?></td>
        </tr>
        <tr>
            <th><strong>Contact Email:</strong></th>
            <td><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></td>
        </tr>
        <tr>
            <th><strong>Phone:</strong></th>
            <td>
                <?php if ( $phone ) : ?>
                    <a href="tel:<?php echo esc_attr( $phone ); ?>"><?php echo esc_html( $phone ); ?></a>
                    &nbsp;|&nbsp;
                    <a href="https://wa.me/<?php echo esc_attr( preg_replace( '/\D/', '', $phone ) ); ?>" target="_blank" style="color:#25D366;font-weight:600;">Message on WhatsApp</a>
                <?php else : ?>
                    <em>None provided</em>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <th><strong>Traveller Message / Notes:</strong></th>
            <td><div style="background:#f8fafc;padding:12px;border:1px solid #e2e8f0;border-radius:6px;"><?php echo nl2br( esc_html( $message ) ); ?></div></td>
        </tr>
        <?php if ( ! empty( $trip ) ) : ?>
        <tr>
            <th><strong>Trip Parameters:</strong></th>
            <td>
                <pre style="background:#f1f5f9;padding:12px;border-radius:6px;max-height:200px;overflow:auto;"><?php echo esc_html( wp_json_encode( $trip, JSON_PRETTY_PRINT ) ); ?></pre>
            </td>
        </tr>
        <?php endif; ?>
        <?php if ( ! empty( $selection ) ) : ?>
        <tr>
            <th><strong>Selection Snapshot:</strong></th>
            <td>
                <pre style="background:#f1f5f9;padding:12px;border-radius:6px;max-height:200px;overflow:auto;"><?php echo esc_html( wp_json_encode( $selection, JSON_PRETTY_PRINT ) ); ?></pre>
            </td>
        </tr>
        <?php endif; ?>
    </table>
    <?php
}

add_action( 'save_post_enquiry', 'outbound_save_enquiry_status' );
function outbound_save_enquiry_status( $post_id ) {
    if ( ! isset( $_POST['outbound_enquiry_nonce'] ) || ! wp_verify_nonce( $_POST['outbound_enquiry_nonce'], 'outbound_save_enquiry_meta' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( isset( $_POST['outbound_enquiry_status'] ) ) {
        update_post_meta( $post_id, '_outbound_status', sanitize_text_field( $_POST['outbound_enquiry_status'] ) );
    }
}

/**
 * 3. CORS Support for Headless Requests
 */
add_action( 'rest_api_init', function() {
    remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );
    add_filter( 'rest_pre_serve_request', function( $value ) {
        header( 'Access-Control-Allow-Origin: *' );
        header( 'Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE' );
        header( 'Access-Control-Allow-Headers: Authorization, Content-Type, Idempotency-Key, X-Requested-With' );
        header( 'Access-Control-Expose-Headers: ETag, Content-Length' );
        return $value;
    });
}, 15 );

/**
 * 4. Register Outbound REST API Endpoints
 */
add_action( 'rest_api_init', 'outbound_register_rest_routes' );
function outbound_register_rest_routes() {
    $namespace = 'outbound/v1';

    // 4.1 Content Snapshot: GET /wp-json/outbound/v1/content
    register_rest_route( $namespace, '/content', [
        'methods'             => 'GET',
        'callback'            => 'outbound_handle_get_content',
        'permission_callback' => '__return_true',
    ] );

    // 4.2 Enquiries: POST /wp-json/outbound/v1/enquiries
    register_rest_route( $namespace, '/enquiries', [
        'methods'             => [ 'POST', 'OPTIONS' ],
        'callback'            => 'outbound_handle_post_enquiry',
        'permission_callback' => '__return_true',
    ] );

    // 4.3 Newsletter: POST /wp-json/outbound/v1/newsletter
    register_rest_route( $namespace, '/newsletter', [
        'methods'             => [ 'POST', 'OPTIONS' ],
        'callback'            => 'outbound_handle_post_newsletter',
        'permission_callback' => '__return_true',
    ] );

    // 4.4 Automated Importer: POST /wp-json/outbound/v1/import-snapshot (Admin only)
    register_rest_route( $namespace, '/import-snapshot', [
        'methods'             => 'POST',
        'callback'            => 'outbound_handle_import_snapshot',
        'permission_callback' => function() {
            return current_user_can( 'manage_options' );
        },
    ] );

    // 4.5 Cache Rebuilder: POST /wp-json/outbound/v1/rebuild-cache (Admin only)
    register_rest_route( $namespace, '/rebuild-cache', [
        'methods'             => 'POST',
        'callback'            => 'outbound_handle_rebuild_cache',
        'permission_callback' => function() {
            return current_user_can( 'manage_options' );
        },
    ] );
}

/**
 * 4.1 Handler: GET /wp-json/outbound/v1/content
 */
function outbound_handle_get_content( WP_REST_Request $request ) {
    $force = $request->get_param( 'force' ) || $request->get_param( 'nocache' );
    $snapshot = class_exists( 'Outbound_CMS_Studio' )
        ? Outbound_CMS_Studio::get_live_snapshot()
        : get_option( 'outbound_snapshot_cache' );

    if ( ! $snapshot || ! is_array( $snapshot ) || empty( $snapshot['accommodations'] ) ) {
        $snapshot = outbound_compile_snapshot();
        update_option( 'outbound_snapshot_cache', $snapshot, false );
        update_option( 'outbound_cms_snapshot', $snapshot, false );
    }

    $etag = md5( wp_json_encode( $snapshot ) );
    if ( ! headers_sent() ) {
        header( 'ETag: "' . $etag . '"' );
        header( 'Cache-Control: no-cache, must-revalidate' );
    }

    $if_none_match = isset( $_SERVER['HTTP_IF_NONE_MATCH'] ) ? trim( $_SERVER['HTTP_IF_NONE_MATCH'], '"' ) : '';
    if ( $if_none_match === $etag && ! $force ) {
        status_header( 304 );
        exit;
    }

    $response = new WP_REST_Response( $snapshot, 200 );
    $response->header( 'ETag', '"' . $etag . '"' );
    $response->header( 'Cache-Control', 'no-cache, must-revalidate' );
    return $response;
}

/**
 * 4.2 Handler: POST /wp-json/outbound/v1/enquiries
 */
function outbound_handle_post_enquiry( WP_REST_Request $request ) {
    if ( $request->get_method() === 'OPTIONS' ) {
        return new WP_REST_Response( null, 204 );
    }

    $params   = $request->get_json_params();
    $raw_name = $params['name'] ?? ( $params['fullName'] ?? '' );
    if ( empty( $raw_name ) || empty( $params['email'] ) ) {
        return new WP_REST_Response( [ 'error' => 'Name and email are required.' ], 422 );
    }

    $name    = sanitize_text_field( $raw_name );
    $email   = sanitize_email( $params['email'] );
    $phone   = ! empty( $params['phone'] ) ? sanitize_text_field( $params['phone'] ) : '';
    $message = ! empty( $params['message'] ) ? sanitize_textarea_field( $params['message'] ) : '';
    $source  = ! empty( $params['source'] ) ? sanitize_text_field( $params['source'] ) : 'website';
    $trip    = ! empty( $params['trip'] ) && is_array( $params['trip'] ) ? $params['trip'] : [];

    // Reference: OH-YYYYMMDD-XXXX
    $ref_date  = current_time( 'Ymd' );
    $ref_rand  = strtoupper( wp_generate_password( 6, false ) );
    $reference = "OH-{$ref_date}-{$ref_rand}";

    // Create Enquiry Post in WordPress
    $post_id = wp_insert_post( [
        'post_title'   => "{$name} - {$reference}",
        'post_type'    => 'enquiry',
        'post_status'  => 'publish',
        'post_content' => $message,
    ] );

    if ( is_wp_error( $post_id ) ) {
        return new WP_REST_Response( [ 'error' => 'Unable to save enquiry. Please try again.' ], 500 );
    }

    update_post_meta( $post_id, '_outbound_reference', $reference );
    update_post_meta( $post_id, '_outbound_name', $name );
    update_post_meta( $post_id, '_outbound_email', $email );
    update_post_meta( $post_id, '_outbound_phone', $phone );
    update_post_meta( $post_id, '_outbound_message', $message );
    update_post_meta( $post_id, '_outbound_source', $source );
    update_post_meta( $post_id, '_outbound_trip', $trip );
    update_post_meta( $post_id, '_outbound_status', 'new' );

    // Bridge Enquiry directly into Outbound CRM Engine
    $crm_enquiry_payload = [
        'reference'        => $reference,
        'name'             => $name,
        'email'            => $email,
        'phone'            => $phone,
        'message'          => $message,
        'source'           => $source,
        'trip'             => $trip,
        'marketingConsent' => ! empty( $params['marketingConsent'] ),
    ];
    if ( class_exists( 'Outbound_CRM_Enquiries' ) ) {
        Outbound_CRM_Enquiries::create_from_enquiry( $crm_enquiry_payload );
    } elseif ( class_exists( 'Outbound_CRM_Data' ) ) {
        Outbound_CRM_Data::create_opportunity_from_enquiry( $crm_enquiry_payload );
    }

    // Send Team Email Notification
    $admin_email = get_option( 'outbound_notification_email', 'travel@outboundholidays.co.zw' );
    $team_subject = "New Victoria Falls Enquiry: [{$reference}] from {$name}";

    $team_body = "<h2>New Outbound Holidays Enquiry</h2>";
    $team_body .= "<p><strong>Reference:</strong> {$reference}<br>";
    $team_body .= "<strong>Traveller:</strong> {$name}<br>";
    $team_body .= "<strong>Email:</strong> <a href='mailto:{$email}'>{$email}</a><br>";
    $team_body .= "<strong>Phone:</strong> {$phone}</p>";
    $team_body .= "<h3>Trip Details</h3><pre>" . esc_html( wp_json_encode( $trip, JSON_PRETTY_PRINT ) ) . "</pre>";
    $team_body .= "<h3>Traveller Message</h3><p>" . nl2br( esc_html( $message ) ) . "</p>";

    $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
    wp_mail( $admin_email, $team_subject, $team_body, $headers );

    // Send Customer Acknowledgement
    $cust_subject = "We have received your Victoria Falls enquiry [{$reference}]";
    $cust_body  = "<div style='font-family:sans-serif;color:#1e293b;max-width:600px;margin:0 auto;line-height:1.6;'>";
    $cust_body .= "<h2 style='color:#1e3a8a;'>Warm Greetings from Victoria Falls, {$name}!</h2>";
    $cust_body .= "<p>Thank you for reaching out to Outbound Holidays. We have received your holiday enquiry under reference <strong>{$reference}</strong>.</p>";
    $cust_body .= "<p>Our local travel specialists are reviewing your preferences and will prepare a tailored itinerary and quotation within 24 hours.</p>";
    $cust_body .= "<p>If you need urgent assistance, feel free to reply to this email or message us on WhatsApp: <strong>+263 714 701 721</strong>.</p>";
    $cust_body .= "<p style='margin-top:24px;border-top:1px solid #e2e8f0;padding-top:16px;color:#64748b;font-size:13px;'>Outbound Holidays • Suite 4, Mosi-oa-Tunya Commercial Centre, Victoria Falls, Zimbabwe</p>";
    $cust_body .= "</div>";

    wp_mail( $email, $cust_subject, $cust_body, $headers );

    return new WP_REST_Response( [
        'saved'        => true,
        'reference'    => $reference,
        'customerName' => $name,
        'submittedAt'  => current_time( 'c' ),
        'status'       => 'queued',
    ], 200 );
}

/**
 * 4.3 Handler: POST /wp-json/outbound/v1/newsletter
 */
function outbound_handle_post_newsletter( WP_REST_Request $request ) {
    if ( $request->get_method() === 'OPTIONS' ) {
        return new WP_REST_Response( null, 204 );
    }

    $params = $request->get_json_params();
    if ( empty( $params['email'] ) ) {
        return new WP_REST_Response( [ 'error' => 'Email is required.' ], 422 );
    }

    $email = sanitize_email( $params['email'] );
    $subscribers = get_option( 'outbound_subscribers', [] );

    if ( ! in_array( $email, $subscribers, true ) ) {
        $subscribers[] = $email;
        update_option( 'outbound_subscribers', $subscribers, false );
    }

    return new WP_REST_Response( [
        'saved'  => true,
        'status' => 'subscribed',
    ], 200 );
}

/**
 * 4.4 Handler: POST /wp-json/outbound/v1/import-snapshot
 * Takes the JSON snapshot and updates all CPTs, meta, and options
 */
function outbound_handle_import_snapshot( WP_REST_Request $request ) {
    $snapshot = $request->get_json_params();
    if ( empty( $snapshot ) || ! is_array( $snapshot ) ) {
        return new WP_REST_Response( [ 'error' => 'Invalid snapshot payload.' ], 400 );
    }

    $counts = [
        'accommodations' => 0,
        'experiences'    => 0,
        'packages'       => 0,
        'guides'         => 0,
    ];

    // 1. Accommodations
    if ( ! empty( $snapshot['accommodations'] ) ) {
        foreach ( $snapshot['accommodations'] as $acc ) {
            $slug  = sanitize_title( $acc['slug'] ?? $acc['id'] );
            $title = sanitize_text_field( $acc['name'] );
            $post_id = outbound_upsert_post( 'accommodation', $slug, $title, $acc['shortDescription'] ?? '' );
            if ( $post_id ) {
                update_post_meta( $post_id, '_outbound_payload', $acc );
                $counts['accommodations']++;
            }
        }
    }

    // 2. Experiences
    if ( ! empty( $snapshot['experiences'] ) ) {
        foreach ( $snapshot['experiences'] as $exp ) {
            $slug  = sanitize_title( $exp['slug'] ?? $exp['id'] );
            $title = sanitize_text_field( $exp['title'] );
            $post_id = outbound_upsert_post( 'experience', $slug, $title, $exp['shortDescription'] ?? '' );
            if ( $post_id ) {
                update_post_meta( $post_id, '_outbound_payload', $exp );
                // Categories
                if ( ! empty( $exp['categories'] ) ) {
                    wp_set_object_terms( $post_id, $exp['categories'], 'experience_category' );
                }
                $counts['experiences']++;
            }
        }
    }

    // 3. Packages
    if ( ! empty( $snapshot['packages'] ) ) {
        foreach ( $snapshot['packages'] as $pkg ) {
            $slug  = sanitize_title( $pkg['slug'] ?? $pkg['id'] );
            $title = sanitize_text_field( $pkg['title'] );
            $post_id = outbound_upsert_post( 'package', $slug, $title, $pkg['description'] ?? '' );
            if ( $post_id ) {
                update_post_meta( $post_id, '_outbound_payload', $pkg );
                $counts['packages']++;
            }
        }
    }

    // 4. Guides
    if ( ! empty( $snapshot['guides'] ) ) {
        foreach ( $snapshot['guides'] as $guide ) {
            $slug  = sanitize_title( $guide['slug'] );
            $title = sanitize_text_field( $guide['title'] );
            $post_id = outbound_upsert_post( 'guide_article', $slug, $title, $guide['summary'] ?? '' );
            if ( $post_id ) {
                update_post_meta( $post_id, '_outbound_payload', $guide );
                $counts['guides']++;
            }
        }
    }

    // 5. Store other items in options
    if ( ! empty( $snapshot['albums'] ) ) {
        update_option( 'outbound_albums_data', $snapshot['albums'], false );
    }
    if ( ! empty( $snapshot['builderActivities'] ) ) {
        update_option( 'outbound_builder_activities', $snapshot['builderActivities'], false );
    }
    if ( ! empty( $snapshot['stayTiers'] ) ) {
        update_option( 'outbound_stay_tiers', $snapshot['stayTiers'], false );
    }
    if ( ! empty( $snapshot['site'] ) ) {
        update_option( 'outbound_site_data', $snapshot['site'], false );
    }

    // Save snapshot directly to cache
    update_option( 'outbound_snapshot_cache', $snapshot, false );

    return new WP_REST_Response( [
        'success'  => true,
        'message'  => 'Snapshot successfully imported into WordPress.',
        'imported' => $counts,
        'version'  => $snapshot['version'] ?? current_time( 'c' ),
    ], 200 );
}

/**
 * 4.5 Handler: POST /wp-json/outbound/v1/rebuild-cache
 */
function outbound_handle_rebuild_cache() {
    $snapshot = outbound_compile_snapshot();
    update_option( 'outbound_snapshot_cache', $snapshot, false );
    return new WP_REST_Response( [ 'success' => true, 'version' => $snapshot['version'] ], 200 );
}

/**
 * Helper: Upsert post by slug & post type
 */
function outbound_upsert_post( $post_type, $slug, $title, $content = '' ) {
    $existing = get_page_by_path( $slug, OBJECT, $post_type );
    $post_data = [
        'post_title'   => $title,
        'post_name'    => $slug,
        'post_type'    => $post_type,
        'post_status'  => 'publish',
        'post_content' => $content,
    ];

    if ( $existing ) {
        $post_data['ID'] = $existing->ID;
        return wp_update_post( $post_data );
    }
    return wp_insert_post( $post_data );
}

/**
 * Global accessor for Theme to get current cached Content Snapshot
 */
function outbound_get_cached_snapshot(): array {
    if ( class_exists( 'Outbound_CMS_Studio' ) ) {
        return Outbound_CMS_Studio::get_live_snapshot();
    }
    $snapshot = get_option( 'outbound_cms_snapshot' );
    if ( empty( $snapshot ) || ! is_array( $snapshot ) || empty( $snapshot['accommodations'] ) ) {
        $snapshot = get_option( 'outbound_snapshot_cache' );
    }
    if ( empty( $snapshot ) || ! is_array( $snapshot ) || empty( $snapshot['accommodations'] ) ) {
        $snapshot = outbound_compile_snapshot();
        update_option( 'outbound_snapshot_cache', $snapshot, false );
        update_option( 'outbound_cms_snapshot', $snapshot, false );
    }
    return $snapshot;
}

/**
 * Helper: Compile Live Snapshot from authoritative CMS snapshot, CPTs and options
 */
function outbound_compile_snapshot() {
    $cached = get_option( 'outbound_cms_snapshot' );
    if ( empty( $cached ) || ! is_array( $cached ) || empty( $cached['accommodations'] ) ) {
        $cached = get_option( 'outbound_snapshot_cache' );
    }
    if ( empty( $cached ) || ! is_array( $cached ) || empty( $cached['accommodations'] ) ) {
        // Load initial authoritative seed from published-content.json if cache is uninitialized
        $seed_file = OUTBOUND_PLUGIN_PATH . 'published-content.json';
        if ( ! file_exists( $seed_file ) && function_exists( 'get_template_directory' ) ) {
            $seed_file = get_template_directory() . '/published-content.json';
        }
        if ( file_exists( $seed_file ) ) {
            $seed = json_decode( (string) file_get_contents( $seed_file ), true );
            if ( is_array( $seed ) && ! empty( $seed['accommodations'] ) ) {
                $cached = $seed;
                update_option( 'outbound_snapshot_cache', $cached, false );
                update_option( 'outbound_cms_snapshot', $cached, false );
            }
        }
    }

    if ( ! empty( $cached ) && is_array( $cached ) ) {
        $cached['version'] = current_time( 'Y-m-d\TH:i:s.v\Z' );
        return $cached;
    }

    // Fallback template if cache not yet populated
    return [
        'version'           => current_time( 'c' ),
        'accommodations'    => [],
        'experiences'       => [],
        'packages'          => [],
        'guides'            => [],
        'albums'            => get_option( 'outbound_albums_data', [] ),
        'builderActivities' => get_option( 'outbound_builder_activities', [] ),
        'stayTiers'         => get_option( 'outbound_stay_tiers', [] ),
        'site'              => get_option( 'outbound_site_data', [
            'routeSeo'      => [],
            'editorial'     => [ 'strings' => [], 'structures' => [] ],
            'contact'       => [
                'whatsappNumber' => '263714701721',
                'displayNumber'  => '+263 714 701 721',
                'email'          => 'travel@outboundholidays.co.zw',
                'address'        => 'Suite 4, Mosi-oa-Tunya Commercial Centre, Victoria Falls, Zimbabwe',
                'hours'          => 'Mon - Sun: 7:30 AM - 7:00 PM (CAT)',
            ],
            'currencyRates' => [
                'USD' => [ 'symbol' => '$', 'rate' => 1 ],
                'EUR' => [ 'symbol' => '€', 'rate' => 0.92 ],
                'GBP' => [ 'symbol' => '£', 'rate' => 0.79 ],
                'ZAR' => [ 'symbol' => 'R', 'rate' => 18.5 ],
            ],
            'guideCategories' => [],
            'featured'        => [ 'accommodationIds' => [], 'experienceIds' => [], 'packageIds' => [] ],
            'legacy'          => [],
        ] ),
    ];
}

// Sync individual CPT post saves into authoritative CMS snapshot without wiping CMS edits
add_action( 'save_post', function( $post_id, $post = null ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( defined( 'OUTBOUND_CMS_SYNCING_CPTS' ) && OUTBOUND_CMS_SYNCING_CPTS ) return;
    $post_type = get_post_type( $post_id );
    if ( ! in_array( $post_type, [ 'accommodation', 'experience', 'package', 'guide_article' ], true ) ) {
        return;
    }
    $payload = get_post_meta( $post_id, '_outbound_payload', true );
    if ( ! is_array( $payload ) || empty( $payload ) ) {
        return;
    }
    $snapshot = get_option( 'outbound_cms_snapshot' );
    if ( ! is_array( $snapshot ) || empty( $snapshot ) ) {
        return;
    }
    $map = [
        'accommodation' => [ 'key' => 'accommodations', 'title_field' => 'name' ],
        'experience'    => [ 'key' => 'experiences',    'title_field' => 'title' ],
        'package'       => [ 'key' => 'packages',       'title_field' => 'title' ],
        'guide_article' => [ 'key' => 'guides',         'title_field' => 'title' ],
    ];
    $cfg = $map[ $post_type ];
    $p = $post ?: get_post( $post_id );
    if ( $p && $p->post_status === 'publish' ) {
        $payload[ $cfg['title_field'] ] = $p->post_title;
        $payload['slug'] = $p->post_name;
        $list = $snapshot[ $cfg['key'] ] ?? [];
        $found = false;
        foreach ( $list as $idx => $item ) {
            if ( ( $item['slug'] ?? '' ) === $p->post_name || ( $item['id'] ?? '' ) === ( $payload['id'] ?? '' ) ) {
                $list[ $idx ] = array_merge( $item, $payload );
                $found = true;
                break;
            }
        }
        if ( ! $found ) {
            $list[] = $payload;
        }
        $snapshot[ $cfg['key'] ] = $list;
        $snapshot['version'] = gmdate( 'Y-m-d\TH:i:s.v\Z' );
        update_option( 'outbound_cms_snapshot', $snapshot, false );
        update_option( 'outbound_snapshot_cache', $snapshot, false );
    }
}, 10, 2 );
endif;


