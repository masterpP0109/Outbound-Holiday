/**
 * Outbound Holidays — Visual Content Studio Admin Controller
 *
 * Powers all 14 Outbound CMS sections:
 *  - Expandable record cards
 *  - Instant record search & filtering
 *  - Reordering (Move Up / Move Down / Make Featured #1)
 *  - WordPress Media Library single & bulk image selectors
 *  - Multi-photo gallery management for Client Memories, Properties, Experiences, Packages, About, Boma & Bungee
 *  - Dynamic record creation & removal
 *  - Unsaved-change browser warnings
 */
(function ($) {
	'use strict';

	if (!$) {
		return;
	}

	/**
	 * Safely retrieve WordPress Media Library API (`window.wp.media`)
	 */
	function getWpMedia() {
		const win = /** @type {any} */ (window);
		return win.wp && typeof win.wp.media === 'function' ? win.wp.media : null;
	}

	let isDirty = false;

	function markDirty() {
		isDirty = true;
	}

	// Track unsaved changes across the main CMS form
	$(document).on('change input', '#outbound-cms-main-form input, #outbound-cms-main-form textarea, #outbound-cms-main-form select', function () {
		if ($(this).hasClass('cms-record-search')) return;
		markDirty();
	});

	$(document).on('submit', '#outbound-cms-main-form', function () {
		isDirty = false;
	});

	window.addEventListener('beforeunload', function (e) {
		if (!isDirty) return;
		e.preventDefault();
	});

	// 1. Accordion Toggle
	$(document).on('click', '.cms-accordion-header', function (e) {
		if ($(e.target).closest('button, a, input, select').length) {
			return;
		}
		$(this).closest('.cms-accordion-item').toggleClass('is-open');
	});

	// 2. Instant Search / Filter Bar
	$(document).on('input search', '.cms-record-search', function () {
		const query = ($(this).val() || '').toString().toLowerCase().trim();
		const targetSelector = $(this).data('target');
		if (!targetSelector) return;

		$(targetSelector).each(function () {
			const $el = $(this);
			const haystack = ($el.attr('data-search') || $el.text() || '').toLowerCase();
			if (!query || haystack.indexOf(query) !== -1) {
				$el.show();
			} else {
				$el.hide();
			}
		});
	});

	// 3. Reorder Up / Down & Make Featured (#1)
	function reindexContainer($container) {
		$container.children().each(function (newIdx) {
			$(this).find('input[name], textarea[name], select[name]').each(function () {
				const name = $(this).attr('name');
				if (!name) return;
				// Replace the first numeric index in brackets: prefix[12]... -> prefix[newIdx]...
				const updated = name.replace(/^([^[]+\[)\d+(\].*)$/, '$1' + newIdx + '$2');
				$(this).attr('name', updated);
			});
		});
		markDirty();
	}

	$(document).on('click', '.cms-move-up', function (e) {
		e.preventDefault();
		e.stopPropagation();
		const $item = $(this).closest('.cms-accordion-item, .cms-gallery-card, .cms-string-gallery-item, .cms-section-order-row, .cms-story-card, .cms-hero-slide-card');
		const $prev = $item.prev();
		if ($prev.length) {
			$item.insertBefore($prev);
			reindexContainer($item.parent());
		}
	});

	$(document).on('click', '.cms-move-down', function (e) {
		e.preventDefault();
		e.stopPropagation();
		const $item = $(this).closest('.cms-accordion-item, .cms-gallery-card, .cms-string-gallery-item, .cms-section-order-row, .cms-story-card, .cms-hero-slide-card');
		const $next = $item.next();
		if ($next.length) {
			$item.insertAfter($next);
			reindexContainer($item.parent());
		}
	});

	$(document).on('click', '.cms-make-featured-photo', function (e) {
		e.preventDefault();
		const $card = $(this).closest('.cms-gallery-card');
		const $parent = $card.parent();
		$parent.prepend($card);
		reindexContainer($parent);
	});

	// 4. Remove Card / Gallery Item
	$(document).on('click', '.cms-remove-card', function (e) {
		e.preventDefault();
		e.stopPropagation();
		if (!confirm('Remove this item? Click "Publish Changes" or "Save Draft" afterwards to persist.')) {
			return;
		}
		const $card = $(this).closest('.cms-accordion-item, .cms-story-card, .cms-hero-slide-card');
		const $parent = $card.parent();
		$card.remove();
		reindexContainer($parent);
	});

	$(document).on('click', '.cms-remove-gallery-img, .cms-remove-gallery-url', function (e) {
		e.preventDefault();
		const $card = $(this).closest('.cms-gallery-card, .cms-string-gallery-item');
		const $parent = $card.parent();
		$card.remove();
		reindexContainer($parent);
	});

	// 5. WP Media Library Picker for Standard Image Fields
	$(document).on('click', '.cms-pick-media', function (e) {
		e.preventDefault();
		const $picker = $(this).closest('.cms-media-picker');
		const $urlInput = $picker.find('.cms-media-url');
		const $preview = $picker.find('.cms-media-preview');

		const wpMedia = getWpMedia();
		if (!wpMedia) {
			alert('WordPress Media Library is not available.');
			return;
		}

		const frame = wpMedia({
			title: 'Select or Upload Image',
			button: { text: 'Use This Image' },
			multiple: false
		});

		frame.on('select', function () {
			const attachment = frame.state().get('selection').first().toJSON();
			$urlInput.val(attachment.url).trigger('change');
			if ($preview.length) {
				$preview.html('<img src="' + attachment.url + '" alt="">');
			}
		});

		frame.open();
	});

	$(document).on('change input', '.cms-media-url', function () {
		const url = ($(this).val() || '').toString().trim();
		const $picker = $(this).closest('.cms-media-picker');
		if ($picker.length && $picker.find('.cms-media-preview').length) {
			if (url) {
				$picker.find('.cms-media-preview').html('<img src="' + url + '" alt="">');
			} else {
				$picker.find('.cms-media-preview').html('<span class="cms-no-img">No image</span>');
			}
		}
		const $galleryCard = $(this).closest('.cms-gallery-card, .cms-string-gallery-item');
		if ($galleryCard.length && url) {
			$galleryCard.find('img').first().attr('src', url);
		}
	});

	// 6. Replace Photo in Gallery Card
	$(document).on('click', '.cms-pick-gallery-img, .cms-pick-single-gallery-url', function (e) {
		e.preventDefault();
		const $card = $(this).closest('.cms-gallery-card, .cms-string-gallery-item');
		const $urlInput = $card.find('.cms-media-url');

		const wpMedia = getWpMedia();
		if (!wpMedia) return;

		const frame = wpMedia({
			title: 'Replace Gallery Photograph',
			button: { text: 'Use Photograph' },
			multiple: false
		});

		frame.on('select', function () {
			const attachment = frame.state().get('selection').first().toJSON();
			$urlInput.val(attachment.url).trigger('change');
			$card.find('img').first().attr('src', attachment.url);
		});

		frame.open();
	});

	// 7. Add / Bulk Upload String-Array Gallery Photos (Experiences, Accommodations, Packages, Boma, Bungee)
	$(document).on('click', '.cms-add-string-gallery-photo', function (e) {
		e.preventDefault();
		const inputName = $(this).attr('data-input-name');
		const $grid = $(this).closest('.cms-field').find('.cms-string-gallery-grid');

		const appendUrlCard = function (url) {
			const html = `
				<div class="cms-string-gallery-item" style="background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:8px;">
					<img src="${url}" alt="" style="width:100%;height:105px;object-fit:cover;border-radius:6px;display:block;margin-bottom:6px;">
					<input type="text" name="${inputName}" value="${url}" class="cms-media-url" style="width:100%;font-size:11px;margin-bottom:6px;">
					<div style="display:flex;justify-content:space-between;gap:4px;">
						<button type="button" class="button button-small cms-pick-single-gallery-url">Replace</button>
						<button type="button" class="button button-small cms-move-up" title="Move Left">←</button>
						<button type="button" class="button button-small cms-move-down" title="Move Right">→</button>
						<button type="button" class="button-link-delete cms-remove-gallery-url">✕</button>
					</div>
				</div>`;
			$grid.append(html);
			markDirty();
		};

		const wpMedia = getWpMedia();
		if (wpMedia) {
			const frame = wpMedia({
				title: 'Select or Upload Gallery Photographs',
				button: { text: 'Add to Gallery' },
				multiple: true
			});
			frame.on('select', function () {
				const selection = frame.state().get('selection');
				selection.each(function (attachment) {
					const data = attachment.toJSON();
					appendUrlCard(data.url || '');
				});
			});
			frame.open();
		} else {
			appendUrlCard('');
		}
	});

	// 8. Add / Bulk Upload Photos to Client Memories Gallery
	$(document).on('click', '#cms-add-gallery-photo-btn', function (e) {
		e.preventDefault();
		const $grid = $('#cms-gallery-grid');

		const appendClientPhoto = function (url, alt, caption) {
			const idx = $grid.children().length;
			const html = `
				<div class="cms-gallery-card">
					<div class="cms-gallery-thumb"><img src="${url}" alt=""></div>
					<div class="cms-gallery-fields">
						<input type="hidden" name="gallery[${idx}][id]" value="photo-${Date.now()}-${idx}">
						<div class="cms-field"><label>Image URL</label><input type="text" name="gallery[${idx}][url]" value="${url}" class="cms-media-url"></div>
						<div class="cms-field"><label>Alt Text</label><input type="text" name="gallery[${idx}][alt]" value="${alt}"></div>
						<div class="cms-field"><label>Caption</label><input type="text" name="gallery[${idx}][caption]" value="${caption}"></div>
						<div class="cms-gallery-card-actions" style="display:flex;justify-content:space-between;align-items:center;gap:4px;">
							<button type="button" class="button button-small cms-pick-gallery-img">Replace</button>
							<div style="display:flex;gap:3px;">
								<button type="button" class="button button-small cms-make-featured-photo" title="Make Featured (#1)">★</button>
								<button type="button" class="button button-small cms-move-up">←</button>
								<button type="button" class="button button-small cms-move-down">→</button>
							</div>
							<button type="button" class="button-link-delete cms-remove-gallery-img">Remove</button>
						</div>
					</div>
				</div>`;
			$grid.prepend(html);
			reindexContainer($grid);
		};

		const wpMedia = getWpMedia();
		if (wpMedia) {
			const frame = wpMedia({
				title: 'Add Photographs to Client Memories Gallery',
				button: { text: 'Add to Gallery' },
				multiple: true
			});
			frame.on('select', function () {
				const selection = frame.state().get('selection');
				selection.each(function (attachment) {
					const data = attachment.toJSON();
					appendClientPhoto(data.url || '', data.alt || data.title || 'Outbound Holidays client memory', data.caption || '');
				});
			});
			frame.open();
		} else {
			appendClientPhoto('', 'Outbound Holidays client memory', '');
		}
	});

	// 9. Add Photo to About / Fungai Memories Gallery
	$(document).on('click', '#cms-add-fungai-photo-btn', function (e) {
		e.preventDefault();
		const $grid = $('#cms-fungai-gallery-grid');
		const appendFungaiPhoto = function (url, alt) {
			const idx = $grid.children().length;
			const html = `
				<div class="cms-gallery-card">
					<div class="cms-gallery-thumb"><img src="${url}" alt=""></div>
					<div class="cms-gallery-fields">
						<div class="cms-field"><label>Image URL</label><input type="text" name="fungai_memories[${idx}][src]" value="${url}" class="cms-media-url"></div>
						<div class="cms-field"><label>Alt Text / Caption</label><input type="text" name="fungai_memories[${idx}][alt]" value="${alt}"></div>
						<div class="cms-gallery-card-actions" style="display:flex;justify-content:space-between;align-items:center;">
							<button type="button" class="button button-small cms-pick-gallery-img">Replace</button>
							<div>
								<button type="button" class="button button-small cms-move-up">←</button>
								<button type="button" class="button button-small cms-move-down">→</button>
							</div>
							<button type="button" class="button-link-delete cms-remove-gallery-img">Remove</button>
						</div>
					</div>
				</div>`;
			$grid.prepend(html);
			reindexContainer($grid);
		};

		const wpMedia = getWpMedia();
		if (wpMedia) {
			const frame = wpMedia({
				title: 'Add Photograph to About Us Gallery',
				button: { text: 'Add Photo' },
				multiple: true
			});
			frame.on('select', function () {
				frame.state().get('selection').each(function (att) {
					const d = att.toJSON();
					appendFungaiPhoto(d.url || '', d.alt || d.title || 'Outbound Holidays memory');
				});
			});
			frame.open();
		} else {
			appendFungaiPhoto('', 'Outbound Holidays memory');
		}
	});

	// 10. Clone / Add Record Helpers for Hero Slides, Stays, Experiences, Packages, Stories, Reviews, Tiers & Activities
	function cloneFirstRecord(listSelector, defaultTitleFieldSelector, newTitleValue) {
		const $list = $(listSelector);
		const $first = $list.children().first();
		if (!$first.length) return;
		const $clone = $first.clone();
		$clone.addClass('is-open');
		if (defaultTitleFieldSelector && newTitleValue) {
			$clone.find(defaultTitleFieldSelector).first().val(newTitleValue);
		}
		// Generate fresh unique ID if hidden ID input exists
		$clone.find('input[type="hidden"][name$="[id]"]').val('item-' + Date.now());
		$list.prepend($clone);
		reindexContainer($list);
	}

	$(document).on('click', '#cms-add-hero-slide-btn', function (e) {
		e.preventDefault();
		cloneFirstRecord('#cms-hero-slides-list', 'input[name$="[titleTag]"]', 'New Hero Slide');
	});

	$(document).on('click', '#cms-add-stay-btn', function (e) {
		e.preventDefault();
		cloneFirstRecord('#cms-stays-list', 'input[name$="[name]"]', 'New Victoria Falls Property');
	});

	$(document).on('click', '#cms-add-exp-btn', function (e) {
		e.preventDefault();
		cloneFirstRecord('#cms-experiences-list', 'input[name$="[title]"]', 'New Victoria Falls Experience');
	});

	$(document).on('click', '#cms-add-pkg-btn', function (e) {
		e.preventDefault();
		cloneFirstRecord('#cms-packages-list', 'input[name$="[title]"]', 'New Victoria Falls Package');
	});

	$(document).on('click', '#cms-add-story-btn', function (e) {
		e.preventDefault();
		cloneFirstRecord('#cms-stories-list', 'input[name$="[initials]"]', 'New Guest');
	});

	$(document).on('click', '#cms-add-review-btn', function (e) {
		e.preventDefault();
		cloneFirstRecord('#cms-reviews-list', 'input[name$="[author]"]', 'New Verified Guest');
	});

	$(document).on('click', '#cms-add-tier-btn', function (e) {
		e.preventDefault();
		cloneFirstRecord('#cms-tiers-list', 'input[name$="[name]"]', 'New Comfort Tier');
	});

	$(document).on('click', '#cms-add-bact-btn', function (e) {
		e.preventDefault();
		cloneFirstRecord('#cms-bacts-list', 'input[name$="[title]"]', 'New Builder Activity');
	});

})(/** @type {any} */ (window).jQuery);
