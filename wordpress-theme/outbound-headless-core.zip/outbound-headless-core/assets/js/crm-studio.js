document.addEventListener('DOMContentLoaded', function () {
	// 1. Expand / Collapse Record Cards
	document.querySelectorAll('.crm-card-header').forEach(function (header) {
		header.addEventListener('click', function (e) {
			// Prevent toggling if clicking a direct button inside header
			var target = e.target instanceof Element ? e.target : null;
			if (target && (target.closest('a') || target.closest('button') || target.closest('select') || target.closest('input'))) {
				return;
			}
			var card = this.closest('.crm-record-card');
			if (card) {
				card.classList.toggle('expanded');
			}
		});
	});

	// 2. Expand All / Collapse All Utility
	var expandAllBtn = document.getElementById('crm-expand-all');
	if (expandAllBtn) {
		expandAllBtn.addEventListener('click', function () {
			var cards = document.querySelectorAll('.crm-record-card');
			var anyCollapsed = Array.from(cards).some(function (c) {
				return !c.classList.contains('expanded');
			});
			cards.forEach(function (c) {
				if (anyCollapsed) {
					c.classList.add('expanded');
				} else {
					c.classList.remove('expanded');
				}
			});
			this.textContent = anyCollapsed ? 'Collapse All' : 'Expand All';
		});
	}

	// 3. Client-Side Quick Search & Filtering
	var searchInput = document.getElementById('crm-record-search');
	if (searchInput instanceof HTMLInputElement) {
		searchInput.addEventListener('input', function () {
			var term = this.value.toLowerCase().trim();
			document.querySelectorAll('.crm-record-card').forEach(function (card) {
				if (!(card instanceof HTMLElement)) return;
				var text = (card.textContent || '').toLowerCase();
				if (text.indexOf(term) !== -1) {
					card.style.display = '';
				} else {
					card.style.display = 'none';
				}
			});
		});
	}
});
