=== Outbound Holidays Headless Core & CRM Studio ===
Contributors: masterpP0109, outboundholidays
Tags: travel, crm, headless, react, victoria falls
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 1.2.0
Requires PHP: 7.4
License: Proprietary

Powers the Outbound Holidays Victoria Falls website, React Headless API content delivery, and full-featured Customer Relationship Management (CRM) Studio.

== Description ==

Outbound Holidays Headless Core is the authoritative backend and operational CRM engine for Outbound Holidays (Victoria Falls, Zimbabwe).

### Features
* **Headless CMS Engine:** CPT management for Accommodations, Experiences, Holiday Packages, and Victoria Falls Travel Guides.
* **REST API Content Delivery:** `/wp-json/outbound/v1/content` delivering full website snapshots.
* **Outbound CRM Studio:** Branded administrative studio matching the Content Studio design with horizontal tab navigation, expandable record cards, and sticky Save Changes bar.
* **Full Customer Lifecycle Management:** Website Enquiry -> Customer Profile -> Opportunity -> Tailored Quotation -> Confirmed Booking -> Payment Ledger -> Post-trip Review.
* **Relational Database:** 8 custom tables with indexes for lightning-fast queries and reporting.
* **WhatsApp & Multi-Channel Communications:** Direct WhatsApp click-to-chat integration for travellers and Victoria Falls safari suppliers.
* **Financial Ledger & Margins:** Selling prices, contracted supplier costs, gross margins, and payment reconciliation.
* **Role-Based Access Control:** Pre-configured staff roles for Travel Advisors, Operations Coordinators, and Finance.

== Installation ==

1. Upload `outbound-headless-core.zip` via **Plugins > Add New > Upload Plugin** in your WordPress admin.
2. Activate the plugin.
3. Access **Outbound CRM** in the WordPress sidebar to manage enquiries, customers, pipeline, and bookings.
4. Access **Outbound Settings** to review API cache status and lead notification routing.

== Changelog ==

= 1.2.0 =
* Complete Outbound Holidays CRM Studio integration matching Content Studio design system.
* Expandable record cards, horizontal tabs, and real-time form change detection.
* Automated database schema provisioning and enquiry ingestion pipeline.
* Standalone modular class architecture in `includes/` and assets in `assets/`.
