<?php
/**
 * Outbound CRM Studio - Quotations & Proposals View
 * Expandable cards with structured quotation editor, inclusions, and WhatsApp proposal sharing
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
if ( ! isset( $quotes ) ) {
    $quotes = $wpdb->get_results( "
        SELECT q.*, c.first_name, c.last_name, c.email, c.phone, c.whatsapp, o.reference as opp_ref
        FROM {$wpdb->prefix}outbound_crm_quotations q
        LEFT JOIN {$wpdb->prefix}outbound_crm_customers c ON q.customer_id = c.id
        LEFT JOIN {$wpdb->prefix}outbound_crm_opportunities o ON q.opportunity_id = o.id
        ORDER BY q.id DESC
    ", ARRAY_A );
}
?>

<div class="crm-toolbar">
    <div class="crm-search-box">
        <span class="dashicons dashicons-search" style="color:#64748b;"></span>
        <input type="text" id="crm-record-search" placeholder="<?php esc_attr_e( 'Search quotes by number, guest name or email...', 'outbound-headless' ); ?>">
    </div>
    <div style="display:flex; gap:10px;">
        <button type="button" class="crm-btn crm-btn-secondary" id="crm-expand-all"><?php _e( 'Expand All', 'outbound-headless' ); ?></button>
        <button type="button" class="crm-btn crm-btn-primary" onclick="document.getElementById('new-quote-card').classList.toggle('expanded');">
            <span class="dashicons dashicons-plus-alt2"></span> <?php _e( 'New Quotation', 'outbound-headless' ); ?>
        </button>
    </div>
</div>

<!-- New Quotation Creation Card (Initially Collapsed) -->
<div class="crm-record-card" id="new-quote-card" style="margin-bottom:20px; border-style:dashed;">
    <div class="crm-card-header">
        <div class="crm-card-title-group">
            <span class="dashicons dashicons-plus" style="color:#0284c7;"></span>
            <h3><?php _e( 'Generate New Quotation / Proposal', 'outbound-headless' ); ?></h3>
        </div>
        <span class="dashicons dashicons-arrow-down-alt2 crm-toggle-icon"></span>
    </div>
    <div class="crm-card-body">
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <?php wp_nonce_field( 'outbound_crm_nonce' ); ?>
            <input type="hidden" name="action" value="outbound_crm_action">
            <input type="hidden" name="crm_action" value="create_quotation">

            <div class="crm-form-grid">
                <div class="crm-form-group">
                    <label><?php _e( 'Opportunity ID *', 'outbound-headless' ); ?></label>
                    <input type="number" name="opportunity_id" required placeholder="e.g. 1">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Package / Itinerary Title *', 'outbound-headless' ); ?></label>
                    <input type="text" name="item_desc" required value="Victoria Falls Safari & Adventure Package (4D/3N)">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Total Quotation Price ($ USD) *', 'outbound-headless' ); ?></label>
                    <input type="number" step="0.01" name="total" required value="1650.00">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Deposit Required ($ USD)', 'outbound-headless' ); ?></label>
                    <input type="number" step="0.01" name="deposit_required" value="495.00">
                </div>
            </div>

            <div class="crm-form-group" style="margin-bottom:16px;">
                <label><?php _e( 'Package Inclusions', 'outbound-headless' ); ?></label>
                <textarea name="inclusions" rows="2">Luxury Safari Lodge (3 Nights B&B), Airport transfers, Guided Rainforest Tour of Victoria Falls, Zambezi Sunset Cruise with snacks & open bar, BOMA Dinner & Drum Show.</textarea>
            </div>

            <div class="crm-form-group" style="margin-bottom:16px;">
                <label><?php _e( 'Package Exclusions', 'outbound-headless' ); ?></label>
                <textarea name="exclusions" rows="2">International flights, visa fees, travel insurance, personal gratuities.</textarea>
            </div>

            <div style="display:flex; justify-content:flex-end;">
                <button type="submit" class="crm-btn crm-btn-primary">
                    <span class="dashicons dashicons-saved"></span> <?php _e( 'Create & Dispatch Quotation', 'outbound-headless' ); ?>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Quotations List Stack -->
<div class="crm-card-stack">
    <?php if ( ! empty( $quotes ) ) : ?>
        <?php foreach ( $quotes as $q ) : 
            $wa_clean = preg_replace( '/[^0-9]/', '', $q['whatsapp'] ?: $q['phone'] );
        ?>
            <div class="crm-record-card" id="quote-card-<?php echo intval( $q['id'] ); ?>">
                <div class="crm-card-header">
                    <div class="crm-card-title-group">
                        <span class="dashicons dashicons-media-document" style="color:#0284c7;"></span>
                        <h3><?php echo esc_html( $q['quote_number'] ); ?> — <?php echo esc_html( trim( $q['first_name'] . ' ' . $q['last_name'] ) ); ?></h3>
                        <span class="crm-badge badge-<?php echo esc_attr( $q['status'] ); ?>">
                            <?php echo esc_html( ucfirst( $q['status'] ) ); ?>
                        </span>
                    </div>
                    <div class="crm-card-meta">
                        <span><strong>$<?php echo number_format( $q['total'], 2 ); ?></strong></span>
                        <span><?php printf( __( 'Valid until: %s', 'outbound-headless' ), esc_html( $q['valid_until'] ) ); ?></span>
                        <span class="dashicons dashicons-arrow-down-alt2 crm-toggle-icon"></span>
                    </div>
                </div>

                <div class="crm-card-body">
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <?php wp_nonce_field( 'outbound_crm_nonce' ); ?>
                        <input type="hidden" name="action" value="outbound_crm_action">
                        <input type="hidden" name="crm_action" value="save_quotation">
                        <input type="hidden" name="quote_id" value="<?php echo intval( $q['id'] ); ?>">

                        <div class="crm-form-grid">
                            <div class="crm-form-group">
                                <label><?php _e( 'Total Price ($ USD)', 'outbound-headless' ); ?></label>
                                <input type="number" step="0.01" name="total" value="<?php echo esc_attr( $q['total'] ); ?>" required>
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Deposit Required ($ USD)', 'outbound-headless' ); ?></label>
                                <input type="number" step="0.01" name="deposit_required" value="<?php echo esc_attr( $q['deposit_required'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Status', 'outbound-headless' ); ?></label>
                                <select name="status">
                                    <option value="draft" <?php selected( $q['status'], 'draft' ); ?>>Draft</option>
                                    <option value="sent" <?php selected( $q['status'], 'sent' ); ?>>Sent to Client</option>
                                    <option value="accepted" <?php selected( $q['status'], 'accepted' ); ?>>Accepted</option>
                                    <option value="expired" <?php selected( $q['status'], 'expired' ); ?>>Expired</option>
                                    <option value="declined" <?php selected( $q['status'], 'declined' ); ?>>Declined</option>
                                </select>
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Currency', 'outbound-headless' ); ?></label>
                                <input type="text" value="<?php echo esc_attr( $q['currency'] ?: 'USD' ); ?>" readonly style="background:#f1f5f9;">
                            </div>
                        </div>

                        <div class="crm-form-group" style="margin-bottom:16px;">
                            <label><?php _e( 'Inclusions', 'outbound-headless' ); ?></label>
                            <textarea name="inclusions" rows="3"><?php echo esc_textarea( $q['inclusions'] ); ?></textarea>
                        </div>

                        <div class="crm-form-group" style="margin-bottom:16px;">
                            <label><?php _e( 'Exclusions', 'outbound-headless' ); ?></label>
                            <textarea name="exclusions" rows="2"><?php echo esc_textarea( $q['exclusions'] ); ?></textarea>
                        </div>

                        <div class="crm-form-group" style="margin-bottom:18px;">
                            <label><?php _e( 'Terms & Payment Conditions', 'outbound-headless' ); ?></label>
                            <textarea name="terms" rows="2"><?php echo esc_textarea( $q['terms'] ); ?></textarea>
                        </div>

                        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid #e2e8f0; padding-top:16px;">
                            <div style="display:flex; gap:8px;">
                                <?php if ( ! empty( $wa_clean ) ) : 
                                    $msg = "Hi {$q['first_name']}, your Outbound Holidays proposal [{$q['quote_number']}] for Victoria Falls is ready! Total: \${$q['total']} USD. Let me know if you would like to proceed with reservation.";
                                ?>
                                    <a href="https://wa.me/<?php echo esc_attr( $wa_clean ); ?>?text=<?php echo urlencode( $msg ); ?>" target="_blank" class="crm-btn crm-btn-whatsapp">
                                        <span class="dashicons dashicons-format-chat"></span> <?php _e( 'WhatsApp Proposal', 'outbound-headless' ); ?>
                                    </a>
                                <?php endif; ?>
                                <a href="mailto:<?php echo esc_attr( $q['email'] ); ?>?subject=<?php echo urlencode( "Your Victoria Falls Proposal [{$q['quote_number']}]" ); ?>" class="crm-btn crm-btn-secondary">
                                    <span class="dashicons dashicons-email"></span> <?php _e( 'Email Proposal', 'outbound-headless' ); ?>
                                </a>
                            </div>

                            <div style="display:flex; gap:10px;">
                                <button type="submit" class="crm-btn crm-btn-primary">
                                    <span class="dashicons dashicons-saved"></span> <?php _e( 'Save Quotation', 'outbound-headless' ); ?>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else : ?>
        <div class="crm-record-card" style="padding:40px; text-align:center;">
            <p style="color:#64748b; font-size:15px; margin:0;"><?php _e( 'No quotations generated yet. Click "New Quotation" or generate one from any qualified lead.', 'outbound-headless' ); ?></p>
        </div>
    <?php endif; ?>
</div>
