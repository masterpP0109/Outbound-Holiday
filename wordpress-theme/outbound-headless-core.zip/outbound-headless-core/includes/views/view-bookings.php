<?php
/**
 * Outbound CRM Studio - Bookings & Operations View
 * Expandable cards with operational instructions, financial margins, and inline payment recording
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
if ( ! isset( $bookings ) ) {
    $bookings = $wpdb->get_results( "
        SELECT b.*, c.first_name, c.last_name, c.email, c.phone, c.whatsapp
        FROM {$wpdb->prefix}outbound_crm_bookings b
        LEFT JOIN {$wpdb->prefix}outbound_crm_customers c ON b.customer_id = c.id
        ORDER BY b.id DESC
    ", ARRAY_A );
}
?>

<div class="crm-toolbar">
    <div class="crm-search-box">
        <span class="dashicons dashicons-search" style="color:#64748b;"></span>
        <input type="text" id="crm-record-search" placeholder="<?php esc_attr_e( 'Search bookings by ref, guest name or email...', 'outbound-headless' ); ?>">
    </div>
    <div style="display:flex; gap:10px;">
        <button type="button" class="crm-btn crm-btn-secondary" id="crm-expand-all"><?php _e( 'Expand All', 'outbound-headless' ); ?></button>
    </div>
</div>

<div class="crm-card-stack">
    <?php if ( ! empty( $bookings ) ) : ?>
        <?php foreach ( $bookings as $b ) : 
            $wa_clean = preg_replace( '/[^0-9]/', '', $b['whatsapp'] ?: $b['phone'] );
        ?>
            <div class="crm-record-card" id="booking-card-<?php echo intval( $b['id'] ); ?>">
                <div class="crm-card-header">
                    <div class="crm-card-title-group">
                        <span class="dashicons dashicons-calendar-alt" style="color:#0284c7;"></span>
                        <h3><?php echo esc_html( $b['booking_ref'] ); ?> — <?php echo esc_html( trim( $b['first_name'] . ' ' . $b['last_name'] ) ); ?></h3>
                        <span class="crm-badge badge-<?php echo esc_attr( $b['payment_status'] ); ?>">
                            <?php echo esc_html( ucfirst( str_replace( '_', ' ', $b['payment_status'] ) ) ); ?>
                        </span>
                        <span class="crm-badge badge-<?php echo esc_attr( $b['status'] ); ?>">
                            <?php echo esc_html( ucfirst( $b['status'] ) ); ?>
                        </span>
                    </div>
                    <div class="crm-card-meta">
                        <span><strong>$<?php echo number_format( $b['total_selling_price'], 2 ); ?></strong></span>
                        <span style="color:#10b981;">Profit: $<?php echo number_format( $b['gross_profit'], 2 ); ?></span>
                        <span><?php echo esc_html( $b['arrival_date'] ?: 'TBD' ); ?></span>
                        <span class="dashicons dashicons-arrow-down-alt2 crm-toggle-icon"></span>
                    </div>
                </div>

                <div class="crm-card-body">
                    <!-- 1. Main Booking Update Form -->
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <?php wp_nonce_field( 'outbound_crm_nonce' ); ?>
                        <input type="hidden" name="action" value="outbound_crm_action">
                        <input type="hidden" name="crm_action" value="save_booking">
                        <input type="hidden" name="booking_id" value="<?php echo intval( $b['id'] ); ?>">

                        <div class="crm-form-grid">
                            <div class="crm-form-group">
                                <label><?php _e( 'Arrival Date', 'outbound-headless' ); ?></label>
                                <input type="date" name="arrival_date" value="<?php echo esc_attr( $b['arrival_date'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Departure Date', 'outbound-headless' ); ?></label>
                                <input type="date" name="departure_date" value="<?php echo esc_attr( $b['departure_date'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Adults', 'outbound-headless' ); ?></label>
                                <input type="number" name="adults" value="<?php echo intval( $b['adults'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Children', 'outbound-headless' ); ?></label>
                                <input type="number" name="children" value="<?php echo intval( $b['children'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Selling Price ($ USD)', 'outbound-headless' ); ?></label>
                                <input type="number" step="0.01" name="total_selling_price" value="<?php echo esc_attr( $b['total_selling_price'] ); ?>" required>
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Supplier Cost ($ USD)', 'outbound-headless' ); ?></label>
                                <input type="number" step="0.01" name="total_supplier_cost" value="<?php echo esc_attr( $b['total_supplier_cost'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Booking Status', 'outbound-headless' ); ?></label>
                                <select name="status">
                                    <option value="confirmed" <?php selected( $b['status'], 'confirmed' ); ?>>Confirmed</option>
                                    <option value="in_progress" <?php selected( $b['status'], 'in_progress' ); ?>>In-Resort / Travelling</option>
                                    <option value="completed" <?php selected( $b['status'], 'completed' ); ?>>Trip Completed</option>
                                    <option value="cancelled" <?php selected( $b['status'], 'cancelled' ); ?>>Cancelled</option>
                                </select>
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Payment Status', 'outbound-headless' ); ?></label>
                                <select name="payment_status">
                                    <option value="unpaid" <?php selected( $b['payment_status'], 'unpaid' ); ?>>Unpaid</option>
                                    <option value="deposit_paid" <?php selected( $b['payment_status'], 'deposit_paid' ); ?>>Deposit Paid</option>
                                    <option value="paid" <?php selected( $b['payment_status'], 'paid' ); ?>>Fully Paid</option>
                                    <option value="refunded" <?php selected( $b['payment_status'], 'refunded' ); ?>>Refunded</option>
                                </select>
                            </div>
                        </div>

                        <div class="crm-form-group" style="margin-bottom:18px;">
                            <label><?php _e( 'Operational Logistics, Flights & Guide Instructions', 'outbound-headless' ); ?></label>
                            <textarea name="operational_instructions" rows="3" placeholder="Flight numbers, airport driver paging info, dietary restrictions, room setup..."><?php echo esc_textarea( $b['operational_instructions'] ); ?></textarea>
                        </div>

                        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid #e2e8f0; padding-top:16px;">
                            <div style="display:flex; gap:8px;">
                                <?php if ( ! empty( $wa_clean ) ) : ?>
                                    <a href="https://wa.me/<?php echo esc_attr( $wa_clean ); ?>?text=<?php echo urlencode( "Hi {$b['first_name']}, here is your Outbound Holidays confirmation for Victoria Falls [{$b['booking_ref']}]. We are thrilled to host you!" ); ?>" target="_blank" class="crm-btn crm-btn-whatsapp">
                                        <span class="dashicons dashicons-format-chat"></span> <?php _e( 'WhatsApp Guest', 'outbound-headless' ); ?>
                                    </a>
                                <?php endif; ?>
                                <a href="mailto:<?php echo esc_attr( $b['email'] ); ?>?subject=<?php echo urlencode( "Outbound Holidays Booking Confirmation [{$b['booking_ref']}]" ); ?>" class="crm-btn crm-btn-secondary">
                                    <span class="dashicons dashicons-email"></span> <?php _e( 'Email Guest', 'outbound-headless' ); ?>
                                </a>
                            </div>

                            <div style="display:flex; gap:10px;">
                                <button type="submit" class="crm-btn crm-btn-primary">
                                    <span class="dashicons dashicons-saved"></span> <?php _e( 'Save Booking Details', 'outbound-headless' ); ?>
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- 2. Quick Inline Payment Recording Section -->
                    <div style="margin-top:20px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:16px;">
                        <h4 style="margin:0 0 10px 0; color:#0f172a; font-size:13px; text-transform:uppercase; letter-spacing:0.5px;">
                            <?php _e( 'Record Customer Payment Against This Booking', 'outbound-headless' ); ?>
                        </h4>
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex; gap:12px; align-items:flex-end; flex-wrap:wrap;">
                            <?php wp_nonce_field( 'outbound_crm_nonce' ); ?>
                            <input type="hidden" name="action" value="outbound_crm_action">
                            <input type="hidden" name="crm_action" value="record_payment">
                            <input type="hidden" name="booking_id" value="<?php echo intval( $b['id'] ); ?>">

                            <div style="flex:1; min-width:140px;">
                                <label style="font-size:11px; font-weight:700; color:#475569; display:block; margin-bottom:4px;"><?php _e( 'Payment Amount ($ USD)', 'outbound-headless' ); ?></label>
                                <input type="number" step="0.01" name="amount" required placeholder="0.00" style="width:100%; padding:6px 10px;">
                            </div>
                            <div style="flex:1; min-width:140px;">
                                <label style="font-size:11px; font-weight:700; color:#475569; display:block; margin-bottom:4px;"><?php _e( 'Payment Method', 'outbound-headless' ); ?></label>
                                <select name="payment_method" style="width:100%; padding:6px 10px;">
                                    <option value="bank_transfer">Bank Wire / Transfer</option>
                                    <option value="credit_card">Credit / Debit Card</option>
                                    <option value="cash">Cash in Resort</option>
                                    <option value="other">Other Gateway</option>
                                </select>
                            </div>
                            <div style="flex:1; min-width:160px;">
                                <label style="font-size:11px; font-weight:700; color:#475569; display:block; margin-bottom:4px;"><?php _e( 'Ref / Proof Notes', 'outbound-headless' ); ?></label>
                                <input type="text" name="payment_reference" placeholder="e.g. TXN-998231" style="width:100%; padding:6px 10px;">
                            </div>
                            <div>
                                <button type="submit" class="crm-btn crm-btn-primary" style="background:#10b981;">
                                    <span class="dashicons dashicons-money-alt"></span> <?php _e( 'Record Payment', 'outbound-headless' ); ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else : ?>
        <div class="crm-record-card" style="padding:40px; text-align:center;">
            <p style="color:#64748b; font-size:15px; margin:0;"><?php _e( 'No confirmed bookings recorded yet. Confirm an enquiry from the Leads tab to generate a booking.', 'outbound-headless' ); ?></p>
        </div>
    <?php endif; ?>
</div>
