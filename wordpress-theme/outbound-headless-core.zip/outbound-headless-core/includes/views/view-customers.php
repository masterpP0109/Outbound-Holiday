<?php
/**
 * Outbound CRM Studio - Customers Directory View
 * Expandable cards with complete customer profile, travel preferences, and linked records
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
$customers = $wpdb->get_results( "
    SELECT c.*, 
    (SELECT COUNT(*) FROM {$wpdb->prefix}outbound_crm_opportunities WHERE customer_id = c.id) as total_enquiries,
    (SELECT COUNT(*) FROM {$wpdb->prefix}outbound_crm_bookings WHERE customer_id = c.id AND status = 'confirmed') as total_bookings
    FROM {$wpdb->prefix}outbound_crm_customers c
    ORDER BY c.id DESC
", ARRAY_A );
?>

<div class="crm-toolbar">
    <div class="crm-search-box">
        <span class="dashicons dashicons-search" style="color:#64748b;"></span>
        <input type="text" id="crm-record-search" placeholder="<?php esc_attr_e( 'Search customers by name, email, phone or country...', 'outbound-headless' ); ?>">
    </div>
    <div style="display:flex; gap:10px;">
        <button type="button" class="crm-btn crm-btn-secondary" id="crm-expand-all"><?php _e( 'Expand All', 'outbound-headless' ); ?></button>
        <button type="button" class="crm-btn crm-btn-primary" onclick="document.getElementById('new-customer-card').classList.toggle('expanded');">
            <span class="dashicons dashicons-plus-alt2"></span> <?php _e( 'Add Customer', 'outbound-headless' ); ?>
        </button>
    </div>
</div>

<!-- New Customer Creation Card (Initially Collapsed) -->
<div class="crm-record-card" id="new-customer-card" style="margin-bottom:20px; border-style:dashed;">
    <div class="crm-card-header">
        <div class="crm-card-title-group">
            <span class="dashicons dashicons-plus" style="color:#0284c7;"></span>
            <h3><?php _e( 'Create New Traveller Profile', 'outbound-headless' ); ?></h3>
        </div>
        <span class="dashicons dashicons-arrow-down-alt2 crm-toggle-icon"></span>
    </div>
    <div class="crm-card-body">
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <?php wp_nonce_field( 'outbound_crm_nonce' ); ?>
            <input type="hidden" name="action" value="outbound_crm_action">
            <input type="hidden" name="crm_action" value="save_customer">
            <input type="hidden" name="customer_id" value="0">

            <div class="crm-form-grid">
                <div class="crm-form-group">
                    <label><?php _e( 'First Name *', 'outbound-headless' ); ?></label>
                    <input type="text" name="first_name" required placeholder="e.g. Michael">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Last Name', 'outbound-headless' ); ?></label>
                    <input type="text" name="last_name" placeholder="e.g. Davies">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Email Address *', 'outbound-headless' ); ?></label>
                    <input type="email" name="email" required placeholder="traveller@example.com">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'WhatsApp Number', 'outbound-headless' ); ?></label>
                    <input type="text" name="whatsapp" placeholder="+44 7700 900077">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Country of Residence', 'outbound-headless' ); ?></label>
                    <input type="text" name="country" placeholder="United Kingdom">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Customer Type', 'outbound-headless' ); ?></label>
                    <select name="customer_type">
                        <option value="individual">Individual</option>
                        <option value="couple">Couple</option>
                        <option value="family">Family</option>
                        <option value="group">Group</option>
                        <option value="corporate">Corporate</option>
                    </select>
                </div>
            </div>

            <div class="crm-form-group" style="margin-bottom:16px;">
                <label><?php _e( 'Internal Notes & Travel Preferences', 'outbound-headless' ); ?></label>
                <textarea name="notes" rows="3" placeholder="Dietary requirements, anniversary trip, preferred room setup..."></textarea>
            </div>

            <div style="display:flex; justify-content:flex-end; gap:10px;">
                <button type="submit" class="crm-btn crm-btn-primary"><?php _e( 'Save Customer Profile', 'outbound-headless' ); ?></button>
            </div>
        </form>
    </div>
</div>

<!-- Customer Records Stack -->
<div class="crm-card-stack">
    <?php if ( ! empty( $customers ) ) : ?>
        <?php foreach ( $customers as $c ) : 
            $wa_clean = preg_replace( '/[^0-9]/', '', $c['whatsapp'] ?: $c['phone'] );
        ?>
            <div class="crm-record-card" id="customer-card-<?php echo intval( $c['id'] ); ?>">
                <div class="crm-card-header">
                    <div class="crm-card-title-group">
                        <span class="dashicons dashicons-admin-users" style="color:#64748b;"></span>
                        <h3><?php echo esc_html( trim( $c['first_name'] . ' ' . $c['last_name'] ) ); ?></h3>
                        <span class="crm-badge badge-contacted"><?php echo esc_html( ucfirst( $c['customer_type'] ) ); ?></span>
                    </div>
                    <div class="crm-card-meta">
                        <span><span class="dashicons dashicons-email" style="font-size:16px;"></span> <?php echo esc_html( $c['email'] ); ?></span>
                        <span><span class="dashicons dashicons-location" style="font-size:16px;"></span> <?php echo esc_html( $c['country'] ?: 'Global' ); ?></span>
                        <span><strong><?php echo intval( $c['total_bookings'] ); ?></strong> Bookings</span>
                        <span class="dashicons dashicons-arrow-down-alt2 crm-toggle-icon"></span>
                    </div>
                </div>

                <div class="crm-card-body">
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <?php wp_nonce_field( 'outbound_crm_nonce' ); ?>
                        <input type="hidden" name="action" value="outbound_crm_action">
                        <input type="hidden" name="crm_action" value="save_customer">
                        <input type="hidden" name="customer_id" value="<?php echo intval( $c['id'] ); ?>">

                        <div class="crm-form-grid">
                            <div class="crm-form-group">
                                <label><?php _e( 'First Name', 'outbound-headless' ); ?></label>
                                <input type="text" name="first_name" value="<?php echo esc_attr( $c['first_name'] ); ?>" required>
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Last Name', 'outbound-headless' ); ?></label>
                                <input type="text" name="last_name" value="<?php echo esc_attr( $c['last_name'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Email', 'outbound-headless' ); ?></label>
                                <input type="email" name="email" value="<?php echo esc_attr( $c['email'] ); ?>" required>
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'WhatsApp / Phone', 'outbound-headless' ); ?></label>
                                <input type="text" name="whatsapp" value="<?php echo esc_attr( $c['whatsapp'] ?: $c['phone'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'City & Country', 'outbound-headless' ); ?></label>
                                <input type="text" name="country" value="<?php echo esc_attr( trim( $c['city'] . ', ' . $c['country'], ', ' ) ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Customer Type', 'outbound-headless' ); ?></label>
                                <select name="customer_type">
                                    <option value="individual" <?php selected( $c['customer_type'], 'individual' ); ?>>Individual</option>
                                    <option value="couple" <?php selected( $c['customer_type'], 'couple' ); ?>>Couple</option>
                                    <option value="family" <?php selected( $c['customer_type'], 'family' ); ?>>Family</option>
                                    <option value="group" <?php selected( $c['customer_type'], 'group' ); ?>>Group</option>
                                    <option value="corporate" <?php selected( $c['customer_type'], 'corporate' ); ?>>Corporate</option>
                                </select>
                            </div>
                        </div>

                        <div class="crm-form-group" style="margin-bottom:18px;">
                            <label><?php _e( 'Internal Notes, Preferences & History', 'outbound-headless' ); ?></label>
                            <textarea name="notes" rows="3"><?php echo esc_textarea( $c['notes'] ); ?></textarea>
                        </div>

                        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid #e2e8f0; padding-top:16px;">
                            <div>
                                <?php if ( ! empty( $wa_clean ) ) : ?>
                                    <a href="https://wa.me/<?php echo esc_attr( $wa_clean ); ?>?text=<?php echo urlencode( "Hi {$c['first_name']}, warm greetings from Outbound Holidays in Victoria Falls!" ); ?>" target="_blank" class="crm-btn crm-btn-whatsapp">
                                        <span class="dashicons dashicons-format-chat"></span> <?php _e( 'WhatsApp Chat', 'outbound-headless' ); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                            <div style="display:flex; gap:10px;">
                                <button type="submit" class="crm-btn crm-btn-primary">
                                    <span class="dashicons dashicons-saved"></span> <?php _e( 'Save Customer', 'outbound-headless' ); ?>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else : ?>
        <div class="crm-record-card" style="padding:40px; text-align:center;">
            <p style="color:#64748b; font-size:15px; margin:0;"><?php _e( 'No traveller profiles recorded yet. Click "Add Customer" to create your first profile.', 'outbound-headless' ); ?></p>
        </div>
    <?php endif; ?>
</div>
