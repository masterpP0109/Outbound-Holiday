<?php
/**
 * Outbound CRM Studio - Financial & Conversion Reports View
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! isset( $metrics ) ) {
    $metrics = Outbound_CRM_Data::get_dashboard_metrics();
}

$margin = $metrics['total_booking_val'] > 0 ? round( ( $metrics['total_gross_profit'] / $metrics['total_booking_val'] ) * 100, 1 ) : 0;
?>

<div class="crm-stats-grid">
    <div class="crm-stat-card primary">
        <span class="stat-label"><?php _e( 'Gross Revenue ($ USD)', 'outbound-headless' ); ?></span>
        <span class="stat-value">$<?php echo number_format( $metrics['total_booking_val'], 2 ); ?></span>
        <span class="stat-sub"><?php _e( 'All confirmed bookings to date', 'outbound-headless' ); ?></span>
    </div>
    <div class="crm-stat-card success">
        <span class="stat-label"><?php _e( 'Gross Profit ($ USD)', 'outbound-headless' ); ?></span>
        <span class="stat-value">$<?php echo number_format( $metrics['total_gross_profit'], 2 ); ?></span>
        <span class="stat-sub"><?php echo esc_html( $margin ); ?>% <?php _e( 'Gross margin', 'outbound-headless' ); ?></span>
    </div>
    <div class="crm-stat-card warning">
        <span class="stat-label"><?php _e( 'Conversion Rate', 'outbound-headless' ); ?></span>
        <span class="stat-value"><?php echo esc_html( $metrics['conversion_rate'] ); ?>%</span>
        <span class="stat-sub"><?php _e( 'Enquiry to Confirmed Booking', 'outbound-headless' ); ?></span>
    </div>
    <div class="crm-stat-card primary">
        <span class="stat-label"><?php _e( 'Collected Receipts', 'outbound-headless' ); ?></span>
        <span class="stat-value">$<?php echo number_format( $metrics['payments_received'], 2 ); ?></span>
        <span class="stat-sub"><?php printf( __( 'Outstanding: $%s', 'outbound-headless' ), number_format( $metrics['outstanding_bal'], 2 ) ); ?></span>
    </div>
</div>

<div class="crm-card">
    <h2><?php _e( 'Executive Operational Insights & Rules', 'outbound-headless' ); ?></h2>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:20px;">
        <div style="background:#f8fafc; padding:16px; border-radius:8px; border:1px solid #e2e8f0;">
            <h4 style="margin:0 0 8px 0; color:#0f172a; font-size:13px; font-weight:700;"><?php _e( 'Revenue Calculation', 'outbound-headless' ); ?></h4>
            <p style="margin:0; font-size:13px; color:#475569; line-height:1.6;">
                Calculated dynamically as the sum of <code>total_selling_price</code> for all bookings with status <code>confirmed</code>, <code>in_progress</code> or <code>completed</code>.
            </p>
        </div>
        <div style="background:#f8fafc; padding:16px; border-radius:8px; border:1px solid #e2e8f0;">
            <h4 style="margin:0 0 8px 0; color:#0f172a; font-size:13px; font-weight:700;"><?php _e( 'Profit Margin Calculation', 'outbound-headless' ); ?></h4>
            <p style="margin:0; font-size:13px; color:#475569; line-height:1.6;">
                Evaluated as <code>total_selling_price - total_supplier_cost</code>. Supplier rates reflect contracted STO pricing with Victoria Falls hoteliers and activity concessionaires.
            </p>
        </div>
        <div style="background:#f8fafc; padding:16px; border-radius:8px; border:1px solid #e2e8f0;">
            <h4 style="margin:0 0 8px 0; color:#0f172a; font-size:13px; font-weight:700;"><?php _e( 'Pipeline Conversion', 'outbound-headless' ); ?></h4>
            <p style="margin:0; font-size:13px; color:#475569; line-height:1.6;">
                The ratio of converted booking records divided by total initial enquiries submitted via the website holiday builder, contact forms or direct WhatsApp links.
            </p>
        </div>
    </div>
</div>
