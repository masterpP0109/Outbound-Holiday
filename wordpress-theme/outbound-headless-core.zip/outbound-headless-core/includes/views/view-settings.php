<?php
/**
 * Outbound CRM Studio - Settings, Roles & Backup Export View
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<!-- Export & Backup Card -->
<div class="crm-card">
    <h2><span class="dashicons dashicons-database-export" style="color:#0284c7;"></span> <?php _e( 'Data Export & Audit Backup', 'outbound-headless' ); ?></h2>
    <p style="color:#64748b; font-size:13px; margin:0 0 16px 0;">
        <?php _e( 'Download a complete JSON export of all CRM records, customer profiles, pipeline opportunities and payments for financial auditing or external backup.', 'outbound-headless' ); ?>
    </p>
    
    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <?php wp_nonce_field( 'outbound_crm_export_nonce' ); ?>
        <input type="hidden" name="action" value="outbound_crm_export">
        
        <div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap;">
            <select name="export_type" style="padding:8px 12px; font-size:13px; border:1px solid #cbd5e1; border-radius:6px; min-width:240px;">
                <option value="all">Full CRM Database (All 8 Tables)</option>
                <option value="customers">Customers Directory Only</option>
                <option value="opportunities">Enquiries & Pipeline Deals</option>
                <option value="quotations">Quotations & Proposals</option>
                <option value="bookings">Confirmed Bookings</option>
                <option value="payments">Financial Transactions Ledger</option>
                <option value="suppliers">Suppliers & Partners</option>
            </select>
            <button type="submit" class="crm-btn crm-btn-primary">
                <span class="dashicons dashicons-download"></span> <?php _e( 'Download Backup JSON', 'outbound-headless' ); ?>
            </button>
        </div>
    </form>
</div>

<!-- Role Permissions & Access Control Info -->
<div class="crm-card">
    <h2><span class="dashicons dashicons-shield" style="color:#0284c7;"></span> <?php _e( 'Configured Staff Roles & Permissions', 'outbound-headless' ); ?></h2>
    <table class="crm-table">
        <thead>
            <tr>
                <th><?php _e( 'Staff Role', 'outbound-headless' ); ?></th>
                <th><?php _e( 'Assigned Responsibilities', 'outbound-headless' ); ?></th>
                <th><?php _e( 'Granted Capabilities', 'outbound-headless' ); ?></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><strong>Administrator</strong></td>
                <td>Full agency oversight, financial access, data backups and system settings.</td>
                <td><code>outbound_crm_admin</code>, <code>outbound_crm_finance</code>, <code>outbound_crm_manage_ops</code>, <code>outbound_crm_manage_leads</code></td>
            </tr>
            <tr>
                <td><strong>Outbound Travel Advisor</strong></td>
                <td>Lead management, holiday planning, quotation creation and WhatsApp follow-ups.</td>
                <td><code>outbound_crm_view</code>, <code>outbound_crm_manage_leads</code></td>
            </tr>
            <tr>
                <td><strong>Operations Coordinator</strong></td>
                <td>Ground handling in Victoria Falls, hotel/tour operator confirmations, airport transfers.</td>
                <td><code>outbound_crm_view</code>, <code>outbound_crm_manage_ops</code></td>
            </tr>
            <tr>
                <td><strong>Finance & Accounts</strong></td>
                <td>Customer receipts reconciliation, supplier STO invoice settlement, profit reports.</td>
                <td><code>outbound_crm_view</code>, <code>outbound_crm_finance</code></td>
            </tr>
        </tbody>
    </table>
</div>

<!-- Relational Database Schema Status -->
<div class="crm-card">
    <h2><span class="dashicons dashicons-admin-generic" style="color:#0284c7;"></span> <?php _e( 'Relational Database Schema Status', 'outbound-headless' ); ?></h2>
    <?php
    global $wpdb;
    $tables = [
        $wpdb->prefix . 'outbound_crm_customers',
        $wpdb->prefix . 'outbound_crm_opportunities',
        $wpdb->prefix . 'outbound_crm_quotations',
        $wpdb->prefix . 'outbound_crm_bookings',
        $wpdb->prefix . 'outbound_crm_payments',
        $wpdb->prefix . 'outbound_crm_tasks',
        $wpdb->prefix . 'outbound_crm_suppliers',
        $wpdb->prefix . 'outbound_crm_logs',
    ];
    ?>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:12px;">
        <?php foreach ( $tables as $tbl ) : 
            $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $tbl ) ) === $tbl;
            $cnt = $exists ? intval( $wpdb->get_var( "SELECT COUNT(*) FROM `{$tbl}`" ) ) : 0;
        ?>
            <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:6px; padding:12px;">
                <div style="font-weight:700; font-size:12px; color:#0f172a; margin-bottom:4px;"><code><?php echo esc_html( $tbl ); ?></code></div>
                <div style="display:flex; justify-content:space-between; align-items:center; font-size:12px;">
                    <span style="color:#10b981; font-weight:600;"><span class="dashicons dashicons-yes"></span> Active</span>
                    <span style="color:#64748b;"><?php echo $cnt; ?> records</span>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
