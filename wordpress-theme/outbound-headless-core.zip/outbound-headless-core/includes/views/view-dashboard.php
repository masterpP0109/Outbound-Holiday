<?php
/**
 * Outbound CRM Studio - Overview Dashboard
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! isset( $metrics ) ) {
    $metrics = Outbound_CRM_Data::get_dashboard_metrics();
}
?>

<!-- Live Performance Metrics Cards -->
<div class="crm-stats-grid">
    <div class="crm-stat-card primary">
        <span class="stat-label"><?php _e( 'Total Enquiries', 'outbound-headless' ); ?></span>
        <span class="stat-value"><?php echo number_format( $metrics['total_enquiries'] ); ?></span>
        <span class="stat-sub"><?php printf( __( '%d New awaiting review', 'outbound-headless' ), $metrics['new_enquiries'] ); ?></span>
    </div>

    <div class="crm-stat-card warning">
        <span class="stat-label"><?php _e( 'Qualified Leads', 'outbound-headless' ); ?></span>
        <span class="stat-value"><?php echo number_format( $metrics['qualified_leads'] ); ?></span>
        <span class="stat-sub"><?php printf( __( '%d Quotes sent to clients', 'outbound-headless' ), $metrics['quotes_sent'] ); ?></span>
    </div>

    <div class="crm-stat-card success">
        <span class="stat-label"><?php _e( 'Confirmed Bookings', 'outbound-headless' ); ?></span>
        <span class="stat-value"><?php echo number_format( $metrics['confirmed_bookings'] ); ?></span>
        <span class="stat-sub"><?php printf( __( 'Conversion Rate: %s%%', 'outbound-headless' ), $metrics['conversion_rate'] ); ?></span>
    </div>

    <div class="crm-stat-card primary">
        <span class="stat-label"><?php _e( 'Total Booking Value', 'outbound-headless' ); ?></span>
        <span class="stat-value">$<?php echo number_format( $metrics['total_booking_val'], 2 ); ?></span>
        <span class="stat-sub"><?php printf( __( 'Gross Profit: $%s', 'outbound-headless' ), number_format( $metrics['total_gross_profit'], 2 ) ); ?></span>
    </div>

    <div class="crm-stat-card success">
        <span class="stat-label"><?php _e( 'Payments Received', 'outbound-headless' ); ?></span>
        <span class="stat-value">$<?php echo number_format( $metrics['payments_received'], 2 ); ?></span>
        <span class="stat-sub"><?php printf( __( 'Outstanding: $%s', 'outbound-headless' ), number_format( $metrics['outstanding_bal'], 2 ) ); ?></span>
    </div>

    <div class="crm-stat-card danger">
        <span class="stat-label"><?php _e( 'Follow-ups & Tasks', 'outbound-headless' ); ?></span>
        <span class="stat-value"><?php echo number_format( $metrics['tasks_due_today'] ); ?></span>
        <span class="stat-sub"><?php printf( __( '%d Overdue tasks', 'outbound-headless' ), $metrics['tasks_overdue'] ); ?></span>
    </div>
</div>

<!-- Active Travellers & Upcoming Arrivals -->
<div class="crm-card">
    <h2><?php _e( 'Victoria Falls Operations Status', 'outbound-headless' ); ?></h2>
    <div style="display:flex; gap:20px; flex-wrap:wrap;">
        <div style="flex:1; min-width:250px; background:#f8fafc; padding:18px; border-radius:8px; border:1px solid #e2e8f0;">
            <h3 style="margin:0 0 6px 0; color:#0f172a; font-size:14px; font-weight:700;"><?php _e( 'Active In-Resort Guests', 'outbound-headless' ); ?></h3>
            <p style="font-size:28px; font-weight:800; margin:0; color:#0284c7;"><?php echo intval( $metrics['active_travellers'] ); ?> <?php _e( 'parties', 'outbound-headless' ); ?></p>
            <small style="color:#64748b;"><?php _e( 'Currently in Victoria Falls / Zambezi', 'outbound-headless' ); ?></small>
        </div>
        <div style="flex:1; min-width:250px; background:#f8fafc; padding:18px; border-radius:8px; border:1px solid #e2e8f0;">
            <h3 style="margin:0 0 6px 0; color:#0f172a; font-size:14px; font-weight:700;"><?php _e( 'Upcoming Arrivals', 'outbound-headless' ); ?></h3>
            <p style="font-size:28px; font-weight:800; margin:0; color:#10b981;"><?php echo intval( $metrics['upcoming_arrivals'] ); ?> <?php _e( 'parties', 'outbound-headless' ); ?></p>
            <small style="color:#64748b;"><?php _e( 'Scheduled arrivals in next 30 days', 'outbound-headless' ); ?></small>
        </div>
        <div style="flex:1; min-width:250px; background:#f8fafc; padding:18px; border-radius:8px; border:1px solid #e2e8f0;">
            <h3 style="margin:0 0 6px 0; color:#0f172a; font-size:14px; font-weight:700;"><?php _e( 'Completed Safaris & Tours', 'outbound-headless' ); ?></h3>
            <p style="font-size:28px; font-weight:800; margin:0; color:#64748b;"><?php echo intval( $metrics['completed_trips'] ); ?> <?php _e( 'holidays', 'outbound-headless' ); ?></p>
            <small style="color:#64748b;"><?php _e( 'Post-trip review follow-ups eligible', 'outbound-headless' ); ?></small>
        </div>
    </div>
</div>

<!-- Enquiry Sources Breakdown -->
<div class="crm-card">
    <h2><?php _e( 'Enquiry Acquisition Channels', 'outbound-headless' ); ?></h2>
    <table class="crm-table">
        <thead>
            <tr>
                <th><?php _e( 'Source Channel', 'outbound-headless' ); ?></th>
                <th><?php _e( 'Total Enquiries', 'outbound-headless' ); ?></th>
                <th><?php _e( 'Channel Share', 'outbound-headless' ); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if ( ! empty( $metrics['lead_sources'] ) ) : ?>
                <?php foreach ( $metrics['lead_sources'] as $src ) : 
                    $pct = $metrics['total_enquiries'] > 0 ? round( ( $src['count'] / $metrics['total_enquiries'] ) * 100, 1 ) : 0;
                ?>
                    <tr>
                        <td><strong><?php echo esc_html( ucfirst( str_replace( '_', ' ', $src['lead_source'] ) ) ); ?></strong></td>
                        <td><?php echo intval( $src['count'] ); ?></td>
                        <td>
                            <div style="display:flex; align-items:center; gap:8px;">
                                <div style="flex:1; height:8px; background:#e2e8f0; border-radius:4px; max-width:200px;">
                                    <div style="height:100%; width:<?php echo $pct; ?>%; background:#0284c7; border-radius:4px;"></div>
                                </div>
                                <span><?php echo $pct; ?>%</span>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr><td colspan="3" style="text-align:center; color:#64748b; padding:24px;"><?php _e( 'No enquiry sources recorded yet.', 'outbound-headless' ); ?></td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
