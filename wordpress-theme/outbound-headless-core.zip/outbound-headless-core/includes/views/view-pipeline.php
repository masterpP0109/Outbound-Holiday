<?php
/**
 * Outbound CRM Studio - Sales Pipeline (Kanban Board)
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
if ( ! isset( $opps ) ) {
    $opps = $wpdb->get_results( "
        SELECT o.*, c.first_name, c.last_name, c.phone, c.whatsapp 
        FROM {$wpdb->prefix}outbound_crm_opportunities o
        LEFT JOIN {$wpdb->prefix}outbound_crm_customers c ON o.customer_id = c.id
        ORDER BY o.id DESC
    ", ARRAY_A );
}

$stages = [
    'new'        => __( 'New Enquiry', 'outbound-headless' ),
    'contacted'  => __( 'Contacted', 'outbound-headless' ),
    'qualified'  => __( 'Qualified', 'outbound-headless' ),
    'planning'   => __( 'Preparing Quote', 'outbound-headless' ),
    'quote_sent' => __( 'Quotation Sent', 'outbound-headless' ),
    'confirmed'  => __( 'Confirmed Booking', 'outbound-headless' ),
    'lost'       => __( 'Lost / Closed', 'outbound-headless' ),
];

$grouped = [];
foreach ( array_keys( $stages ) as $s ) {
    $grouped[$s] = [];
}
foreach ( $opps as $o ) {
    $st = $o['stage'] ?: 'new';
    if ( isset( $grouped[$st] ) ) {
        $grouped[$st][] = $o;
    } else {
        $grouped['new'][] = $o;
    }
}
?>

<div class="crm-toolbar">
    <div style="font-size:14px; font-weight:700; color:#0f172a;">
        <?php printf( __( 'Active Pipeline: %d Opportunities across %d Stages', 'outbound-headless' ), count( $opps ), count( $stages ) ); ?>
    </div>
    <div style="display:flex; gap:10px;">
        <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'outbound-crm', 'tab' => 'leads' ], admin_url( 'admin.php' ) ) ); ?>" class="crm-btn crm-btn-secondary">
            <span class="dashicons dashicons-list-view"></span> <?php _e( 'Card View (All Details)', 'outbound-headless' ); ?>
        </a>
    </div>
</div>

<div class="crm-kanban-board">
    <?php foreach ( $stages as $stage_key => $stage_label ) : 
        $stage_opps = $grouped[$stage_key] ?? [];
        $stage_sum  = array_sum( array_column( $stage_opps, 'value' ) );
    ?>
        <div class="kanban-col">
            <div class="kanban-col-header">
                <span><?php echo esc_html( $stage_label ); ?> (<?php echo count( $stage_opps ); ?>)</span>
                <span style="color:#0284c7; font-weight:800;">$<?php echo number_format( $stage_sum, 0 ); ?></span>
            </div>
            <div class="kanban-cards">
                <?php if ( ! empty( $stage_opps ) ) : ?>
                    <?php foreach ( $stage_opps as $c ) : ?>
                        <div class="kanban-card">
                            <h4><?php echo esc_html( $c['title'] ); ?></h4>
                            <div class="card-meta">
                                <strong><?php echo esc_html( trim( $c['first_name'] . ' ' . $c['last_name'] ) ); ?></strong>
                                <br><code><?php echo esc_html( $c['reference'] ); ?></code>
                            </div>
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-top:8px;">
                                <span class="card-val">$<?php echo number_format( $c['value'], 2 ); ?></span>
                                
                                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                    <?php wp_nonce_field( 'outbound_crm_nonce' ); ?>
                                    <input type="hidden" name="action" value="outbound_crm_action">
                                    <input type="hidden" name="crm_action" value="update_stage">
                                    <input type="hidden" name="opportunity_id" value="<?php echo intval( $c['id'] ); ?>">
                                    <select name="new_stage" onchange="this.form.submit()" style="font-size:11px; padding:3px 6px; border-radius:4px; border:1px solid #cbd5e1;">
                                        <option value="">Move...</option>
                                        <?php foreach ( $stages as $sk => $sl ) : if ( $sk !== $stage_key ) : ?>
                                            <option value="<?php echo esc_attr( $sk ); ?>"><?php echo esc_html( $sl ); ?></option>
                                        <?php endif; endforeach; ?>
                                    </select>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else : ?>
                    <div style="padding:24px 16px; text-align:center; color:#94a3b8; font-size:12px;">
                        <?php _e( 'No deals in this stage', 'outbound-headless' ); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>
