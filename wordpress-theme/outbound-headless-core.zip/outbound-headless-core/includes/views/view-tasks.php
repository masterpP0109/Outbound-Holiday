<?php
/**
 * Outbound CRM Studio - Tasks & Reminders View
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
if ( ! isset( $tasks ) ) {
    $tasks = $wpdb->get_results( "
        SELECT t.*, c.first_name, c.last_name, c.phone, c.email
        FROM {$wpdb->prefix}outbound_crm_tasks t
        LEFT JOIN {$wpdb->prefix}outbound_crm_customers c ON t.customer_id = c.id
        ORDER BY t.due_date ASC, t.id DESC
    ", ARRAY_A );
}
?>

<div class="crm-toolbar">
    <div class="crm-search-box">
        <span class="dashicons dashicons-search" style="color:#64748b;"></span>
        <input type="text" id="crm-record-search" placeholder="<?php esc_attr_e( 'Search tasks by title or customer...', 'outbound-headless' ); ?>">
    </div>
    <div style="display:flex; gap:10px;">
        <button type="button" class="crm-btn crm-btn-secondary" id="crm-expand-all"><?php _e( 'Expand All', 'outbound-headless' ); ?></button>
        <button type="button" class="crm-btn crm-btn-primary" onclick="document.getElementById('new-task-card').classList.toggle('expanded');">
            <span class="dashicons dashicons-plus-alt2"></span> <?php _e( 'Add Task', 'outbound-headless' ); ?>
        </button>
    </div>
</div>

<!-- New Task Card (Collapsed by default) -->
<div class="crm-record-card" id="new-task-card" style="margin-bottom:20px; border-style:dashed;">
    <div class="crm-card-header">
        <div class="crm-card-title-group">
            <span class="dashicons dashicons-plus" style="color:#0284c7;"></span>
            <h3><?php _e( 'Create Follow-up / Operational Task', 'outbound-headless' ); ?></h3>
        </div>
        <span class="dashicons dashicons-arrow-down-alt2 crm-toggle-icon"></span>
    </div>
    <div class="crm-card-body">
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <?php wp_nonce_field( 'outbound_crm_nonce' ); ?>
            <input type="hidden" name="action" value="outbound_crm_action">
            <input type="hidden" name="crm_action" value="add_task">

            <div class="crm-form-grid">
                <div class="crm-form-group">
                    <label><?php _e( 'Task Title *', 'outbound-headless' ); ?></label>
                    <input type="text" name="title" required placeholder="e.g. Call guest regarding Falls helicopter flight">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Task Type', 'outbound-headless' ); ?></label>
                    <select name="task_type">
                        <option value="follow_up">WhatsApp / Phone Follow-up</option>
                        <option value="quote_preparation">Prepare & Send Quote</option>
                        <option value="payment_reminder">Payment Reminder</option>
                        <option value="arrival_prep">Arrival Prep & Airport Transfer</option>
                        <option value="review_request">Post-Trip Review Request</option>
                    </select>
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Customer ID (Optional)', 'outbound-headless' ); ?></label>
                    <input type="number" name="customer_id" placeholder="e.g. 1">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Due Date *', 'outbound-headless' ); ?></label>
                    <input type="date" name="due_date" value="<?php echo date( 'Y-m-d', strtotime( '+1 day' ) ); ?>" required>
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Priority', 'outbound-headless' ); ?></label>
                    <select name="priority">
                        <option value="low">Low</option>
                        <option value="medium" selected>Medium</option>
                        <option value="high">High</option>
                    </select>
                </div>
            </div>

            <div class="crm-form-group" style="margin-bottom:16px;">
                <label><?php _e( 'Notes & Instructions', 'outbound-headless' ); ?></label>
                <textarea name="notes" rows="2" placeholder="Details regarding this follow-up..."></textarea>
            </div>

            <div style="display:flex; justify-content:flex-end;">
                <button type="submit" class="crm-btn crm-btn-primary">
                    <span class="dashicons dashicons-saved"></span> <?php _e( 'Schedule Task', 'outbound-headless' ); ?>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Tasks Stack -->
<div class="crm-card-stack">
    <?php if ( ! empty( $tasks ) ) : ?>
        <?php foreach ( $tasks as $t ) : 
            $is_overdue = ( $t['status'] === 'pending' && $t['due_date'] < current_time( 'Y-m-d' ) );
        ?>
            <div class="crm-record-card" id="task-card-<?php echo intval( $t['id'] ); ?>" style="<?php echo $is_overdue ? 'border-left:4px solid #ef4444;' : ''; ?>">
                <div class="crm-card-header">
                    <div class="crm-card-title-group">
                        <span class="dashicons dashicons-clock" style="color:<?php echo $is_overdue ? '#ef4444' : '#0284c7'; ?>;"></span>
                        <h3><?php echo esc_html( $t['title'] ); ?></h3>
                        <span class="crm-badge badge-contacted"><?php echo esc_html( ucfirst( str_replace( '_', ' ', $t['task_type'] ) ) ); ?></span>
                        <span class="crm-badge badge-<?php echo esc_attr( $t['status'] ); ?>"><?php echo esc_html( ucfirst( $t['status'] ) ); ?></span>
                    </div>
                    <div class="crm-card-meta">
                        <?php if ( ! empty( $t['first_name'] ) ) : ?>
                            <span><strong><?php echo esc_html( trim( $t['first_name'] . ' ' . $t['last_name'] ) ); ?></strong></span>
                        <?php endif; ?>
                        <span style="<?php echo $is_overdue ? 'color:#b91c1c; font-weight:700;' : ''; ?>">
                            Due: <?php echo esc_html( $t['due_date'] ); ?><?php if ( $is_overdue ) : ?> (OVERDUE)<?php endif; ?>
                        </span>
                        <span class="dashicons dashicons-arrow-down-alt2 crm-toggle-icon"></span>
                    </div>
                </div>

                <div class="crm-card-body">
                    <?php if ( ! empty( $t['notes'] ) ) : ?>
                        <div style="background:#f1f5f9; padding:12px; border-radius:6px; margin-bottom:16px; font-size:13px; color:#334155;">
                            <?php echo nl2br( esc_html( $t['notes'] ) ); ?>
                        </div>
                    <?php endif; ?>

                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <span style="font-size:12px; color:#64748b;"><?php printf( __( 'Priority: %s', 'outbound-headless' ), strtoupper( $t['priority'] ?: 'MEDIUM' ) ); ?></span>
                        </div>
                        <div style="display:flex; gap:10px;">
                            <?php if ( $t['status'] === 'pending' ) : ?>
                                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
                                    <?php wp_nonce_field( 'outbound_crm_nonce' ); ?>
                                    <input type="hidden" name="action" value="outbound_crm_action">
                                    <input type="hidden" name="crm_action" value="complete_task">
                                    <input type="hidden" name="task_id" value="<?php echo intval( $t['id'] ); ?>">
                                    <button type="submit" class="crm-btn crm-btn-primary" style="background:#10b981;">
                                        <span class="dashicons dashicons-yes"></span> <?php _e( 'Mark as Completed', 'outbound-headless' ); ?>
                                    </button>
                                </form>
                            <?php else : ?>
                                <span style="color:#10b981; font-weight:700; font-size:13px;"><span class="dashicons dashicons-yes-alt"></span> <?php _e( 'Completed', 'outbound-headless' ); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else : ?>
        <div class="crm-record-card" style="padding:40px; text-align:center;">
            <p style="color:#64748b; font-size:15px; margin:0;"><?php _e( 'No active tasks found. Click "Add Task" to schedule your first follow-up.', 'outbound-headless' ); ?></p>
        </div>
    <?php endif; ?>
</div>
