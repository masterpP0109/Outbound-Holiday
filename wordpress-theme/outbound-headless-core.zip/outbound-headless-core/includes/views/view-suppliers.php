<?php
/**
 * Outbound CRM Studio - Supplier Directory View
 * Expandable cards with hotel/lodge contacts, activity operators and payment terms
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
if ( ! isset( $suppliers ) ) {
    $suppliers = $wpdb->get_results( "
        SELECT * FROM {$wpdb->prefix}outbound_crm_suppliers ORDER BY name ASC
    ", ARRAY_A );
}
?>

<div class="crm-toolbar">
    <div class="crm-search-box">
        <span class="dashicons dashicons-search" style="color:#64748b;"></span>
        <input type="text" id="crm-record-search" placeholder="<?php esc_attr_e( 'Search suppliers by name, category or contact...', 'outbound-headless' ); ?>">
    </div>
    <div style="display:flex; gap:10px;">
        <button type="button" class="crm-btn crm-btn-secondary" id="crm-expand-all"><?php _e( 'Expand All', 'outbound-headless' ); ?></button>
        <button type="button" class="crm-btn crm-btn-primary" onclick="document.getElementById('new-supplier-card').classList.toggle('expanded');">
            <span class="dashicons dashicons-plus-alt2"></span> <?php _e( 'Add Supplier', 'outbound-headless' ); ?>
        </button>
    </div>
</div>

<!-- New Supplier Registration Card (Collapsed by default) -->
<div class="crm-record-card" id="new-supplier-card" style="margin-bottom:20px; border-style:dashed;">
    <div class="crm-card-header">
        <div class="crm-card-title-group">
            <span class="dashicons dashicons-plus" style="color:#0284c7;"></span>
            <h3><?php _e( 'Register New Supplier / Service Partner', 'outbound-headless' ); ?></h3>
        </div>
        <span class="dashicons dashicons-arrow-down-alt2 crm-toggle-icon"></span>
    </div>
    <div class="crm-card-body">
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <?php wp_nonce_field( 'outbound_crm_nonce' ); ?>
            <input type="hidden" name="action" value="outbound_crm_action">
            <input type="hidden" name="crm_action" value="save_supplier">
            <input type="hidden" name="supplier_id" value="0">

            <div class="crm-form-grid">
                <div class="crm-form-group">
                    <label><?php _e( 'Supplier / Property Name *', 'outbound-headless' ); ?></label>
                    <input type="text" name="name" required placeholder="e.g. Victoria Falls Safari Lodge">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Category', 'outbound-headless' ); ?></label>
                    <select name="supplier_type">
                        <option value="accommodation">Accommodation / Hotel / Lodge</option>
                        <option value="activity">Activity Operator (Heli, Cruise, Bungee)</option>
                        <option value="transfer">Airport & Cross-Border Transfers</option>
                        <option value="safari">Game Drives & Chobe Safaris</option>
                        <option value="restaurant">Dining / BOMA Experience</option>
                    </select>
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Contact Person', 'outbound-headless' ); ?></label>
                    <input type="text" name="contact_person" placeholder="Reservations Manager">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Reservations Email', 'outbound-headless' ); ?></label>
                    <input type="email" name="email" placeholder="reservations@partner.com">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'WhatsApp / Phone', 'outbound-headless' ); ?></label>
                    <input type="text" name="whatsapp" placeholder="+263 77 ...">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Location', 'outbound-headless' ); ?></label>
                    <input type="text" name="location" value="Victoria Falls">
                </div>
                <div class="crm-form-group">
                    <label><?php _e( 'Payment Terms', 'outbound-headless' ); ?></label>
                    <input type="text" name="payment_terms" value="30 Days Account / Pre-payment">
                </div>
            </div>

            <div class="crm-form-group" style="margin-bottom:16px;">
                <label><?php _e( 'Services Offered & Contract Notes', 'outbound-headless' ); ?></label>
                <textarea name="services_offered" rows="2" placeholder="STOs, commission rates, allocation terms..."></textarea>
            </div>

            <div style="display:flex; justify-content:flex-end;">
                <button type="submit" class="crm-btn crm-btn-primary">
                    <span class="dashicons dashicons-saved"></span> <?php _e( 'Save Supplier Profile', 'outbound-headless' ); ?>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Suppliers Stack -->
<div class="crm-card-stack">
    <?php if ( ! empty( $suppliers ) ) : ?>
        <?php foreach ( $suppliers as $s ) : 
            $wa_clean = preg_replace( '/[^0-9]/', '', $s['whatsapp'] ?: $s['phone'] );
        ?>
            <div class="crm-record-card" id="supplier-card-<?php echo intval( $s['id'] ); ?>">
                <div class="crm-card-header">
                    <div class="crm-card-title-group">
                        <span class="dashicons dashicons-store" style="color:#0284c7;"></span>
                        <h3><?php echo esc_html( $s['name'] ); ?></h3>
                        <span class="crm-badge badge-contacted"><?php echo esc_html( ucfirst( $s['supplier_type'] ) ); ?></span>
                        <span class="crm-badge badge-confirmed"><?php echo esc_html( ucfirst( $s['status'] ) ); ?></span>
                    </div>
                    <div class="crm-card-meta">
                        <span><?php echo esc_html( $s['contact_person'] ?: 'Operations' ); ?></span>
                        <span><span class="dashicons dashicons-location" style="font-size:16px;"></span> <?php echo esc_html( $s['location'] ?: 'Victoria Falls' ); ?></span>
                        <span class="dashicons dashicons-arrow-down-alt2 crm-toggle-icon"></span>
                    </div>
                </div>

                <div class="crm-card-body">
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <?php wp_nonce_field( 'outbound_crm_nonce' ); ?>
                        <input type="hidden" name="action" value="outbound_crm_action">
                        <input type="hidden" name="crm_action" value="save_supplier">
                        <input type="hidden" name="supplier_id" value="<?php echo intval( $s['id'] ); ?>">

                        <div class="crm-form-grid">
                            <div class="crm-form-group">
                                <label><?php _e( 'Supplier Name', 'outbound-headless' ); ?></label>
                                <input type="text" name="name" value="<?php echo esc_attr( $s['name'] ); ?>" required>
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Supplier Category', 'outbound-headless' ); ?></label>
                                <select name="supplier_type">
                                    <option value="accommodation" <?php selected( $s['supplier_type'], 'accommodation' ); ?>>Accommodation / Hotel / Lodge</option>
                                    <option value="activity" <?php selected( $s['supplier_type'], 'activity' ); ?>>Activity Operator</option>
                                    <option value="transfer" <?php selected( $s['supplier_type'], 'transfer' ); ?>>Transfers & Logistics</option>
                                    <option value="safari" <?php selected( $s['supplier_type'], 'safari' ); ?>>Safaris & Game Drives</option>
                                    <option value="restaurant" <?php selected( $s['supplier_type'], 'restaurant' ); ?>>Dining / Experiences</option>
                                </select>
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Contact Person', 'outbound-headless' ); ?></label>
                                <input type="text" name="contact_person" value="<?php echo esc_attr( $s['contact_person'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Reservations Email', 'outbound-headless' ); ?></label>
                                <input type="email" name="email" value="<?php echo esc_attr( $s['email'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'WhatsApp / Phone', 'outbound-headless' ); ?></label>
                                <input type="text" name="whatsapp" value="<?php echo esc_attr( $s['whatsapp'] ?: $s['phone'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Location', 'outbound-headless' ); ?></label>
                                <input type="text" name="location" value="<?php echo esc_attr( $s['location'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Payment Terms', 'outbound-headless' ); ?></label>
                                <input type="text" name="payment_terms" value="<?php echo esc_attr( $s['payment_terms'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Status', 'outbound-headless' ); ?></label>
                                <select name="status">
                                    <option value="active" <?php selected( $s['status'], 'active' ); ?>>Active Partner</option>
                                    <option value="inactive" <?php selected( $s['status'], 'inactive' ); ?>>Inactive</option>
                                </select>
                            </div>
                        </div>

                        <div class="crm-form-group" style="margin-bottom:16px;">
                            <label><?php _e( 'Services Offered & Agreed Rates', 'outbound-headless' ); ?></label>
                            <textarea name="services_offered" rows="2"><?php echo esc_textarea( $s['services_offered'] ); ?></textarea>
                        </div>

                        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid #e2e8f0; padding-top:16px;">
                            <div style="display:flex; gap:8px;">
                                <?php if ( ! empty( $wa_clean ) ) : ?>
                                    <a href="https://wa.me/<?php echo esc_attr( $wa_clean ); ?>?text=<?php echo urlencode( "Hello {$s['name']} reservations, warm greetings from Outbound Holidays Victoria Falls team." ); ?>" target="_blank" class="crm-btn crm-btn-whatsapp">
                                        <span class="dashicons dashicons-format-chat"></span> <?php _e( 'WhatsApp Partner', 'outbound-headless' ); ?>
                                    </a>
                                <?php endif; ?>
                                <?php if ( ! empty( $s['email'] ) ) : ?>
                                    <a href="mailto:<?php echo esc_attr( $s['email'] ); ?>" class="crm-btn crm-btn-secondary">
                                        <span class="dashicons dashicons-email"></span> <?php _e( 'Email Partner', 'outbound-headless' ); ?>
                                    </a>
                                <?php endif; ?>
                            </div>

                            <div style="display:flex; gap:10px;">
                                <button type="submit" class="crm-btn crm-btn-primary">
                                    <span class="dashicons dashicons-saved"></span> <?php _e( 'Save Supplier Profile', 'outbound-headless' ); ?>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else : ?>
        <div class="crm-record-card" style="padding:40px; text-align:center;">
            <p style="color:#64748b; font-size:15px; margin:0;"><?php _e( 'No suppliers registered yet. Click "Add Supplier" to register your first hotel or tour operator.', 'outbound-headless' ); ?></p>
        </div>
    <?php endif; ?>
</div>
