<?php
/**
 * Outbound CRM Studio - WhatsApp & Communication Templates View
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="crm-toolbar">
    <div style="font-size:14px; font-weight:700; color:#0f172a;">
        <?php _e( 'Standardised Victoria Falls Client Communication Templates', 'outbound-headless' ); ?>
    </div>
    <div>
        <span style="font-size:12px; color:#64748b;"><?php _e( 'Click "Copy Template" to copy directly to your clipboard for WhatsApp Web or email client.', 'outbound-headless' ); ?></span>
    </div>
</div>

<div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(360px, 1fr)); gap:20px;">
    <!-- Template 1: Initial Response -->
    <div class="crm-card">
        <h2><span class="dashicons dashicons-format-chat" style="color:#25D366;"></span> <?php _e( '1. Initial Enquiry Follow-Up (WhatsApp)', 'outbound-headless' ); ?></h2>
        <div style="background:#f8fafc; border:1px solid #e2e8f0; padding:16px; border-radius:8px; font-size:13px; line-height:1.7; margin-bottom:16px; color:#1e293b;" id="tmpl-1">
            Hi [Guest Name], warm greetings from Victoria Falls! 🌿<br><br>
            Thank you for reaching out to Outbound Holidays regarding your trip enquiry [Reference]. I am currently reviewing your dates and curated activities.<br><br>
            Do you have a preferred accommodation style (e.g. safari lodge with game drives or riverfront hotel close to the Falls)? Looking forward to planning an unforgettable holiday for you!
        </div>
        <button type="button" class="crm-btn crm-btn-whatsapp" onclick="navigator.clipboard.writeText(document.getElementById('tmpl-1').innerText); alert('Template copied to clipboard!');">
            <span class="dashicons dashicons-clipboard"></span> <?php _e( 'Copy WhatsApp Message', 'outbound-headless' ); ?>
        </button>
    </div>

    <!-- Template 2: Quotation Sent -->
    <div class="crm-card">
        <h2><span class="dashicons dashicons-media-document" style="color:#0284c7;"></span> <?php _e( '2. Quotation & Itinerary Delivery', 'outbound-headless' ); ?></h2>
        <div style="background:#f8fafc; border:1px solid #e2e8f0; padding:16px; border-radius:8px; font-size:13px; line-height:1.7; margin-bottom:16px; color:#1e293b;" id="tmpl-2">
            Hi [Guest Name], your custom Victoria Falls itinerary & proposal [Quote #] is ready! 📄✨<br><br>
            It includes your stay at [Hotel/Lodge], guided Rainforest Tour of the Falls, Zambezi Sunset Cruise, and private airport transfers.<br><br>
            Total package: $[Amount] USD.<br>
            Please take a look and let me know if you would like to adjust any dates or add helicopter flights!
        </div>
        <button type="button" class="crm-btn crm-btn-whatsapp" onclick="navigator.clipboard.writeText(document.getElementById('tmpl-2').innerText); alert('Template copied to clipboard!');">
            <span class="dashicons dashicons-clipboard"></span> <?php _e( 'Copy WhatsApp Message', 'outbound-headless' ); ?>
        </button>
    </div>

    <!-- Template 3: Pre-Arrival Check-in -->
    <div class="crm-card">
        <h2><span class="dashicons dashicons-location-alt" style="color:#f59e0b;"></span> <?php _e( '3. Pre-Arrival & Driver Paging Details', 'outbound-headless' ); ?></h2>
        <div style="background:#f8fafc; border:1px solid #e2e8f0; padding:16px; border-radius:8px; font-size:13px; line-height:1.7; margin-bottom:16px; color:#1e293b;" id="tmpl-3">
            Hi [Guest Name], we are looking forward to welcoming you to Victoria Falls tomorrow! ✈️🐘<br><br>
            Your private Outbound Holidays driver will meet you at Victoria Falls Airport (VFA) holding a sign with your name [Guest Name].<br><br>
            If your flight is delayed or you need anything upon landing, message us here directly. Safe travels!
        </div>
        <button type="button" class="crm-btn crm-btn-whatsapp" onclick="navigator.clipboard.writeText(document.getElementById('tmpl-3').innerText); alert('Template copied to clipboard!');">
            <span class="dashicons dashicons-clipboard"></span> <?php _e( 'Copy WhatsApp Message', 'outbound-headless' ); ?>
        </button>
    </div>

    <!-- Template 4: Post-Trip Review -->
    <div class="crm-card">
        <h2><span class="dashicons dashicons-star-filled" style="color:#eab308;"></span> <?php _e( '4. Post-Trip Guest Review Request', 'outbound-headless' ); ?></h2>
        <div style="background:#f8fafc; border:1px solid #e2e8f0; padding:16px; border-radius:8px; font-size:13px; line-height:1.7; margin-bottom:16px; color:#1e293b;" id="tmpl-4">
            Hi [Guest Name], we hope you arrived home safely from Victoria Falls! 🌍<br><br>
            It was our absolute pleasure hosting you. If you enjoyed your holiday with Outbound Holidays, would you mind taking 60 seconds to share your experience? It means the world to our local Zimbabwe team: [Review Link]<br><br>
            We hope to welcome you back on safari soon!
        </div>
        <button type="button" class="crm-btn crm-btn-whatsapp" onclick="navigator.clipboard.writeText(document.getElementById('tmpl-4').innerText); alert('Template copied to clipboard!');">
            <span class="dashicons dashicons-clipboard"></span> <?php _e( 'Copy WhatsApp Message', 'outbound-headless' ); ?>
        </button>
    </div>
</div>
