<?php
/**
 * Outbound Holidays CRM Studio Shell Template
 * Renders the Branded Header, Horizontal Navigation Tabs, Content View, and Sticky Save Bar
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$page = sanitize_key( $_GET['page'] ?? 'outbound-crm' );
$page_tab_map = [
    'outbound-crm'            => 'dashboard',
    'outbound-crm-leads'      => 'leads',
    'outbound-crm-pipeline'   => 'pipeline',
    'outbound-crm-customers'  => 'customers',
    'outbound-crm-quotations' => 'quotations',
    'outbound-crm-bookings'   => 'bookings',
    'outbound-crm-payments'   => 'payments',
    'outbound-crm-tasks'      => 'tasks',
    'outbound-crm-suppliers'  => 'suppliers',
    'outbound-crm-reports'    => 'reports',
    'outbound-crm-templates'  => 'templates',
    'outbound-crm-settings'   => 'settings',
];

$current_tab = sanitize_key( $_GET['tab'] ?? ( $page_tab_map[ $page ] ?? 'dashboard' ) );

$tabs = [
    'dashboard'   => [ 'label' => __( 'Dashboard', 'outbound-headless' ), 'icon' => 'dashicons-chart-area' ],
    'leads'       => [ 'label' => __( 'Enquiries & Leads', 'outbound-headless' ), 'icon' => 'dashicons-email' ],
    'customers'   => [ 'label' => __( 'Customers', 'outbound-headless' ), 'icon' => 'dashicons-admin-users' ],
    'pipeline'    => [ 'label' => __( 'Sales Pipeline', 'outbound-headless' ), 'icon' => 'dashicons-randomize' ],
    'quotations'  => [ 'label' => __( 'Quotations', 'outbound-headless' ), 'icon' => 'dashicons-media-document' ],
    'bookings'    => [ 'label' => __( 'Bookings', 'outbound-headless' ), 'icon' => 'dashicons-calendar-alt' ],
    'payments'    => [ 'label' => __( 'Payments', 'outbound-headless' ), 'icon' => 'dashicons-money-alt' ],
    'tasks'       => [ 'label' => __( 'Tasks & Follow-ups', 'outbound-headless' ), 'icon' => 'dashicons-clock' ],
    'suppliers'   => [ 'label' => __( 'Suppliers', 'outbound-headless' ), 'icon' => 'dashicons-store' ],
    'templates'   => [ 'label' => __( 'WhatsApp & Messages', 'outbound-headless' ), 'icon' => 'dashicons-format-chat' ],
    'reports'     => [ 'label' => __( 'Reports', 'outbound-headless' ), 'icon' => 'dashicons-chart-pie' ],
    'settings'    => [ 'label' => __( 'CRM Settings', 'outbound-headless' ), 'icon' => 'dashicons-admin-generic' ],
];
?>

<div class="wrap outbound-crm-studio-wrap">
    <!-- 1. Branded Content Studio Style Header -->
    <div class="crm-studio-header">
        <div>
            <h1>
                <span class="dashicons dashicons-palmtree" style="font-size:28px; width:28px; height:28px;"></span>
                <?php _e( 'Outbound Holidays CRM Studio', 'outbound-headless' ); ?>
                <span class="crm-brand-badge">Victoria Falls Operations</span>
            </h1>
            <p><?php _e( 'Unified traveller management, quotation builder, supplier bookings & payment reconciliation.', 'outbound-headless' ); ?></p>
        </div>
        <div>
            <a href="https://outboundholiday.com" target="_blank" class="crm-btn crm-btn-secondary" style="background:rgba(255,255,255,0.1); color:#fff !important; border-color:rgba(255,255,255,0.2);">
                <span class="dashicons dashicons-external" style="margin-top:2px;"></span> <?php _e( 'Live Website', 'outbound-headless' ); ?>
            </a>
        </div>
    </div>

    <!-- 2. Horizontal Section Tabs Matching Content Studio -->
    <nav class="crm-tabs-nav" aria-label="<?php esc_attr_e( 'CRM Studio Navigation Tabs', 'outbound-headless' ); ?>">
        <?php foreach ( $tabs as $tab_id => $t ) : 
            $is_active = ( $current_tab === $tab_id );
            $url = add_query_arg( [ 'page' => 'outbound-crm', 'tab' => $tab_id ], admin_url( 'admin.php' ) );
        ?>
            <a href="<?php echo esc_url( $url ); ?>" class="crm-tab-link <?php echo $is_active ? 'active' : ''; ?>">
                <span class="dashicons <?php echo esc_attr( $t['icon'] ); ?>"></span>
                <?php echo esc_html( $t['label'] ); ?>
            </a>
        <?php endforeach; ?>
    </nav>

    <!-- 3. Active Tab Content -->
    <div class="crm-tab-view-container">
        <?php
        switch ( $current_tab ) {
            case 'leads':
                include plugin_dir_path( __FILE__ ) . 'view-leads.php';
                break;
            case 'customers':
                include plugin_dir_path( __FILE__ ) . 'view-customers.php';
                break;
            case 'pipeline':
                include plugin_dir_path( __FILE__ ) . 'view-pipeline.php';
                break;
            case 'quotations':
                include plugin_dir_path( __FILE__ ) . 'view-quotations.php';
                break;
            case 'bookings':
                include plugin_dir_path( __FILE__ ) . 'view-bookings.php';
                break;
            case 'payments':
                include plugin_dir_path( __FILE__ ) . 'view-payments.php';
                break;
            case 'tasks':
                include plugin_dir_path( __FILE__ ) . 'view-tasks.php';
                break;
            case 'suppliers':
                include plugin_dir_path( __FILE__ ) . 'view-suppliers.php';
                break;
            case 'templates':
                include plugin_dir_path( __FILE__ ) . 'view-templates.php';
                break;
            case 'reports':
                include plugin_dir_path( __FILE__ ) . 'view-reports.php';
                break;
            case 'settings':
                include plugin_dir_path( __FILE__ ) . 'view-settings.php';
                break;
            case 'dashboard':
            default:
                include plugin_dir_path( __FILE__ ) . 'view-dashboard.php';
                break;
        }
        ?>
    </div>

    <!-- 4. Sticky Save Bar for Forms -->
    <div class="crm-sticky-save-bar" id="crm-sticky-bar" style="display:none;">
        <span class="crm-save-bar-info">
            <span class="dashicons dashicons-info" style="color:#38bdf8; margin-top:2px;"></span>
            <?php _e( 'You have unsaved changes in your CRM record.', 'outbound-headless' ); ?>
        </span>
        <div style="display:flex; gap:10px;">
            <button type="button" class="crm-btn crm-btn-secondary" onclick="window.location.reload();"><?php _e( 'Discard', 'outbound-headless' ); ?></button>
            <button type="button" id="crm-sticky-save-btn" class="crm-btn crm-btn-primary"><?php _e( 'Save Changes', 'outbound-headless' ); ?></button>
        </div>
    </div>
</div>
