<?php
/**
 * Outbound CRM Studio - Payments & Financial Ledger View
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
if ( ! isset( $payments ) ) {
    $payments = $wpdb->get_results( "
        SELECT p.*, b.booking_ref, c.first_name, c.last_name, c.email
        FROM {$wpdb->prefix}outbound_crm_payments p
        LEFT JOIN {$wpdb->prefix}outbound_crm_bookings b ON p.booking_id = b.id
        LEFT JOIN {$wpdb->prefix}outbound_crm_customers c ON p.customer_id = c.id
        ORDER BY p.id DESC
    ", ARRAY_A );
}

$total_collected = array_sum( array_column( $payments, 'amount' ) );
?>

<!-- Financial Highlights -->
<div class="crm-stats-grid">
    <div class="crm-stat-card success">
        <span class="stat-label"><?php _e( 'Total Payments Collected', 'outbound-headless' ); ?></span>
        <span class="stat-value">$<?php echo number_format( $total_collected, 2 ); ?></span>
        <span class="stat-sub"><?php printf( __( '%d Reconciled transactions', 'outbound-headless' ), count( $payments ) ); ?></span>
    </div>
    <div class="crm-stat-card primary">
        <span class="stat-label"><?php _e( 'Latest Payment Date', 'outbound-headless' ); ?></span>
        <span class="stat-value"><?php echo ! empty( $payments ) ? esc_html( $payments[0]['payment_date'] ) : '—'; ?></span>
        <span class="stat-sub"><?php _e( 'Victoria Falls banking & card ledger', 'outbound-headless' ); ?></span>
    </div>
</div>

<div class="crm-toolbar">
    <div class="crm-search-box">
        <span class="dashicons dashicons-search" style="color:#64748b;"></span>
        <input type="text" id="crm-record-search" placeholder="<?php esc_attr_e( 'Search by booking ref, guest name or proof ID...', 'outbound-headless' ); ?>">
    </div>
    <div>
        <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'outbound-crm', 'tab' => 'bookings' ], admin_url( 'admin.php' ) ) ); ?>" class="crm-btn crm-btn-secondary">
            <span class="dashicons dashicons-arrow-left-alt"></span> <?php _e( 'Back to Bookings', 'outbound-headless' ); ?>
        </a>
    </div>
</div>

<div class="crm-card" style="padding:0; overflow:hidden;">
    <table class="crm-table">
        <thead>
            <tr>
                <th><?php _e( 'Receipt / ID', 'outbound-headless' ); ?></th>
                <th><?php _e( 'Booking Ref', 'outbound-headless' ); ?></th>
                <th><?php _e( 'Customer / Guest', 'outbound-headless' ); ?></th>
                <th><?php _e( 'Amount ($ USD)', 'outbound-headless' ); ?></th>
                <th><?php _e( 'Method', 'outbound-headless' ); ?></th>
                <th><?php _e( 'Reference / Proof', 'outbound-headless' ); ?></th>
                <th><?php _e( 'Date', 'outbound-headless' ); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if ( ! empty( $payments ) ) : ?>
                <?php foreach ( $payments as $p ) : ?>
                    <tr class="crm-record-card" style="display:table-row;">
                        <td><strong>#PAY-<?php echo intval( $p['id'] ); ?></strong></td>
                        <td><code><?php echo esc_html( $p['booking_ref'] ?: 'N/A' ); ?></code></td>
                        <td>
                            <strong><?php echo esc_html( trim( $p['first_name'] . ' ' . $p['last_name'] ) ); ?></strong>
                            <?php if ( ! empty( $p['email'] ) ) : ?>
                                <br><small style="color:#64748b;"><?php echo esc_html( $p['email'] ); ?></small>
                            <?php endif; ?>
                        </td>
                        <td style="color:#10b981; font-weight:800; font-size:14px;">
                            $<?php echo number_format( $p['amount'], 2 ); ?>
                        </td>
                        <td>
                            <span class="crm-badge badge-contacted">
                                <?php echo esc_html( ucfirst( str_replace( '_', ' ', $p['payment_method'] ) ) ); ?>
                            </span>
                        </td>
                        <td><code><?php echo esc_html( $p['payment_reference'] ?: 'Direct' ); ?></code></td>
                        <td><?php echo esc_html( $p['payment_date'] ); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="7" style="padding:40px; text-align:center; color:#64748b;">
                        <?php _e( 'No customer payments recorded yet.', 'outbound-headless' ); ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
