<?php
/**
 * Outbound CRM Studio - Enquiries & Leads View
 * Expandable cards with complete trip parameters, message history, and direct status updates
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
$opps = $wpdb->get_results( "
    SELECT o.*, c.first_name, c.last_name, c.email, c.phone, c.whatsapp 
    FROM {$wpdb->prefix}outbound_crm_opportunities o
    LEFT JOIN {$wpdb->prefix}outbound_crm_customers c ON o.customer_id = c.id
    ORDER BY o.id DESC
", ARRAY_A );
?>

<div class="crm-toolbar">
    <div class="crm-search-box">
        <span class="dashicons dashicons-search" style="color:#64748b;"></span>
        <input type="text" id="crm-record-search" placeholder="<?php esc_attr_e( 'Search enquiries by reference, guest name or email...', 'outbound-headless' ); ?>">
    </div>
    <div style="display:flex; gap:10px;">
        <button type="button" class="crm-btn crm-btn-secondary" id="crm-expand-all"><?php _e( 'Expand All', 'outbound-headless' ); ?></button>
    </div>
</div>

<div class="crm-card-stack">
    <?php if ( ! empty( $opps ) ) : ?>
        <?php foreach ( $opps as $opp ) : 
            $wa_clean = preg_replace( '/[^0-9]/', '', $opp['whatsapp'] ?: $opp['phone'] );
            $trip = ! empty( $opp['trip_payload'] ) ? json_decode( $opp['trip_payload'], true ) : [];
        ?>
            <div class="crm-record-card" id="enquiry-card-<?php echo intval( $opp['id'] ); ?>">
                <div class="crm-card-header">
                    <div class="crm-card-title-group">
                        <span class="dashicons dashicons-email-alt" style="color:#0284c7;"></span>
                        <h3><?php echo esc_html( $opp['reference'] ); ?> — <?php echo esc_html( trim( $opp['first_name'] . ' ' . $opp['last_name'] ) ); ?></h3>
                        <span class="crm-badge badge-<?php echo esc_attr( $opp['stage'] ); ?>">
                            <?php echo esc_html( ucfirst( str_replace( '_', ' ', $opp['stage'] ) ) ); ?>
                        </span>
                    </div>
                    <div class="crm-card-meta">
                        <span><strong>$<?php echo number_format( $opp['value'], 2 ); ?></strong></span>
                        <span><?php echo esc_html( ucfirst( $opp['lead_source'] ) ); ?></span>
                        <span><?php echo date( 'M j, Y', strtotime( $opp['created_at'] ) ); ?></span>
                        <span class="dashicons dashicons-arrow-down-alt2 crm-toggle-icon"></span>
                    </div>
                </div>

                <div class="crm-card-body">
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <?php wp_nonce_field( 'outbound_crm_nonce' ); ?>
                        <input type="hidden" name="action" value="outbound_crm_action">
                        <input type="hidden" name="crm_action" value="update_opportunity">
                        <input type="hidden" name="opportunity_id" value="<?php echo intval( $opp['id'] ); ?>">

                        <div class="crm-form-grid">
                            <div class="crm-form-group">
                                <label><?php _e( 'Enquiry Title / Package', 'outbound-headless' ); ?></label>
                                <input type="text" name="title" value="<?php echo esc_attr( $opp['title'] ); ?>" required>
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Pipeline Stage', 'outbound-headless' ); ?></label>
                                <select name="stage">
                                    <option value="new" <?php selected( $opp['stage'], 'new' ); ?>>New Enquiry</option>
                                    <option value="contacted" <?php selected( $opp['stage'], 'contacted' ); ?>>Contacted</option>
                                    <option value="qualified" <?php selected( $opp['stage'], 'qualified' ); ?>>Qualified</option>
                                    <option value="planning" <?php selected( $opp['stage'], 'planning' ); ?>>Planning / Preparing Quote</option>
                                    <option value="quote_sent" <?php selected( $opp['stage'], 'quote_sent' ); ?>>Quotation Sent</option>
                                    <option value="confirmed" <?php selected( $opp['stage'], 'confirmed' ); ?>>Confirmed Booking</option>
                                    <option value="lost" <?php selected( $opp['stage'], 'lost' ); ?>>Lost / Cancelled</option>
                                </select>
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Estimated Total ($ USD)', 'outbound-headless' ); ?></label>
                                <input type="number" step="0.01" name="value" value="<?php echo esc_attr( $opp['value'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Proposed Arrival Date', 'outbound-headless' ); ?></label>
                                <input type="date" name="arrival_date" value="<?php echo esc_attr( $opp['arrival_date'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Proposed Departure Date', 'outbound-headless' ); ?></label>
                                <input type="date" name="departure_date" value="<?php echo esc_attr( $opp['departure_date'] ); ?>">
                            </div>
                            <div class="crm-form-group">
                                <label><?php _e( 'Number of Adults', 'outbound-headless' ); ?></label>
                                <input type="number" name="adults" value="<?php echo esc_attr( $opp['adults'] ); ?>">
                            </div>
                        </div>

                        <!-- Structured Trip Details Captured From Frontend -->
                        <?php if ( ! empty( $trip ) ) : ?>
                            <div style="background:#f1f5f9; padding:16px; border-radius:8px; margin-bottom:18px;">
                                <h4 style="margin:0 0 10px 0; color:#0f172a; font-size:13px; text-transform:uppercase; letter-spacing:0.5px;">
                                    <?php _e( 'Preserved Frontend Selections', 'outbound-headless' ); ?>
                                </h4>
                                <div style="display:flex; gap:16px; flex-wrap:wrap; font-size:13px; color:#475569;">
                                    <div><strong>Party:</strong> <?php echo esc_html( ucfirst( $trip['partyType'] ?? 'General' ) ); ?></div>
                                    <div><strong>Accommodation:</strong> <?php echo esc_html( $trip['accommodationCategory'] ?? $trip['accommodationTitle'] ?? 'Standard' ); ?></div>
                                    <div><strong>Budget Range:</strong> <?php echo esc_html( $trip['budgetRange'] ?? 'Standard' ); ?></div>
                                    <?php if ( ! empty( $trip['selectedActivities'] ) ) : ?>
                                        <div style="width:100%;">
                                            <strong>Selected Activities:</strong> <?php echo esc_html( implode( ', ', (array) $trip['selectedActivities'] ) ); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="crm-form-group" style="margin-bottom:18px;">
                            <label><?php _e( 'Guest Message / Enquiry Notes', 'outbound-headless' ); ?></label>
                            <textarea name="customer_notes" rows="3"><?php echo esc_textarea( $opp['customer_notes'] ); ?></textarea>
                        </div>

                        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid #e2e8f0; padding-top:16px;">
                            <div style="display:flex; gap:8px;">
                                <?php if ( ! empty( $wa_clean ) ) : ?>
                                    <a href="https://wa.me/<?php echo esc_attr( $wa_clean ); ?>?text=<?php echo urlencode( "Hi {$opp['first_name']}, thank you for reaching out to Outbound Holidays regarding your Victoria Falls enquiry [{$opp['reference']}]." ); ?>" target="_blank" class="crm-btn crm-btn-whatsapp">
                                        <span class="dashicons dashicons-format-chat"></span> <?php _e( 'WhatsApp Guest', 'outbound-headless' ); ?>
                                    </a>
                                <?php endif; ?>
                                <a href="mailto:<?php echo esc_attr( $opp['email'] ); ?>?subject=<?php echo urlencode( "Outbound Holidays Enquiry [{$opp['reference']}]" ); ?>" class="crm-btn crm-btn-secondary">
                                    <span class="dashicons dashicons-email"></span> <?php _e( 'Email Guest', 'outbound-headless' ); ?>
                                </a>
                            </div>

                            <div style="display:flex; gap:10px;">
                                <button type="submit" class="crm-btn crm-btn-primary">
                                    <span class="dashicons dashicons-saved"></span> <?php _e( 'Save Changes', 'outbound-headless' ); ?>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else : ?>
        <div class="crm-record-card" style="padding:40px; text-align:center;">
            <p style="color:#64748b; font-size:15px; margin:0;"><?php _e( 'No customer enquiries received yet.', 'outbound-headless' ); ?></p>
        </div>
    <?php endif; ?>
</div>
