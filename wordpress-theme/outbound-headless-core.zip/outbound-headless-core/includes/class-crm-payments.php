<?php
/**
 * Outbound Holidays CRM Payments & Ledger Management
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Outbound_CRM_Payments' ) ) :
class Outbound_CRM_Payments {

    public static function get_all( $limit = 100, $offset = 0 ) {
        global $wpdb;
        $table_pmts = Outbound_CRM_Database::get_table( 'payments' );
        $table_bks  = Outbound_CRM_Database::get_table( 'bookings' );
        $table_cust = Outbound_CRM_Database::get_table( 'customers' );

        return $wpdb->get_results( $wpdb->prepare( "
            SELECT p.*, b.booking_ref, c.first_name, c.last_name, c.email
            FROM {$table_pmts} p
            LEFT JOIN {$table_bks} b ON p.booking_id = b.id
            LEFT JOIN {$table_cust} c ON p.customer_id = c.id
            ORDER BY p.id DESC
            LIMIT %d OFFSET %d
        ", $limit, $offset ), ARRAY_A );
    }

    public static function record( $booking_id, $amount, $method = 'bank_transfer', $reference = '', $notes = '' ) {
        global $wpdb;
        $booking = Outbound_CRM_Bookings::get( $booking_id );
        if ( ! $booking || $amount <= 0 ) {
            return false;
        }

        $now = current_time( 'mysql' );
        $table_pmts = Outbound_CRM_Database::get_table( 'payments' );

        $wpdb->insert( $table_pmts, [
            'booking_id'        => $booking_id,
            'customer_id'       => $booking['customer_id'],
            'payment_type'      => 'customer_payment',
            'amount'            => floatval( $amount ),
            'currency'          => 'USD',
            'payment_method'    => sanitize_text_field( $method ),
            'payment_reference' => sanitize_text_field( $reference ),
            'payment_date'      => current_time( 'Y-m-d' ),
            'notes'             => sanitize_textarea_field( $notes ),
            'recorded_by'       => get_current_user_id() ?: 1,
            'created_at'        => $now,
        ] );

        $payment_id = $wpdb->insert_id;

        // Recalculate booking status
        $paid = floatval( $wpdb->get_var( $wpdb->prepare( "SELECT SUM(amount) FROM {$table_pmts} WHERE booking_id = %d", $booking_id ) ) );
        $new_status = ( $paid >= $booking['total_selling_price'] ) ? 'paid' : ( $paid > 0 ? 'deposit_paid' : 'unpaid' );

        $table_bks = Outbound_CRM_Database::get_table( 'bookings' );
        $wpdb->update(
            $table_bks,
            [ 'payment_status' => $new_status, 'updated_at' => $now ],
            [ 'id' => $booking_id ]
        );

        Outbound_CRM_Database::log_activity( [
            'customer_id' => $booking['customer_id'],
            'booking_id'  => $booking_id,
            'log_type'    => 'payment_received',
            'title'       => sprintf( __( 'Payment of $%s received (%s)', 'outbound-headless' ), number_format( $amount, 2 ), $new_status ),
        ] );

        return $payment_id;
    }
}
endif;
