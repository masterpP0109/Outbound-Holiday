<?php
/**
 * Outbound Holidays CRM Quotations Management
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Outbound_CRM_Quotations' ) ) :
class Outbound_CRM_Quotations {

    public static function get_all( $limit = 100, $offset = 0 ) {
        global $wpdb;
        $table_quotes = Outbound_CRM_Database::get_table( 'quotations' );
        $table_cust   = Outbound_CRM_Database::get_table( 'customers' );
        $table_opps   = Outbound_CRM_Database::get_table( 'opportunities' );

        return $wpdb->get_results( $wpdb->prepare( "
            SELECT q.*, c.first_name, c.last_name, c.email, c.phone, c.whatsapp, o.reference as opp_ref
            FROM {$table_quotes} q
            LEFT JOIN {$table_cust} c ON q.customer_id = c.id
            LEFT JOIN {$table_opps} o ON q.opportunity_id = o.id
            ORDER BY q.id DESC
            LIMIT %d OFFSET %d
        ", $limit, $offset ), ARRAY_A );
    }

    public static function create( $opp_id, $data ) {
        global $wpdb;
        $opp = Outbound_CRM_Enquiries::get( $opp_id );
        if ( ! $opp ) {
            return false;
        }

        $total   = floatval( $data['total'] ?? 0 );
        $deposit = floatval( $data['deposit_required'] ?? ( $total * 0.3 ) );
        $q_ref   = 'Q-' . current_time( 'Ymd' ) . '-' . strtoupper( wp_generate_password( 4, false ) );
        $now     = current_time( 'mysql' );
        $valid   = date( 'Y-m-d', strtotime( '+14 days' ) );

        $items = [
            [
                'description' => sanitize_text_field( $data['item_desc'] ?? 'Victoria Falls Travel Package' ),
                'qty'         => intval( $data['item_qty'] ?? 1 ),
                'rate'        => $total,
                'amount'      => $total,
            ]
        ];

        $table_quotes = Outbound_CRM_Database::get_table( 'quotations' );
        $wpdb->insert( $table_quotes, [
            'quote_number'     => $q_ref,
            'opportunity_id'   => $opp_id,
            'customer_id'      => $opp['customer_id'],
            'status'           => 'sent',
            'valid_until'      => $valid,
            'subtotal'         => $total,
            'total'            => $total,
            'deposit_required' => $deposit,
            'currency'         => 'USD',
            'items_json'       => wp_json_encode( $items ),
            'inclusions'       => sanitize_textarea_field( $data['inclusions'] ?? '' ),
            'exclusions'       => sanitize_textarea_field( $data['exclusions'] ?? '' ),
            'terms'            => sanitize_textarea_field( $data['terms'] ?? 'Provisional quotation valid for 14 days.' ),
            'created_by'       => get_current_user_id() ?: 1,
            'created_at'       => $now,
            'updated_at'       => $now,
        ] );

        $quote_id = $wpdb->insert_id;

        // Advance opportunity to quote_sent
        Outbound_CRM_Enquiries::update_stage( $opp_id, 'quote_sent' );

        Outbound_CRM_Database::log_activity( [
            'customer_id'    => $opp['customer_id'],
            'opportunity_id' => $opp_id,
            'log_type'       => 'quote_created',
            'title'          => sprintf( __( 'Quotation %s generated ($%s)', 'outbound-headless' ), $q_ref, number_format( $total, 2 ) ),
        ] );

        return $quote_id;
    }
}
endif;
