<?php
/**
 * Outbound Holidays — Visual Content Studio Sections (Tabs 8 to 14)
 *
 * Renders:
 *  8. Testimonials & Reviews (reviews)
 *  9. About & Contact (about-contact)
 * 10. Header & Navigation (header-nav)
 * 11. Footer & Global Content (footer-global)
 * 12. Holiday Builder Settings (holiday-builder)
 * 13. Design & Layout (design-layout)
 * 14. SEO & Publishing (seo-publishing)
 *
 * @package OutboundHeadlessCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Outbound_CMS_Studio_Sections' ) ) :
class Outbound_CMS_Studio_Sections {

	/**
	 * Helper: Render a string field bound to site.editorial.strings[$key]
	 */
	public static function render_string_input( array $strings, string $key, string $label, bool $multiline = false, int $rows = 2, string $hint = '' ): void {
		$val = $strings[ $key ] ?? '';
		?>
		<div class="cms-field">
			<label><?php echo esc_html( $label ); ?> <code class="cms-key-pill"><?php echo esc_html( $key ); ?></code></label>
			<?php if ( $multiline ) : ?>
				<textarea name="strings[<?php echo esc_attr( $key ); ?>]" rows="<?php echo intval( $rows ); ?>"><?php echo esc_textarea( $val ); ?></textarea>
			<?php else : ?>
				<input type="text" name="strings[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $val ); ?>">
			<?php endif; ?>
			<?php if ( $hint ) : ?>
				<span class="cms-hint"><?php echo esc_html( $hint ); ?></span>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Helper: Render an image picker bound to site.editorial.structures[$key]
	 */
	public static function render_structure_image( array $structures, string $key, string $label ): void {
		$val = is_string( $structures[ $key ] ?? null ) ? $structures[ $key ] : '';
		?>
		<div class="cms-field">
			<label><?php echo esc_html( $label ); ?> <code class="cms-key-pill"><?php echo esc_html( $key ); ?></code></label>
			<div class="cms-media-picker">
				<div class="cms-media-preview">
					<?php if ( $val ) : ?>
						<img src="<?php echo esc_url( $val ); ?>" alt="">
					<?php else : ?>
						<span class="cms-no-img">No image</span>
					<?php endif; ?>
				</div>
				<div class="cms-media-controls">
					<input type="text" name="structure_images[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $val ); ?>" class="cms-media-url" placeholder="https://...">
					<button type="button" class="button cms-pick-media"><span class="dashicons dashicons-format-image"></span> Select / Upload</button>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * =========================================================================
	 * SECTION 8: TESTIMONIALS & REVIEWS
	 * =========================================================================
	 */
	public static function render_tab_reviews( array $snapshot ): void {
		$strings    = $snapshot['site']['editorial']['strings'] ?? [];
		$structures = $snapshot['site']['editorial']['structures'] ?? [];
		$stories    = $structures['travel/TravellerStories.section1'] ?? [];
		$reviews    = $snapshot['site']['legacy']['TRAVEL_REVIEWS'] ?? [];
		?>
		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>8A. Homepage Guest Stories Section Header</h2>
					<p>Controls the headings and trust copy on the Homepage Testimonials section (<code>TravellerStories.tsx</code>).</p>
				</div>
			</div>
			<div class="cms-grid-2">
				<?php
				self::render_string_input( $strings, 'travel/TravellerStories.text4', 'Section Eyebrow Label' );
				self::render_string_input( $strings, 'travel/TravellerStories.text5', 'Section Main Heading' );
				self::render_string_input( $strings, 'travel/TravellerStories.text6', 'Section Intro Description', true, 2 );
				self::render_string_input( $strings, 'travel/TravellerStories.text7', 'Bottom Reassurance / Verification Note' );
				?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>8B. Homepage Guest Story Cards (<?php echo count( $stories ); ?>)</h2>
					<p>These guest quote cards appear directly on the homepage in <code>TravellerStories.tsx</code>.</p>
				</div>
				<button type="button" class="button button-secondary" id="cms-add-story-btn">
					<span class="dashicons dashicons-plus-alt2"></span> Add Guest Story Card
				</button>
			</div>

			<div id="cms-stories-list" class="cms-accordion-list">
				<?php foreach ( $stories as $idx => $st ) : ?>
					<div class="cms-Repeater-Card cms-story-card" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:16px;margin-bottom:12px;">
						<div class="cms-flex-between" style="margin-bottom:10px;">
							<strong>Guest Story #<?php echo intval( $idx + 1 ); ?> — <?php echo esc_html( ( $st['initials'] ?? '' ) . ' (' . ( $st['type'] ?? '' ) . ')' ); ?></strong>
							<div class="cms-inline-actions">
								<button type="button" class="button button-small cms-move-up" title="Move Up">↑</button>
								<button type="button" class="button button-small cms-move-down" title="Move Down">↓</button>
								<button type="button" class="button-link-delete cms-remove-card">Remove</button>
							</div>
						</div>
						<div class="cms-grid-3">
							<div class="cms-field">
								<label>Guest Initials / Name</label>
								<input type="text" name="stories[<?php echo intval( $idx ); ?>][initials]" value="<?php echo esc_attr( $st['initials'] ?? '' ); ?>">
							</div>
							<div class="cms-field">
								<label>Trip Type (e.g. Family Trip, Honeymoon)</label>
								<input type="text" name="stories[<?php echo intval( $idx ); ?>][type]" value="<?php echo esc_attr( $st['type'] ?? '' ); ?>">
							</div>
							<div class="cms-field">
								<label>Guest Country / Location</label>
								<input type="text" name="stories[<?php echo intval( $idx ); ?>][location]" value="<?php echo esc_attr( $st['location'] ?? '' ); ?>">
							</div>
							<div class="cms-field cms-col-span-3">
								<label>Testimonial Quote</label>
								<textarea name="stories[<?php echo intval( $idx ); ?>][text]" rows="3"><?php echo esc_textarea( $st['text'] ?? '' ); ?></textarea>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>8C. Full Verified Traveller Reviews Catalogue (<?php echo count( $reviews ); ?>)</h2>
					<p>Structured review records stored in <code>site.legacy.TRAVEL_REVIEWS</code> with ratings, dates, avatars, and verified status.</p>
				</div>
				<button type="button" class="button button-secondary" id="cms-add-review-btn">
					<span class="dashicons dashicons-plus-alt2"></span> Add Verified Review
				</button>
			</div>

			<div id="cms-reviews-list" class="cms-accordion-list">
				<?php foreach ( $reviews as $idx => $rev ) : ?>
					<div class="cms-accordion-item cms-review-item <?php echo 0 === $idx ? 'is-open' : ''; ?>">
						<div class="cms-accordion-header">
							<div class="cms-acc-title-wrap">
								<div class="cms-acc-meta">
									<strong><?php echo esc_html( $rev['author'] ?? 'Guest' ); ?> — <?php echo esc_html( $rev['title'] ?? 'Review' ); ?></strong>
									<span><?php echo esc_html( ( $rev['roleOrCity'] ?? '' ) . ' • ' . ( $rev['rating'] ?? 5 ) . '★ • ' . ( $rev['date'] ?? '' ) ); ?></span>
								</div>
							</div>
							<div class="cms-acc-actions">
								<button type="button" class="button button-small cms-move-up" title="Move Up">↑</button>
								<button type="button" class="button button-small cms-move-down" title="Move Down">↓</button>
								<button type="button" class="button-link-delete cms-remove-card">Remove</button>
								<span class="dashicons dashicons-arrow-down-alt2 cms-acc-chevron"></span>
							</div>
						</div>
						<div class="cms-accordion-body">
							<input type="hidden" name="reviews[<?php echo intval( $idx ); ?>][id]" value="<?php echo esc_attr( $rev['id'] ?? 'rev-' . ( $idx + 1 ) ); ?>">
							<div class="cms-grid-3">
								<div class="cms-field">
									<label>Guest Name</label>
									<input type="text" name="reviews[<?php echo intval( $idx ); ?>][author]" value="<?php echo esc_attr( $rev['author'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>City / Traveller Role</label>
									<input type="text" name="reviews[<?php echo intval( $idx ); ?>][roleOrCity]" value="<?php echo esc_attr( $rev['roleOrCity'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Review Date Label</label>
									<input type="text" name="reviews[<?php echo intval( $idx ); ?>][date]" value="<?php echo esc_attr( $rev['date'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Review Title</label>
									<input type="text" name="reviews[<?php echo intval( $idx ); ?>][title]" value="<?php echo esc_attr( $rev['title'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Star Rating (1 to 5)</label>
									<input type="number" min="1" max="5" step="1" name="reviews[<?php echo intval( $idx ); ?>][rating]" value="<?php echo esc_attr( $rev['rating'] ?? 5 ); ?>">
								</div>
								<div class="cms-field cms-checkbox-field">
									<label>
										<input type="checkbox" name="reviews[<?php echo intval( $idx ); ?>][verifiedBuyer]" value="1" <?php checked( ! empty( $rev['verifiedBuyer'] ) ); ?>>
										Verified Outbound Traveller
									</label>
								</div>
								<div class="cms-field cms-col-span-3">
									<label>Full Review Comment</label>
									<textarea name="reviews[<?php echo intval( $idx ); ?>][comment]" rows="3"><?php echo esc_textarea( $rev['comment'] ?? '' ); ?></textarea>
								</div>
								<div class="cms-field cms-col-span-3">
									<label>Reviewer Avatar Image</label>
									<div class="cms-media-picker">
										<div class="cms-media-preview">
											<?php if ( ! empty( $rev['avatar'] ) ) : ?>
												<img src="<?php echo esc_url( $rev['avatar'] ); ?>" alt="">
											<?php else : ?>
												<span class="cms-no-img">No avatar</span>
											<?php endif; ?>
										</div>
										<div class="cms-media-controls">
											<input type="text" name="reviews[<?php echo intval( $idx ); ?>][avatar]" value="<?php echo esc_attr( $rev['avatar'] ?? '' ); ?>" class="cms-media-url">
											<button type="button" class="button cms-pick-media"><span class="dashicons dashicons-format-image"></span> Select Image</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * =========================================================================
	 * SECTION 9: ABOUT & CONTACT
	 * =========================================================================
	 */
	public static function render_tab_about_contact( array $snapshot ): void {
		$strings            = $snapshot['site']['editorial']['strings'] ?? [];
		$structures         = $snapshot['site']['editorial']['structures'] ?? [];
		$contact            = $snapshot['site']['contact'] ?? [];
		$notification_email = get_option( 'outbound_notification_email', 'travel@outboundholidays.co.zw' );
		$services           = $structures['travel/AboutPage.services'] ?? [];
		$principles         = $structures['travel/AboutPage.principles'] ?? [];
		?>
		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>9A. Business Contact Details & Enquiry Routing</h2>
					<p>Authoritative WhatsApp, phone, email, physical office address, and operating hours used across Header, Footer, Contact Us, and WhatsApp CTAs.</p>
				</div>
			</div>
			<div class="cms-grid-3">
				<div class="cms-field">
					<label>WhatsApp Number (Digits only, with country code)</label>
					<input type="text" name="contact[whatsappNumber]" value="<?php echo esc_attr( $contact['whatsappNumber'] ?? '263714701721' ); ?>">
					<span class="cms-hint">Used for all <code>wa.me/</code> links (e.g. 263714701721).</span>
				</div>
				<div class="cms-field">
					<label>Display Phone / WhatsApp Number</label>
					<input type="text" name="contact[displayNumber]" value="<?php echo esc_attr( $contact['displayNumber'] ?? '+263 714 701 721' ); ?>">
					<span class="cms-hint">Shown in Header, Footer, and Contact cards.</span>
				</div>
				<div class="cms-field">
					<label>Public Enquiries Email</label>
					<input type="email" name="contact[email]" value="<?php echo esc_attr( $contact['email'] ?? 'travel@outboundholidays.co.zw' ); ?>">
				</div>
				<div class="cms-field cms-col-span-2">
					<label>Physical Office Address (Victoria Falls)</label>
					<input type="text" name="contact[address]" value="<?php echo esc_attr( $contact['address'] ?? '' ); ?>">
					<span class="cms-hint">Automatically synchronizes with Footer and Contact Us page address display.</span>
				</div>
				<div class="cms-field">
					<label>Operating Hours</label>
					<input type="text" name="contact[hours]" value="<?php echo esc_attr( $contact['hours'] ?? '' ); ?>">
				</div>
				<div class="cms-field cms-col-span-3">
					<label>Internal Team Notification Email (WordPress Lead Alerts)</label>
					<input type="email" name="notification_email" value="<?php echo esc_attr( $notification_email ); ?>">
					<span class="cms-hint">New website enquiries & Holiday Builder requests are emailed here and logged in Outbound CRM.</span>
				</div>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>9B. About Page — Hero & Founder Story (Fungai)</h2>
					<p>Manage all photographs, biography paragraphs, and headings on <code>/about</code> (<code>AboutPage.tsx</code>).</p>
				</div>
			</div>
			<div class="cms-grid-3">
				<?php
				self::render_structure_image( $structures, 'travel/AboutPage.founderImage', 'Founder Portrait Image (Fungai)' );
				self::render_structure_image( $structures, 'travel/AboutPage.photo6', 'Why Outbound Feature Photo' );
				self::render_structure_image( $structures, 'travel/AboutPage.photo3', 'Personal Message Feature Photo' );
				?>
			</div>
			<div class="cms-grid-2" style="margin-top:16px;">
				<?php
				self::render_string_input( $strings, 'travel/AboutPage.text1', 'About Hero Eyebrow Badge' );
				self::render_string_input( $strings, 'travel/AboutPage.text2', 'About Hero Main Title' );
				self::render_string_input( $strings, 'travel/AboutPage.text3', 'About Hero Intro Paragraph', true, 3 );
				self::render_string_input( $strings, 'travel/AboutPage.text4', 'Hero Primary Button Label' );
				self::render_string_input( $strings, 'travel/AboutPage.text5', 'Hero Secondary Button Label' );
				self::render_string_input( $strings, 'travel/AboutPage.text12', 'Founder Section Eyebrow' );
				self::render_string_input( $strings, 'travel/AboutPage.text13', 'Founder Heading (Meet Fungai)' );
				self::render_string_input( $strings, 'travel/AboutPage.text14', 'Founder Role & Title' );
				self::render_string_input( $strings, 'travel/AboutPage.text15', 'Founder Biography Paragraph 1', true, 3 );
				self::render_string_input( $strings, 'travel/AboutPage.text16', 'Founder Biography Paragraph 2', true, 3 );
				self::render_string_input( $strings, 'travel/AboutPage.text17', 'Founder Biography Paragraph 3', true, 3 );
				self::render_string_input( $strings, 'travel/AboutPage.text18', 'Founder Biography Paragraph 4', true, 3 );
				self::render_string_input( $strings, 'travel/AboutPage.text19', 'Founder Highlight Quote Callout', true, 2 );
				self::render_string_input( $strings, 'travel/AboutPage.text20', 'Why Outbound Eyebrow' );
				self::render_string_input( $strings, 'travel/AboutPage.text21', 'Why Outbound Heading' );
				self::render_string_input( $strings, 'travel/AboutPage.text22', 'Why Outbound Paragraph 1', true, 3 );
				self::render_string_input( $strings, 'travel/AboutPage.text23', 'Why Outbound Paragraph 2', true, 3 );
				self::render_string_input( $strings, 'travel/AboutPage.text24', 'Why Outbound Paragraph 3', true, 2 );
				self::render_string_input( $strings, 'travel/AboutPage.text32', 'Personal Message Eyebrow' );
				self::render_string_input( $strings, 'travel/AboutPage.text33', 'Personal Message Heading' );
				self::render_string_input( $strings, 'travel/AboutPage.text34', 'Personal Message Paragraph 1', true, 3 );
				self::render_string_input( $strings, 'travel/AboutPage.text35', 'Personal Message Paragraph 2', true, 3 );
				self::render_string_input( $strings, 'travel/AboutPage.text36', 'Signature Name' );
				self::render_string_input( $strings, 'travel/AboutPage.text37', 'Signature Title' );
				self::render_string_input( $strings, 'travel/AboutPage.text46', 'Bottom CTA Eyebrow' );
				self::render_string_input( $strings, 'travel/AboutPage.text47', 'Bottom CTA Heading' );
				self::render_string_input( $strings, 'travel/AboutPage.text48', 'Bottom CTA Description', true, 2 );
				self::render_string_input( $strings, 'travel/AboutPage.text49', 'Bottom CTA Primary Button' );
				?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>9C. About Page — Services & Principles Cards</h2>
					<p>Edit the "How I Help" service cards and "How We Work" principle cards on <code>/about</code>.</p>
				</div>
			</div>
			<h3 style="margin:0 0 12px;">How I Help — Service Cards (<?php echo count( $services ); ?>)</h3>
			<div class="cms-grid-2">
				<?php foreach ( $services as $idx => $srv ) : ?>
					<div class="cms-subcard" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px;">
						<div class="cms-field">
							<label>Service #<?php echo intval( $idx + 1 ); ?> Title</label>
							<input type="text" name="about_services[<?php echo intval( $idx ); ?>][title]" value="<?php echo esc_attr( $srv['title'] ?? '' ); ?>">
						</div>
						<div class="cms-field" style="margin-top:8px;">
							<label>Description</label>
							<textarea name="about_services[<?php echo intval( $idx ); ?>][copy]" rows="2"><?php echo esc_textarea( $srv['copy'] ?? '' ); ?></textarea>
						</div>
					</div>
				<?php endforeach; ?>
			</div>

			<h3 style="margin:24px 0 12px;">Our Principles Cards (<?php echo count( $principles ); ?>)</h3>
			<div class="cms-grid-2">
				<?php foreach ( $principles as $idx => $pr ) : ?>
					<div class="cms-subcard" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px;">
						<div class="cms-field">
							<label>Principle #<?php echo intval( $idx + 1 ); ?> Title</label>
							<input type="text" name="about_principles[<?php echo intval( $idx ); ?>][title]" value="<?php echo esc_attr( $pr['title'] ?? '' ); ?>">
						</div>
						<div class="cms-field" style="margin-top:8px;">
							<label>Description</label>
							<textarea name="about_principles[<?php echo intval( $idx ); ?>][copy]" rows="2"><?php echo esc_textarea( $pr['copy'] ?? '' ); ?></textarea>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>9D. Contact Us Page Copy & Form Labels (<code>/contact</code>)</h2>
					<p>Edit every heading, label, and message displayed on <code>ContactUsView.tsx</code>.</p>
				</div>
			</div>
			<div class="cms-grid-2">
				<?php
				self::render_string_input( $strings, 'travel/ContactUsView.text1', 'Contact Hero Badge' );
				self::render_string_input( $strings, 'travel/ContactUsView.text2', 'Contact Hero Heading' );
				self::render_string_input( $strings, 'travel/ContactUsView.text3', 'Contact Hero Subtitle', true, 2 );
				self::render_string_input( $strings, 'travel/ContactUsView.text4', 'Direct Contact Section Heading' );
				self::render_string_input( $strings, 'travel/ContactUsView.text5', 'Direct Contact Intro', true, 2 );
				self::render_string_input( $strings, 'travel/ContactUsView.text6', 'Office Address Label' );
				self::render_string_input( $strings, 'travel/ContactUsView.text7', 'Office Address Value' );
				self::render_string_input( $strings, 'travel/ContactUsView.text8', 'Phone / WhatsApp Label' );
				self::render_string_input( $strings, 'travel/ContactUsView.text9', 'Email Address Label' );
				self::render_string_input( $strings, 'travel/ContactUsView.text10', 'Operating Hours Label' );
				self::render_string_input( $strings, 'travel/ContactUsView.text11', 'Operating Hours Value' );
				self::render_string_input( $strings, 'travel/ContactUsView.text12', 'Instant WhatsApp Box Heading' );
				self::render_string_input( $strings, 'travel/ContactUsView.text13', 'Instant WhatsApp Box Description', true, 2 );
				self::render_string_input( $strings, 'travel/ContactUsView.text14', 'Instant WhatsApp Button Text' );
				self::render_string_input( $strings, 'travel/ContactUsView.text15', 'Enquiry Form Heading' );
				self::render_string_input( $strings, 'travel/ContactUsView.text23', 'Enquiry Submit Button Text' );
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * =========================================================================
	 * SECTION 10: HEADER & NAVIGATION
	 * =========================================================================
	 */
	public static function render_tab_header_nav( array $snapshot ): void {
		$strings    = $snapshot['site']['editorial']['strings'] ?? [];
		$structures = $snapshot['site']['editorial']['structures'] ?? [];
		$rates      = $snapshot['site']['currencyRates'] ?? [];
		$nav_cfg    = $structures['cms/navigation'] ?? [
			'showGuide'         => true,
			'showExperiences'   => true,
			'showAccommodation' => true,
			'showPackages'      => true,
			'showGallery'       => true,
			'showAbout'         => true,
			'showContact'       => true,
		];
		?>
		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>10A. Top Announcement Bar & Brand Logo</h2>
					<p>Controls the top announcement strip, brand logo, search bar placeholders, and primary CTA button in <code>Header.tsx</code>.</p>
				</div>
			</div>
			<div class="cms-grid-2">
				<?php
				self::render_structure_image( $structures, 'common/Header.outboundLogo', 'Header Brand Logo Image' );
				self::render_string_input( $strings, 'common/Header.text4', 'Brand Logo Alt Text' );
				self::render_string_input( $strings, 'common/Header.text1', 'Top Bar Highlight Badge (e.g. Victoria Falls Specialists)' );
				self::render_string_input( $strings, 'common/Header.text2', 'Top Bar Announcement Tagline' );
				self::render_string_input( $strings, 'common/Header.text3', 'Top Bar Phone Prefix (e.g. Talk to a Local Specialist: )' );
				self::render_string_input( $strings, 'common/Header.text13', 'Primary Header CTA Button Label (e.g. Plan My Holiday)' );
				self::render_string_input( $strings, 'common/Header.text12', 'Desktop Search Placeholder' );
				self::render_string_input( $strings, 'common/Header.text14', 'Mobile Search Placeholder' );
				?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>10B. Navigation Menu Items (Desktop & Mobile Labels + Visibility)</h2>
					<p>Edit desktop and mobile menu labels and toggle visibility for each navigation item.</p>
				</div>
			</div>
			<div class="cms-grid-2">
				<?php
				$nav_items = [
					[ 'toggle' => 'showGuide',         'title' => '1. Victoria Falls Guide', 'desk' => 'common/Header.text5',  'mob' => 'common/Header.text15' ],
					[ 'toggle' => 'showExperiences',   'title' => '2. Experiences',          'desk' => 'common/Header.text6',  'mob' => 'common/Header.text17' ],
					[ 'toggle' => 'showAccommodation', 'title' => '3. Where to Stay',        'desk' => 'common/Header.text7',  'mob' => 'common/Header.text18' ],
					[ 'toggle' => 'showPackages',      'title' => '4. Holiday Packages',     'desk' => 'common/Header.text8',  'mob' => 'common/Header.text19' ],
					[ 'toggle' => 'showGallery',       'title' => '5. Client Gallery',       'desk' => 'common/Header.text9',  'mob' => 'common/Header.text20' ],
					[ 'toggle' => 'showAbout',         'title' => '6. About Us',             'desk' => 'common/Header.text10', 'mob' => 'common/Header.text22' ],
					[ 'toggle' => 'showContact',       'title' => '7. Contact Us',           'desk' => 'common/Header.text11', 'mob' => 'common/Header.text24' ],
				];
				foreach ( $nav_items as $item ) :
					$is_vis = ! isset( $nav_cfg[ $item['toggle'] ] ) || ! empty( $nav_cfg[ $item['toggle'] ] );
					?>
					<div class="cms-subcard" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px;">
						<div class="cms-flex-between" style="margin-bottom:10px;">
							<strong><?php echo esc_html( $item['title'] ); ?></strong>
							<label style="font-size:12px;font-weight:600;display:flex;align-items:center;gap:6px;">
								<input type="checkbox" name="nav_config[<?php echo esc_attr( $item['toggle'] ); ?>]" value="1" <?php checked( $is_vis ); ?>>
								Visible in Menu
							</label>
						</div>
						<div class="cms-grid-2">
							<?php
							self::render_string_input( $strings, $item['desk'], 'Desktop Menu Label' );
							self::render_string_input( $strings, $item['mob'], 'Mobile Menu Label' );
							?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>10C. Currency Switcher & Live Exchange Rates</h2>
					<p>Configure conversion multipliers relative to USD (1.00) used by the Header currency switcher across Stays and Packages.</p>
				</div>
			</div>
			<div class="cms-grid-4">
				<?php foreach ( [ 'USD', 'EUR', 'GBP', 'ZAR' ] as $code ) :
					$r = $rates[ $code ] ?? [ 'symbol' => '$', 'rate' => 1 ];
					?>
					<div class="cms-rate-card">
						<h4><?php echo esc_html( $code ); ?></h4>
						<div class="cms-field">
							<label>Currency Symbol</label>
							<input type="text" name="rates[<?php echo esc_attr( $code ); ?>][symbol]" value="<?php echo esc_attr( $r['symbol'] ?? '' ); ?>">
						</div>
						<div class="cms-field">
							<label>Rate per 1 USD</label>
							<input type="number" step="0.01" name="rates[<?php echo esc_attr( $code ); ?>][rate]" value="<?php echo esc_attr( $r['rate'] ?? 1 ); ?>">
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * =========================================================================
	 * SECTION 11: FOOTER & GLOBAL CONTENT
	 * =========================================================================
	 */
	public static function render_tab_footer_global( array $snapshot ): void {
		$strings    = $snapshot['site']['editorial']['strings'] ?? [];
		$structures = $snapshot['site']['editorial']['structures'] ?? [];
		$wa_tpls    = $structures['cms/whatsappTemplates'] ?? [
			'defaultGreeting'           => "Hello Outbound Holidays,\n\nI'm interested in {{item}} and would like to know its availability, pricing and how to book.",
			'specialistTopicTemplate'   => "Hello Outbound Holidays,\n\nI need some help planning my Victoria Falls trip regarding {{topic}}. Could I speak with a Victoria Falls travel specialist?\n\nThank you.",
			'specialistGeneralTemplate' => "Hello Outbound Holidays,\n\nI need some help choosing the right experiences for my Victoria Falls trip. Could I speak with a Victoria Falls travel specialist?\n\nThank you.",
			'closingLine'               => 'Thank you.',
		];
		?>
		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>11A. Footer Branding, Panoramic Backdrop & Columns (<code>Footer.tsx</code>)</h2>
					<p>Manage the footer logo, panoramic Zambezi backdrop photo, brand summary, column headings, links, payment badges, and copyright text.</p>
				</div>
			</div>
			<div class="cms-grid-2">
				<?php
				self::render_structure_image( $structures, 'common/Footer.outboundLogo', 'Footer Brand Logo' );
				self::render_structure_image( $structures, 'common/Footer.cruise1', 'Footer Panoramic Backdrop Image' );
				self::render_string_input( $strings, 'common/Footer.text1', 'Footer Backdrop Image Alt Text' );
				self::render_string_input( $strings, 'common/Footer.text2', 'Footer Logo Alt Text' );
				self::render_string_input( $strings, 'common/Footer.text3', 'Footer Brand Summary Paragraph', true, 3 );
				self::render_string_input( $strings, 'common/Footer.text4', 'Footer Office Address Text' );
				self::render_string_input( $strings, 'common/Footer.text5', 'Footer Phone Prefix' );
				self::render_string_input( $strings, 'common/Footer.text6', 'Column 1 Heading (Explore Victoria Falls)' );
				self::render_string_input( $strings, 'common/Footer.text7', 'Column 1 Link 1 (Victoria Falls Travel Guide)' );
				self::render_string_input( $strings, 'common/Footer.text8', 'Column 1 Link 2 (Things to Do & Activities)' );
				self::render_string_input( $strings, 'common/Footer.text9', 'Column 1 Link 3 (Where to Stay — Hotels & Lodges)' );
				self::render_string_input( $strings, 'common/Footer.text10', 'Column 1 Link 4 (Curated Holiday Packages)' );
				self::render_string_input( $strings, 'common/Footer.text11', 'Column 1 Link 5 (Custom Holiday Builder)' );
				self::render_string_input( $strings, 'common/Footer.text12', 'Column 2 Heading (Company & Support)' );
				self::render_string_input( $strings, 'common/Footer.text13', 'Column 2 Link 1 (About Outbound Holidays)' );
				self::render_string_input( $strings, 'common/Footer.text14', 'Column 2 Link 2 (Client Memories Gallery)' );
				self::render_string_input( $strings, 'common/Footer.text15', 'Column 2 Link 3 (Contact Our Local Team)' );
				self::render_string_input( $strings, 'common/Footer.text16', 'Column 2 Link 4 (Chat on WhatsApp)' );
				self::render_string_input( $strings, 'common/Footer.text17', 'Copyright Notice Text' );
				self::render_string_input( $strings, 'common/Footer.text18', 'Footer Primary CTA Button Text' );
				self::render_string_input( $strings, 'common/Footer.text19', 'Payment Badge 1 (e.g. Visa)' );
				self::render_string_input( $strings, 'common/Footer.text20', 'Payment Badge 2 (e.g. Mastercard)' );
				self::render_string_input( $strings, 'common/Footer.text21', 'Payment Badge 3 (e.g. Bank Transfer)' );
				self::render_string_input( $strings, 'common/Footer.text22', 'Payment Badge 4 (e.g. Cash on Arrival)' );
				?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>11B. Global Newsletter Signup Section (<code>Newsletter.tsx</code>)</h2>
					<p>Edit the newsletter heading, description, consent text, and button label shown above the footer.</p>
				</div>
			</div>
			<div class="cms-grid-2">
				<?php
				self::render_string_input( $strings, 'common/Newsletter.text1', 'Newsletter Eyebrow Badge' );
				self::render_string_input( $strings, 'common/Newsletter.text2', 'Newsletter Main Heading' );
				self::render_string_input( $strings, 'common/Newsletter.text3', 'Newsletter Description', true, 2 );
				self::render_string_input( $strings, 'common/Newsletter.text4', 'Email Input Placeholder' );
				self::render_string_input( $strings, 'common/Newsletter.text5', 'Subscribe Button Label' );
				self::render_string_input( $strings, 'common/Newsletter.text6', 'Marketing Consent Checkbox Label', true, 2 );
				self::render_string_input( $strings, 'common/Newsletter.text7', 'Privacy Reassurance Footnote' );
				?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>11C. Mobile Sticky Bottom CTA Bar (<code>MobileStickyCta.tsx</code>)</h2>
					<p>Controls the two action buttons fixed at the bottom of mobile screens.</p>
				</div>
			</div>
			<div class="cms-grid-2">
				<?php
				self::render_string_input( $strings, 'common/MobileStickyCta.text1', 'Left WhatsApp Button Label' );
				self::render_string_input( $strings, 'common/MobileStickyCta.text2', 'Right Plan Holiday Button Label' );
				?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>11D. Global WhatsApp Enquiry Message Templates (<code>whatsapp.ts</code>)</h2>
					<p>Customize the pre-filled WhatsApp messages opened when travellers click WhatsApp enquiry buttons across the website.</p>
				</div>
			</div>
			<div class="cms-grid-2">
				<div class="cms-field">
					<label>Experience / Activity Enquiry Template (use <code>{{item}}</code> for item name)</label>
					<textarea name="whatsapp_templates[defaultGreeting]" rows="3"><?php echo esc_textarea( $wa_tpls['defaultGreeting'] ?? '' ); ?></textarea>
				</div>
				<div class="cms-field">
					<label>Specialist Topic Consultation Template (use <code>{{topic}}</code> for topic)</label>
					<textarea name="whatsapp_templates[specialistTopicTemplate]" rows="3"><?php echo esc_textarea( $wa_tpls['specialistTopicTemplate'] ?? '' ); ?></textarea>
				</div>
				<div class="cms-field">
					<label>General Specialist Consultation Template</label>
					<textarea name="whatsapp_templates[specialistGeneralTemplate]" rows="3"><?php echo esc_textarea( $wa_tpls['specialistGeneralTemplate'] ?? '' ); ?></textarea>
				</div>
				<div class="cms-field">
					<label>Message Closing Sign-off Line</label>
					<input type="text" name="whatsapp_templates[closingLine]" value="<?php echo esc_attr( $wa_tpls['closingLine'] ?? 'Thank you.' ); ?>">
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * =========================================================================
	 * SECTION 12: HOLIDAY BUILDER SETTINGS
	 * =========================================================================
	 */
	public static function render_tab_holiday_builder( array $snapshot ): void {
		$strings            = $snapshot['site']['editorial']['strings'] ?? [];
		$structures         = $snapshot['site']['editorial']['structures'] ?? [];
		$stay_tiers         = $snapshot['stayTiers'] ?? [];
		$builder_activities = $snapshot['builderActivities'] ?? [];
		$intents            = $structures['travel/HolidayBuilderModal.section1'] ?? [];
		$parties            = $structures['travel/HolidayBuilderModal.section2'] ?? [];
		$durations          = $structures['travel/HolidayBuilderModal.section3'] ?? [];
		$seasons            = $structures['travel/HolidayBuilderModal.section4'] ?? [];
		$stay_prefs         = $structures['travel/HolidayBuilderModal.section5'] ?? [];
		$transfers          = $structures['travel/HolidayBuilderModal.section6'] ?? [];
		?>
		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>12A. Holiday Builder — Accommodation Stay Tiers (<?php echo count( $stay_tiers ); ?>)</h2>
					<p>Manage the accommodation comfort tiers and per-night USD estimates in Step 2 of the interactive Holiday Builder modal.</p>
				</div>
				<button type="button" class="button button-secondary" id="cms-add-tier-btn">
					<span class="dashicons dashicons-plus-alt2"></span> Add Stay Tier
				</button>
			</div>
			<div id="cms-tiers-list" class="cms-accordion-list">
				<?php foreach ( $stay_tiers as $idx => $tier ) : ?>
					<div class="cms-accordion-item <?php echo 0 === $idx ? 'is-open' : ''; ?>">
						<div class="cms-accordion-header">
							<div class="cms-acc-title-wrap">
								<?php if ( ! empty( $tier['imageUrl'] ) ) : ?>
									<img src="<?php echo esc_url( $tier['imageUrl'] ); ?>" class="cms-acc-thumb" alt="">
								<?php endif; ?>
								<div class="cms-acc-meta">
									<strong><?php echo esc_html( $tier['name'] ?? 'Stay Tier' ); ?></strong>
									<span>$<?php echo esc_html( $tier['pricePerNightUSD'] ?? 0 ); ?> / night • <?php echo esc_html( $tier['tagline'] ?? '' ); ?></span>
								</div>
							</div>
							<div class="cms-acc-actions">
								<button type="button" class="button button-small cms-move-up" title="Move Up">↑</button>
								<button type="button" class="button button-small cms-move-down" title="Move Down">↓</button>
								<button type="button" class="button-link-delete cms-remove-card">Remove</button>
								<span class="dashicons dashicons-arrow-down-alt2 cms-acc-chevron"></span>
							</div>
						</div>
						<div class="cms-accordion-body">
							<div class="cms-grid-3">
								<div class="cms-field">
									<label>Tier ID</label>
									<input type="text" name="tiers[<?php echo intval( $idx ); ?>][id]" value="<?php echo esc_attr( $tier['id'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Tier Name</label>
									<input type="text" name="tiers[<?php echo intval( $idx ); ?>][name]" value="<?php echo esc_attr( $tier['name'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Est. Price Per Night (USD)</label>
									<input type="number" name="tiers[<?php echo intval( $idx ); ?>][pricePerNightUSD]" value="<?php echo esc_attr( $tier['pricePerNightUSD'] ?? 0 ); ?>">
								</div>
								<div class="cms-field cms-col-span-3">
									<label>Tagline</label>
									<input type="text" name="tiers[<?php echo intval( $idx ); ?>][tagline]" value="<?php echo esc_attr( $tier['tagline'] ?? '' ); ?>">
								</div>
								<div class="cms-field cms-col-span-3">
									<label>Description</label>
									<textarea name="tiers[<?php echo intval( $idx ); ?>][desc]" rows="2"><?php echo esc_textarea( $tier['desc'] ?? '' ); ?></textarea>
								</div>
								<div class="cms-field cms-col-span-2">
									<label>Tier Image</label>
									<div class="cms-media-picker">
										<div class="cms-media-preview">
											<?php if ( ! empty( $tier['imageUrl'] ) ) : ?>
												<img src="<?php echo esc_url( $tier['imageUrl'] ); ?>" alt="">
											<?php endif; ?>
										</div>
										<div class="cms-media-controls">
											<input type="text" name="tiers[<?php echo intval( $idx ); ?>][imageUrl]" value="<?php echo esc_attr( $tier['imageUrl'] ?? '' ); ?>" class="cms-media-url">
											<button type="button" class="button cms-pick-media"><span class="dashicons dashicons-format-image"></span> Select Image</button>
										</div>
									</div>
								</div>
								<div class="cms-field">
									<label>Highlights (One per line)</label>
									<textarea name="tiers[<?php echo intval( $idx ); ?>][highlights_raw]" rows="3"><?php echo esc_textarea( implode( "\n", $tier['highlights'] ?? [] ) ); ?></textarea>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>12B. Holiday Builder — Selectable Activities & Pricing (<?php echo count( $builder_activities ); ?>)</h2>
					<p>Manage the interactive activities and per-person USD prices in Step 3 of the Holiday Builder modal.</p>
				</div>
				<button type="button" class="button button-secondary" id="cms-add-bact-btn">
					<span class="dashicons dashicons-plus-alt2"></span> Add Builder Activity
				</button>
			</div>
			<div id="cms-bacts-list" class="cms-accordion-list">
				<?php foreach ( $builder_activities as $idx => $act ) : ?>
					<div class="cms-accordion-item">
						<div class="cms-accordion-header">
							<div class="cms-acc-title-wrap">
								<?php if ( ! empty( $act['imageUrl'] ) ) : ?>
									<img src="<?php echo esc_url( $act['imageUrl'] ); ?>" class="cms-acc-thumb" alt="">
								<?php endif; ?>
								<div class="cms-acc-meta">
									<strong><?php echo esc_html( $act['title'] ?? 'Activity' ); ?></strong>
									<span>$<?php echo esc_html( $act['priceUSD'] ?? 0 ); ?> pp • <?php echo esc_html( $act['duration'] ?? '' ); ?> • <?php echo esc_html( $act['badge'] ?? '' ); ?></span>
								</div>
							</div>
							<div class="cms-acc-actions">
								<button type="button" class="button button-small cms-move-up" title="Move Up">↑</button>
								<button type="button" class="button button-small cms-move-down" title="Move Down">↓</button>
								<button type="button" class="button-link-delete cms-remove-card">Remove</button>
								<span class="dashicons dashicons-arrow-down-alt2 cms-acc-chevron"></span>
							</div>
						</div>
						<div class="cms-accordion-body">
							<div class="cms-grid-4">
								<div class="cms-field">
									<label>Activity ID</label>
									<input type="text" name="bacts[<?php echo intval( $idx ); ?>][id]" value="<?php echo esc_attr( $act['id'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Activity Title</label>
									<input type="text" name="bacts[<?php echo intval( $idx ); ?>][title]" value="<?php echo esc_attr( $act['title'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Price Per Person (USD)</label>
									<input type="number" name="bacts[<?php echo intval( $idx ); ?>][priceUSD]" value="<?php echo esc_attr( $act['priceUSD'] ?? 0 ); ?>">
								</div>
								<div class="cms-field">
									<label>Duration</label>
									<input type="text" name="bacts[<?php echo intval( $idx ); ?>][duration]" value="<?php echo esc_attr( $act['duration'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Badge Label</label>
									<input type="text" name="bacts[<?php echo intval( $idx ); ?>][badge]" value="<?php echo esc_attr( $act['badge'] ?? '' ); ?>">
								</div>
								<div class="cms-field cms-col-span-3">
									<label>Ideal For Tags (Comma-separated)</label>
									<input type="text" name="bacts[<?php echo intval( $idx ); ?>][idealFor_csv]" value="<?php echo esc_attr( implode( ', ', $act['idealFor'] ?? [] ) ); ?>">
								</div>
								<div class="cms-field cms-col-span-2">
									<label>Short Description</label>
									<textarea name="bacts[<?php echo intval( $idx ); ?>][shortDesc]" rows="2"><?php echo esc_textarea( $act['shortDesc'] ?? '' ); ?></textarea>
								</div>
								<div class="cms-field cms-col-span-2">
									<label>Why We Recommend</label>
									<textarea name="bacts[<?php echo intval( $idx ); ?>][whyRecommend]" rows="2"><?php echo esc_textarea( $act['whyRecommend'] ?? '' ); ?></textarea>
								</div>
								<div class="cms-field cms-col-span-4">
									<label>Activity Photo</label>
									<div class="cms-media-picker">
										<div class="cms-media-preview">
											<?php if ( ! empty( $act['imageUrl'] ) ) : ?>
												<img src="<?php echo esc_url( $act['imageUrl'] ); ?>" alt="">
											<?php endif; ?>
										</div>
										<div class="cms-media-controls">
											<input type="text" name="bacts[<?php echo intval( $idx ); ?>][imageUrl]" value="<?php echo esc_attr( $act['imageUrl'] ?? '' ); ?>" class="cms-media-url">
											<button type="button" class="button cms-pick-media"><span class="dashicons dashicons-format-image"></span> Select Image</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>12C. Builder Wizard Options (Trip Vision, Party Types, Durations, Seasons, Transfers & Photos)</h2>
					<p>Customize the interactive choices and specialist advice inside <code>HolidayBuilderModal.tsx</code>.</p>
				</div>
			</div>

			<div class="cms-grid-2" style="margin-bottom:18px;">
				<?php
				self::render_structure_image( $structures, 'travel/HolidayBuilderModal.fallsTour1', 'Builder Hero Photo — First-Time / Falls' );
				self::render_structure_image( $structures, 'travel/HolidayBuilderModal.cruise1', 'Builder Hero Photo — Romantic / River' );
				self::render_structure_image( $structures, 'travel/HolidayBuilderModal.bungee1', 'Builder Hero Photo — Adventure' );
				self::render_structure_image( $structures, 'travel/HolidayBuilderModal.gameDrive10', 'Builder Hero Photo — Safari' );
				?>
			</div>

			<h3 style="margin:16px 0 10px;">Step 1: Trip Vision Options (<code>section1</code>)</h3>
			<div class="cms-grid-2">
				<?php foreach ( $intents as $idx => $it ) : ?>
					<div class="cms-subcard" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px;">
						<input type="hidden" name="builder_intents[<?php echo intval( $idx ); ?>][id]" value="<?php echo esc_attr( $it['id'] ?? '' ); ?>">
						<div class="cms-grid-3">
							<div class="cms-field">
								<label>Emoji / Icon</label>
								<input type="text" name="builder_intents[<?php echo intval( $idx ); ?>][icon]" value="<?php echo esc_attr( $it['icon'] ?? '' ); ?>">
							</div>
							<div class="cms-field cms-col-span-2">
								<label>Title</label>
								<input type="text" name="builder_intents[<?php echo intval( $idx ); ?>][title]" value="<?php echo esc_attr( $it['title'] ?? '' ); ?>">
							</div>
							<div class="cms-field cms-col-span-3">
								<label>Description</label>
								<input type="text" name="builder_intents[<?php echo intval( $idx ); ?>][desc]" value="<?php echo esc_attr( $it['desc'] ?? '' ); ?>">
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>

			<h3 style="margin:20px 0 10px;">Step 1: Duration Options (<code>section3</code>) & Stay Preferences (<code>section5</code>)</h3>
			<div class="cms-grid-2">
				<div>
					<?php foreach ( $durations as $idx => $dur ) : ?>
						<div class="cms-grid-3" style="margin-bottom:8px;background:#f8fafc;padding:10px;border-radius:8px;border:1px solid #e2e8f0;">
							<div class="cms-field">
								<label>Nights</label>
								<input type="number" name="builder_durations[<?php echo intval( $idx ); ?>][nights]" value="<?php echo esc_attr( $dur['nights'] ?? 3 ); ?>">
							</div>
							<div class="cms-field">
								<label>Label</label>
								<input type="text" name="builder_durations[<?php echo intval( $idx ); ?>][label]" value="<?php echo esc_attr( $dur['label'] ?? '' ); ?>">
							</div>
							<div class="cms-field">
								<label>Badge</label>
								<input type="text" name="builder_durations[<?php echo intval( $idx ); ?>][badge]" value="<?php echo esc_attr( $dur['badge'] ?? '' ); ?>">
							</div>
						</div>
					<?php endforeach; ?>
				</div>
				<div class="cms-field">
					<label>Step 2 Stay Preference Pills (One per line)</label>
					<textarea name="builder_stay_prefs_raw" rows="8"><?php echo esc_textarea( implode( "\n", is_array( $stay_prefs ) ? $stay_prefs : [] ) ); ?></textarea>
				</div>
			</div>

			<h3 style="margin:20px 0 10px;">Step 3: Airport & Local Transfer Options (<code>section6</code>)</h3>
			<div class="cms-grid-3">
				<?php foreach ( $transfers as $idx => $tr ) : ?>
					<div class="cms-subcard" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px;">
						<input type="hidden" name="builder_transfers[<?php echo intval( $idx ); ?>][id]" value="<?php echo esc_attr( $tr['id'] ?? '' ); ?>">
						<div class="cms-field">
							<label>Transfer Option Title</label>
							<input type="text" name="builder_transfers[<?php echo intval( $idx ); ?>][title]" value="<?php echo esc_attr( $tr['title'] ?? '' ); ?>">
						</div>
						<div class="cms-field" style="margin-top:6px;">
							<label>Badge</label>
							<input type="text" name="builder_transfers[<?php echo intval( $idx ); ?>][badge]" value="<?php echo esc_attr( $tr['badge'] ?? '' ); ?>">
						</div>
						<div class="cms-field" style="margin-top:6px;">
							<label>Description</label>
							<textarea name="builder_transfers[<?php echo intval( $idx ); ?>][desc]" rows="2"><?php echo esc_textarea( $tr['desc'] ?? '' ); ?></textarea>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * =========================================================================
	 * SECTION 13: DESIGN & LAYOUT
	 * =========================================================================
	 */
	public static function render_tab_design_layout( array $snapshot ): void {
		$structures = $snapshot['site']['editorial']['structures'] ?? [];
		$layout     = $structures['cms/designLayout'] ?? [];

		$default_sections = [
			[ 'id' => 'hero',                'label' => '1. Hero Banner & Carousel (TravelHero)',              'visible' => true ],
			[ 'id' => 'quickPlanning',       'label' => '2. Quick Planning Bar (QuickPlanningBar)',            'visible' => true ],
			[ 'id' => 'whyChoose',           'label' => '3. Why Plan With Outbound (WhyChooseOutbound)',       'visible' => true ],
			[ 'id' => 'featuredExperiences', 'label' => '4. Signature Experiences (FeaturedExperiences)',      'visible' => true ],
			[ 'id' => 'whereToStay',         'label' => '5. Where to Stay in Victoria Falls (WhereToStay)',    'visible' => true ],
			[ 'id' => 'vicFallsGuide',       'label' => '6. Victoria Falls Guide Preview (VicFallsGuide)',     'visible' => true ],
			[ 'id' => 'featuredPackages',    'label' => '7. Curated Holiday Packages (FeaturedPackages)',      'visible' => true ],
			[ 'id' => 'travellerStories',    'label' => '8. Guest Stories & Testimonials (TravellerStories)',  'visible' => true ],
			[ 'id' => 'clientGallery',       'label' => '9. Client Memories Gallery Preview (ClientGallery)',  'visible' => true ],
			[ 'id' => 'howWeHelp',           'label' => '10. How We Help Services (HowWeHelp)',                'visible' => true ],
			[ 'id' => 'finalCta',            'label' => '11. Final Call-To-Action Banner (FinalCtaBanner)',    'visible' => true ],
		];

		$label_map = array_column( $default_sections, 'label', 'id' );
		$sections  = ! empty( $layout['homepageSections'] ) && is_array( $layout['homepageSections'] )
			? $layout['homepageSections']
			: $default_sections;
		?>
		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>13A. Homepage Section Ordering & Visibility</h2>
					<p>Reorder homepage sections or toggle their visibility. The React homepage (<code>App.tsx</code>) renders sections in this exact order.</p>
				</div>
			</div>

			<div id="cms-homepage-sections-list" class="cms-accordion-list">
				<?php foreach ( $sections as $idx => $sec ) :
					$sec_id  = $sec['id'] ?? '';
					$sec_lbl = $label_map[ $sec_id ] ?? ( $sec['label'] ?? $sec_id );
					$is_vis  = ! isset( $sec['visible'] ) || ! empty( $sec['visible'] );
					?>
					<div class="cms-section-order-row" style="display:flex;align-items:center;justify-content:space-between;background:#f8fafc;border:1px solid #cbd5e1;border-radius:10px;padding:12px 16px;margin-bottom:8px;">
						<div style="display:flex;align-items:center;gap:12px;">
							<span class="dashicons dashicons-menu" style="color:#64748b;"></span>
							<input type="hidden" name="homepage_sections[<?php echo intval( $idx ); ?>][id]" value="<?php echo esc_attr( $sec_id ); ?>">
							<input type="hidden" name="homepage_sections[<?php echo intval( $idx ); ?>][label]" value="<?php echo esc_attr( $sec_lbl ); ?>">
							<strong><?php echo esc_html( $sec_lbl ); ?></strong>
							<code class="cms-key-pill"><?php echo esc_html( $sec_id ); ?></code>
						</div>
						<div style="display:flex;align-items:center;gap:14px;">
							<label style="font-weight:600;font-size:13px;display:flex;align-items:center;gap:6px;cursor:pointer;">
								<input type="checkbox" name="homepage_sections[<?php echo intval( $idx ); ?>][visible]" value="1" <?php checked( $is_vis ); ?>>
								Visible on Homepage
							</label>
							<button type="button" class="button button-small cms-move-up" title="Move Section Up">↑ Move Up</button>
							<button type="button" class="button button-small cms-move-down" title="Move Section Down">↓ Move Down</button>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>13B. Hero Carousel & Visual Presentation Settings</h2>
					<p>Configure hero carousel auto-rotation speed, image fit mode, gradient overlay contrast, and floating badges.</p>
				</div>
			</div>
			<div class="cms-grid-3">
				<div class="cms-field">
					<label>Hero Slide Auto-Rotation Interval (ms)</label>
					<input type="number" min="2000" max="20000" step="500" name="design_layout[heroAutoplayMs]" value="<?php echo esc_attr( $layout['heroAutoplayMs'] ?? 5500 ); ?>">
					<span class="cms-hint">Default: 5500 (5.5 seconds per slide).</span>
				</div>
				<div class="cms-field">
					<label>Hero Background Image Fit</label>
					<select name="design_layout[heroImageFit]">
						<option value="cover" <?php selected( ( $layout['heroImageFit'] ?? 'cover' ), 'cover' ); ?>>Proportional Cover (object-cover — Default, No Distortion)</option>
						<option value="fill" <?php selected( ( $layout['heroImageFit'] ?? 'cover' ), 'fill' ); ?>>Full-Bleed Cover (object-cover)</option>
					</select>
				</div>
				<div class="cms-field">
					<label>Hero Gradient Overlay Contrast</label>
					<select name="design_layout[heroOverlayOpacity]">
						<option value="default" <?php selected( ( $layout['heroOverlayOpacity'] ?? 'default' ), 'default' ); ?>>Balanced Brand Navy Gradient (Default)</option>
						<option value="light" <?php selected( ( $layout['heroOverlayOpacity'] ?? 'default' ), 'light' ); ?>>Lighter Overlay (More Image Brilliance)</option>
						<option value="dark" <?php selected( ( $layout['heroOverlayOpacity'] ?? 'default' ), 'dark' ); ?>>Deep Contrast Overlay (Maximum Text Legibility)</option>
					</select>
				</div>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>13C. Global UI Component Visibility Controls</h2>
					<p>Show or hide global site bars, floating elements, and utility controls across all routes.</p>
				</div>
			</div>
			<div class="cms-grid-3">
				<?php
				$toggles = [
					'showTopAnnouncementBar'  => 'Show Top Announcement Bar in Header',
					'showCurrencySelector'    => 'Show Currency Switcher Dropdown (USD/EUR/GBP/ZAR)',
					'showHeaderSearch'        => 'Show Search Input in Header & Mobile Menu',
					'showReassuranceBullets'  => 'Show Reassurance Bullets inside Hero Banner',
					'showFloatingSupportCard' => 'Show Floating "Local Team On the Ground" Card in Hero',
					'showNewsletterSection'   => 'Show Global Travel Newsletter Section Above Footer',
					'showMobileStickyCta'     => 'Show Mobile Sticky Bottom WhatsApp & Plan Holiday Bar',
				];
				foreach ( $toggles as $t_key => $t_label ) :
					$checked = ! isset( $layout[ $t_key ] ) || ! empty( $layout[ $t_key ] );
					?>
					<div class="cms-field cms-checkbox-field" style="background:#f8fafc;border:1px solid #e2e8f0;padding:12px 14px;border-radius:10px;">
						<label style="font-weight:600;cursor:pointer;">
							<input type="checkbox" name="design_layout[<?php echo esc_attr( $t_key ); ?>]" value="1" <?php checked( $checked ); ?>>
							<?php echo esc_html( $t_label ); ?>
						</label>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * =========================================================================
	 * SECTION 14: SEO & PUBLISHING
	 * =========================================================================
	 */
	public static function render_tab_seo_publishing( array $snapshot ): void {
		$route_seo  = $snapshot['site']['routeSeo'] ?? [];
		$structures = $snapshot['site']['editorial']['structures'] ?? [];
		$seo_cfg    = $structures['cms/seoConfig'] ?? [
			'canonicalBaseUrl' => 'https://outboundholidays.co.zw',
			'defaultOgImage'   => '',
			'routeMeta'        => [],
		];
		$route_meta = $seo_cfg['routeMeta'] ?? [];
		$revisions  = Outbound_CMS_Studio::get_revisions();
		$has_draft  = Outbound_CMS_Studio::has_draft();
		?>
		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>14A. Publishing Status, Draft Control & Revision History</h2>
					<p>Manage draft vs. live publishing, roll back to previous revisions, or export/import a complete JSON snapshot backup.</p>
				</div>
				<div style="display:flex;gap:10px;align-items:center;">
					<span class="cms-status-pill" style="background:<?php echo $has_draft ? '#fef3c7;color:#92400e;' : '#dcfce7;color:#166534;'; ?>padding:6px 12px;border-radius:999px;font-weight:700;font-size:12px;">
						<?php echo $has_draft ? '● Draft Pending Publication' : '● Live & Synchronized'; ?>
					</span>
					<code class="cms-key-pill">Version: <?php echo esc_html( $snapshot['version'] ?? 'unknown' ); ?></code>
				</div>
			</div>

			<?php if ( ! empty( $revisions ) ) : ?>
				<h3 style="margin:8px 0 10px;">Recent Published Revisions (<?php echo count( $revisions ); ?>)</h3>
				<table class="wp-list-table widefat fixed striped" style="margin-bottom:20px;">
					<thead>
						<tr>
							<th style="width:220px;">Published Timestamp (UTC)</th>
							<th style="width:160px;">Section Updated</th>
							<th style="width:160px;">Author</th>
							<th>Snapshot Version</th>
							<th style="width:150px;">Rollback Action</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $revisions as $rev_idx => $rev ) : ?>
							<tr>
								<td><strong><?php echo esc_html( $rev['timestamp'] ?? '' ); ?></strong></td>
								<td><span class="cms-badge"><?php echo esc_html( $rev['tab'] ?? 'general' ); ?></span></td>
								<td><?php echo esc_html( $rev['user'] ?? 'admin' ); ?></td>
								<td><code><?php echo esc_html( $rev['version'] ?? '' ); ?></code></td>
								<td>
									<button type="submit" name="cms_restore_revision" value="<?php echo esc_attr( $rev['id'] ?? $rev_idx ); ?>" class="button button-small">
										Restore Revision
									</button>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p style="color:#64748b;margin-bottom:16px;">No revisions recorded yet. Every time you click "Publish Changes", a restore point is saved here automatically.</p>
			<?php endif; ?>

			<div class="cms-grid-2" style="border-top:1px solid #e2e8f0;padding-top:16px;">
				<div class="cms-field">
					<label>Export Live Content Snapshot JSON</label>
					<p class="cms-hint" style="margin:0 0 8px;">Download or copy the complete validated <code>ContentSnapshot</code> JSON currently powering the frontend.</p>
					<a href="<?php echo esc_url( rest_url( 'outbound/v1/content?force=1' ) ); ?>" target="_blank" class="button button-secondary">
						<span class="dashicons dashicons-download" style="vertical-align:middle;"></span> Open / Download Live JSON Snapshot
					</a>
				</div>
				<div class="cms-field">
					<label>Import / Restore Full Content Snapshot JSON (Optional)</label>
					<textarea name="cms_import_snapshot_json" rows="3" placeholder="Paste full ContentSnapshot JSON here only if you wish to bulk-import a backup..."></textarea>
					<span class="cms-hint">Leave blank during normal SEO edits.</span>
				</div>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>14B. Global SEO & OpenGraph Configuration</h2>
					<p>Default canonical domain and OpenGraph share image used by <code>PageMetadata.tsx</code> when a route does not specify a custom image.</p>
				</div>
			</div>
			<div class="cms-grid-2">
				<div class="cms-field">
					<label>Canonical Base URL</label>
					<input type="url" name="seo_config[canonicalBaseUrl]" value="<?php echo esc_attr( $seo_cfg['canonicalBaseUrl'] ?? 'https://outboundholidays.co.zw' ); ?>">
				</div>
				<div class="cms-field">
					<label>Default OpenGraph Share Image URL</label>
					<div class="cms-media-picker">
						<div class="cms-media-preview">
							<?php if ( ! empty( $seo_cfg['defaultOgImage'] ) ) : ?>
								<img src="<?php echo esc_url( $seo_cfg['defaultOgImage'] ); ?>" alt="">
							<?php else : ?>
								<span class="cms-no-img">Default</span>
							<?php endif; ?>
						</div>
						<div class="cms-media-controls">
							<input type="text" name="seo_config[defaultOgImage]" value="<?php echo esc_attr( $seo_cfg['defaultOgImage'] ?? '' ); ?>" class="cms-media-url">
							<button type="button" class="button cms-pick-media"><span class="dashicons dashicons-format-image"></span> Select Image</button>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>14C. Per-Route SEO Titles, Descriptions, Canonical URLs & Indexing (<?php echo count( $route_seo ); ?> Routes)</h2>
					<p>Search and edit SEO metadata for every page route across the website (Home, Directories, Categories, Accommodations, Experiences, Packages, and Guides).</p>
				</div>
				<div style="min-width:280px;">
					<input type="search" class="cms-record-search" data-target="#cms-seo-routes-list .cms-seo-route-card" placeholder="Search routes (e.g. /about, /packages, chobe)..." style="width:100%;padding:8px 12px;border-radius:8px;border:1px solid #cbd5e1;">
				</div>
			</div>

			<div id="cms-seo-routes-list" class="cms-accordion-list">
				<?php
				$r_idx = 0;
				foreach ( $route_seo as $path => $meta ) :
					$extra = $route_meta[ $path ] ?? [];
					?>
					<div class="cms-accordion-item cms-seo-route-card <?php echo $r_idx < 3 ? 'is-open' : ''; ?>" data-search="<?php echo esc_attr( strtolower( $path . ' ' . ( $meta['title'] ?? '' ) . ' ' . ( $meta['description'] ?? '' ) ) ); ?>">
						<div class="cms-accordion-header">
							<div class="cms-acc-title-wrap">
								<div class="cms-acc-meta">
									<strong><code><?php echo esc_html( $path ); ?></code> — <?php echo esc_html( $meta['title'] ?? '' ); ?></strong>
									<span><?php echo esc_html( wp_trim_words( $meta['description'] ?? '', 18 ) ); ?></span>
								</div>
							</div>
							<div class="cms-acc-actions">
								<?php if ( ! empty( $extra['noindex'] ) ) : ?>
									<span class="cms-badge" style="background:#fee2e2;color:#991b1b;">noindex</span>
								<?php endif; ?>
								<span class="dashicons dashicons-arrow-down-alt2 cms-acc-chevron"></span>
							</div>
						</div>
						<div class="cms-accordion-body">
							<input type="hidden" name="route_seo[<?php echo intval( $r_idx ); ?>][path]" value="<?php echo esc_attr( $path ); ?>">
							<div class="cms-grid-2">
								<div class="cms-field">
									<label>SEO Page Title (<code>&lt;title&gt;</code> &amp; <code>og:title</code>)</label>
									<input type="text" name="route_seo[<?php echo intval( $r_idx ); ?>][title]" value="<?php echo esc_attr( $meta['title'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Canonical URL Override (Optional)</label>
									<input type="text" name="route_seo[<?php echo intval( $r_idx ); ?>][canonicalUrl]" value="<?php echo esc_attr( $extra['canonicalUrl'] ?? '' ); ?>" placeholder="Defaults to https://outboundholidays.co.zw<?php echo esc_attr( $path ); ?>">
								</div>
								<div class="cms-field cms-col-span-2">
									<label>Meta Description (<code>meta[name="description"]</code> &amp; <code>og:description</code>)</label>
									<textarea name="route_seo[<?php echo intval( $r_idx ); ?>][description]" rows="2"><?php echo esc_textarea( $meta['description'] ?? '' ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>OpenGraph Image URL Override (Optional)</label>
									<div class="cms-media-picker">
										<div class="cms-media-controls">
											<input type="text" name="route_seo[<?php echo intval( $r_idx ); ?>][ogImage]" value="<?php echo esc_attr( $extra['ogImage'] ?? '' ); ?>" class="cms-media-url" placeholder="https://...">
											<button type="button" class="button cms-pick-media"><span class="dashicons dashicons-format-image"></span> Select</button>
										</div>
									</div>
								</div>
								<div class="cms-field cms-checkbox-field" style="display:flex;align-items:center;">
									<label style="font-weight:600;">
										<input type="checkbox" name="route_seo[<?php echo intval( $r_idx ); ?>][noindex]" value="1" <?php checked( ! empty( $extra['noindex'] ) ); ?>>
										Exclude from Search Engines (<code>noindex, follow</code>)
									</label>
								</div>
							</div>
						</div>
					</div>
					<?php
					$r_idx++;
				endforeach;
				?>
			</div>
		</div>
		<?php
	}
}
endif;
