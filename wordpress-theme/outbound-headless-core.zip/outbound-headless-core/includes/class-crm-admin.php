<?php
/**
 * Outbound Holidays CRM Main Admin Controller & Studio Interface
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Outbound_CRM_Admin' ) ) :
class Outbound_CRM_Admin {

    private static $initialized = false;
    private static $rendered    = false;

    public static function init() {
        if ( self::$initialized ) {
            return;
        }
        self::$initialized = true;
        add_action( 'admin_menu', [ __CLASS__, 'register_crm_menus' ], 99 );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_crm_assets' ] );
        add_action( 'admin_post_outbound_crm_action', [ __CLASS__, 'handle_form_actions' ] );
    }

    public static function register_crm_menus() {
        global $submenu;
        remove_menu_page( 'outbound-crm' );
        remove_all_actions( 'toplevel_page_outbound-crm' );
        if ( isset( $submenu['outbound-crm'] ) ) {
            unset( $submenu['outbound-crm'] );
        }

        // Main Outbound CRM Menu
        add_menu_page(
            __( 'Outbound Holidays CRM', 'outbound-headless' ),
            __( 'Outbound CRM', 'outbound-headless' ),
            'edit_posts',
            'outbound-crm',
            [ __CLASS__, 'render_studio_shell' ],
            'dashicons-groups',
            26
        );

        $submenus = [
            [ 'slug' => 'outbound-crm',            'title' => __( 'Dashboard', 'outbound-headless' ) ],
            [ 'slug' => 'outbound-crm-leads',      'title' => __( 'Enquiries & Leads', 'outbound-headless' ) ],
            [ 'slug' => 'outbound-crm-customers',  'title' => __( 'Customers', 'outbound-headless' ) ],
            [ 'slug' => 'outbound-crm-pipeline',   'title' => __( 'Sales Pipeline', 'outbound-headless' ) ],
            [ 'slug' => 'outbound-crm-quotations', 'title' => __( 'Quotations', 'outbound-headless' ) ],
            [ 'slug' => 'outbound-crm-bookings',   'title' => __( 'Bookings', 'outbound-headless' ) ],
            [ 'slug' => 'outbound-crm-payments',   'title' => __( 'Payments', 'outbound-headless' ) ],
            [ 'slug' => 'outbound-crm-tasks',      'title' => __( 'Tasks & Follow-ups', 'outbound-headless' ) ],
            [ 'slug' => 'outbound-crm-suppliers',  'title' => __( 'Suppliers', 'outbound-headless' ) ],
            [ 'slug' => 'outbound-crm-reports',    'title' => __( 'Reports', 'outbound-headless' ) ],
            [ 'slug' => 'outbound-crm-templates',  'title' => __( 'WhatsApp & Templates', 'outbound-headless' ) ],
            [ 'slug' => 'outbound-crm-settings',   'title' => __( 'CRM Settings', 'outbound-headless' ) ],
        ];

        foreach ( $submenus as $sub ) {
            add_submenu_page(
                'outbound-crm',
                $sub['title'],
                $sub['title'],
                ( $sub['slug'] === 'outbound-crm-settings' ) ? 'manage_options' : 'edit_posts',
                $sub['slug'],
                [ __CLASS__, 'render_studio_shell' ]
            );
        }
    }

    public static function enqueue_crm_assets( $hook ) {
        if ( strpos( $hook, 'outbound-crm' ) === false ) {
            return;
        }

        wp_enqueue_style(
            'outbound-crm-studio-css',
            plugins_url( '../assets/css/crm-studio.css', __FILE__ ),
            [],
            '1.2.0'
        );

        wp_enqueue_script(
            'outbound-crm-studio-js',
            plugins_url( '../assets/js/crm-studio.js', __FILE__ ),
            [],
            '1.2.0',
            true
        );
    }

    public static function render_studio_shell() {
        if ( self::$rendered ) {
            return;
        }
        self::$rendered = true;
        include plugin_dir_path( __FILE__ ) . 'views/crm-studio-shell.php';
    }

    public static function handle_form_actions() {
        check_admin_referer( 'outbound_crm_nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_die( __( 'Unauthorized permission', 'outbound-headless' ) );
        }

        global $wpdb;
        $crm_action = sanitize_text_field( $_POST['crm_action'] ?? '' );
        $redirect = wp_get_referer() ?: admin_url( 'admin.php?page=outbound-crm' );

        // 1. Save Customer
        if ( 'save_customer' === $crm_action ) {
            Outbound_CRM_Customers::save( [
                'id'            => intval( $_POST['customer_id'] ?? 0 ),
                'first_name'    => $_POST['first_name'] ?? '',
                'last_name'     => $_POST['last_name'] ?? '',
                'email'         => $_POST['email'] ?? '',
                'phone'         => $_POST['phone'] ?? ( $_POST['whatsapp'] ?? '' ),
                'whatsapp'      => $_POST['whatsapp'] ?? '',
                'country'       => $_POST['country'] ?? '',
                'customer_type' => $_POST['customer_type'] ?? 'individual',
                'notes'         => $_POST['notes'] ?? '',
            ] );
        }

        // 2. Update Opportunity
        if ( 'update_opportunity' === $crm_action ) {
            $opp_id = intval( $_POST['opportunity_id'] ?? 0 );
            if ( $opp_id > 0 ) {
                $table = Outbound_CRM_Database::get_table( 'opportunities' );
                $now = current_time( 'mysql' );
                $wpdb->update(
                    $table,
                    [
                        'title'          => sanitize_text_field( $_POST['title'] ?? '' ),
                        'stage'          => sanitize_text_field( $_POST['stage'] ?? 'new' ),
                        'value'          => floatval( $_POST['value'] ?? 0 ),
                        'arrival_date'   => ! empty( $_POST['arrival_date'] ) ? sanitize_text_field( $_POST['arrival_date'] ) : null,
                        'departure_date' => ! empty( $_POST['departure_date'] ) ? sanitize_text_field( $_POST['departure_date'] ) : null,
                        'adults'         => intval( $_POST['adults'] ?? 2 ),
                        'customer_notes' => sanitize_textarea_field( $_POST['customer_notes'] ?? '' ),
                        'updated_at'     => $now,
                    ],
                    [ 'id' => $opp_id ]
                );
            }
        }

        // 3. Update Pipeline Stage
        if ( 'update_stage' === $crm_action ) {
            $opp_id = intval( $_POST['opportunity_id'] ?? 0 );
            $new_stage = sanitize_text_field( $_POST['new_stage'] ?? '' );
            if ( $opp_id && $new_stage ) {
                Outbound_CRM_Enquiries::update_stage( $opp_id, $new_stage );
            }
        }

        // 4. Create Quotation
        if ( 'create_quotation' === $crm_action ) {
            $opp_id = intval( $_POST['opportunity_id'] ?? 0 );
            Outbound_CRM_Quotations::create( $opp_id, $_POST );
        }

        // 5. Save Quotation
        if ( 'save_quotation' === $crm_action ) {
            $quote_id = intval( $_POST['quote_id'] ?? 0 );
            if ( $quote_id ) {
                $table = Outbound_CRM_Database::get_table( 'quotations' );
                $now = current_time( 'mysql' );
                $total = floatval( $_POST['total'] ?? 0 );
                $deposit = floatval( $_POST['deposit_required'] ?? ( $total * 0.3 ) );
                $wpdb->update(
                    $table,
                    [
                        'total'            => $total,
                        'deposit_required' => $deposit,
                        'status'           => sanitize_text_field( $_POST['status'] ?? 'sent' ),
                        'inclusions'       => sanitize_textarea_field( $_POST['inclusions'] ?? '' ),
                        'exclusions'       => sanitize_textarea_field( $_POST['exclusions'] ?? '' ),
                        'terms'            => sanitize_textarea_field( $_POST['terms'] ?? '' ),
                        'updated_at'       => $now,
                    ],
                    [ 'id' => $quote_id ]
                );
            }
        }

        // 6. Confirm Booking
        if ( 'confirm_booking' === $crm_action ) {
            $opp_id = intval( $_POST['opportunity_id'] ?? 0 );
            Outbound_CRM_Bookings::confirm_from_opportunity( $opp_id, $_POST );
        }

        // 7. Save Booking Details
        if ( 'save_booking' === $crm_action ) {
            $booking_id = intval( $_POST['booking_id'] ?? 0 );
            if ( $booking_id ) {
                $table = Outbound_CRM_Database::get_table( 'bookings' );
                $now = current_time( 'mysql' );
                $selling = floatval( $_POST['total_selling_price'] ?? 0 );
                $supplier_cost = floatval( $_POST['total_supplier_cost'] ?? 0 );
                $profit = max( 0.0, $selling - $supplier_cost );

                $wpdb->update(
                    $table,
                    [
                        'arrival_date'             => ! empty( $_POST['arrival_date'] ) ? sanitize_text_field( $_POST['arrival_date'] ) : null,
                        'departure_date'           => ! empty( $_POST['departure_date'] ) ? sanitize_text_field( $_POST['departure_date'] ) : null,
                        'adults'                   => intval( $_POST['adults'] ?? 2 ),
                        'children'                 => intval( $_POST['children'] ?? 0 ),
                        'total_selling_price'      => $selling,
                        'total_supplier_cost'      => $supplier_cost,
                        'gross_profit'             => $profit,
                        'status'                   => sanitize_text_field( $_POST['status'] ?? 'confirmed' ),
                        'payment_status'           => sanitize_text_field( $_POST['payment_status'] ?? 'unpaid' ),
                        'operational_instructions' => sanitize_textarea_field( $_POST['operational_instructions'] ?? '' ),
                        'updated_at'               => $now,
                    ],
                    [ 'id' => $booking_id ]
                );
            }
        }

        // 8. Record Payment
        if ( 'record_payment' === $crm_action ) {
            $booking_id = intval( $_POST['booking_id'] ?? 0 );
            $amount = floatval( $_POST['amount'] ?? 0 );
            $method = sanitize_text_field( $_POST['payment_method'] ?? 'bank_transfer' );
            $ref = sanitize_text_field( $_POST['payment_reference'] ?? '' );
            $notes = sanitize_textarea_field( $_POST['notes'] ?? '' );
            Outbound_CRM_Payments::record( $booking_id, $amount, $method, $ref, $notes );
        }

        // 9. Add Task
        if ( 'add_task' === $crm_action ) {
            $table = Outbound_CRM_Database::get_table( 'tasks' );
            $wpdb->insert( $table, [
                'title'       => sanitize_text_field( $_POST['title'] ?? 'Follow up' ),
                'task_type'   => sanitize_text_field( $_POST['task_type'] ?? 'follow_up' ),
                'customer_id' => intval( $_POST['customer_id'] ?? 0 ) ?: null,
                'due_date'    => sanitize_text_field( $_POST['due_date'] ?? current_time( 'Y-m-d' ) ),
                'priority'    => sanitize_text_field( $_POST['priority'] ?? 'medium' ),
                'status'      => 'pending',
                'notes'       => sanitize_textarea_field( $_POST['notes'] ?? '' ),
                'created_at'  => current_time( 'mysql' ),
            ] );
        }

        // 10. Complete Task
        if ( 'complete_task' === $crm_action ) {
            $task_id = intval( $_POST['task_id'] ?? 0 );
            if ( $task_id ) {
                $table = Outbound_CRM_Database::get_table( 'tasks' );
                $wpdb->update(
                    $table,
                    [ 'status' => 'completed', 'completed_at' => current_time( 'mysql' ) ],
                    [ 'id' => $task_id ]
                );
            }
        }

        // 11. Save Supplier
        if ( 'save_supplier' === $crm_action ) {
            $supp_id = intval( $_POST['supplier_id'] ?? 0 );
            $name = sanitize_text_field( $_POST['name'] ?? '' );
            if ( ! empty( $name ) ) {
                $table = Outbound_CRM_Database::get_table( 'suppliers' );
                $now = current_time( 'mysql' );
                $data = [
                    'name'             => $name,
                    'supplier_type'    => sanitize_text_field( $_POST['supplier_type'] ?? 'accommodation' ),
                    'contact_person'   => sanitize_text_field( $_POST['contact_person'] ?? '' ),
                    'email'            => sanitize_email( $_POST['email'] ?? '' ),
                    'phone'            => sanitize_text_field( $_POST['phone'] ?? '' ),
                    'whatsapp'         => sanitize_text_field( $_POST['whatsapp'] ?? '' ),
                    'location'         => sanitize_text_field( $_POST['location'] ?? 'Victoria Falls' ),
                    'services_offered' => sanitize_textarea_field( $_POST['services_offered'] ?? '' ),
                    'payment_terms'    => sanitize_text_field( $_POST['payment_terms'] ?? '30 days invoice' ),
                    'status'           => sanitize_text_field( $_POST['status'] ?? 'active' ),
                    'updated_at'       => $now,
                ];

                if ( $supp_id > 0 ) {
                    $wpdb->update( $table, $data, [ 'id' => $supp_id ] );
                } else {
                    $data['created_at'] = $now;
                    $wpdb->insert( $table, $data );
                }
            }
        }

        wp_safe_redirect( $redirect );
        exit;
    }
}
endif;
