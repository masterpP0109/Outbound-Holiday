<?php
/**
 * Outbound Holidays CRM Database Schema & Core Data Model
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Outbound_CRM_Database' ) ) :
class Outbound_CRM_Database {

    const DB_VERSION = '1.2.0';

    public static function init() {
        add_action( 'plugins_loaded', [ __CLASS__, 'check_install' ] );
        add_action( 'admin_init', [ __CLASS__, 'check_install' ] );
    }

    public static function check_install() {
        if ( get_option( 'outbound_crm_db_version' ) !== self::DB_VERSION ) {
            self::install();
        }
    }

    public static function get_table( $name ) {
        global $wpdb;
        return $wpdb->prefix . 'outbound_crm_' . $name;
    }

    public static function install() {
        global $wpdb;
        if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
            return;
        }
        $charset_collate = $wpdb->get_charset_collate();

        if ( ! function_exists( 'dbDelta' ) && file_exists( ABSPATH . 'wp-admin/includes/upgrade.php' ) ) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }
        if ( ! function_exists( 'dbDelta' ) ) {
            return;
        }

        // 1. Customers Table
        $table_customers = self::get_table( 'customers' );
        $sql_customers = "CREATE TABLE $table_customers (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            first_name varchar(100) NOT NULL,
            last_name varchar(100) NOT NULL DEFAULT '',
            email varchar(191) NOT NULL,
            phone varchar(50) NOT NULL DEFAULT '',
            whatsapp varchar(50) NOT NULL DEFAULT '',
            country varchar(100) NOT NULL DEFAULT '',
            city varchar(100) NOT NULL DEFAULT '',
            customer_type varchar(50) NOT NULL DEFAULT 'individual',
            preferred_contact varchar(50) NOT NULL DEFAULT 'email',
            travel_preferences text,
            tags text,
            marketing_consent tinyint(1) NOT NULL DEFAULT 0,
            status varchar(50) NOT NULL DEFAULT 'active',
            notes text,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY email (email),
            KEY status (status)
        ) $charset_collate;";
        dbDelta( $sql_customers );

        // 2. Opportunities (Leads / Enquiries) Table
        $table_opportunities = self::get_table( 'opportunities' );
        $sql_opportunities = "CREATE TABLE $table_opportunities (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            reference varchar(50) NOT NULL,
            customer_id bigint(20) unsigned NOT NULL,
            title varchar(255) NOT NULL,
            lead_source varchar(50) NOT NULL DEFAULT 'website',
            stage varchar(50) NOT NULL DEFAULT 'new',
            value decimal(10,2) NOT NULL DEFAULT 0.00,
            currency varchar(10) NOT NULL DEFAULT 'USD',
            arrival_date date DEFAULT NULL,
            departure_date date DEFAULT NULL,
            adults int(11) NOT NULL DEFAULT 2,
            children int(11) NOT NULL DEFAULT 0,
            assigned_advisor_id bigint(20) unsigned DEFAULT NULL,
            priority varchar(20) NOT NULL DEFAULT 'medium',
            trip_payload longtext,
            customer_notes text,
            lost_reason text,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY reference (reference),
            KEY customer_id (customer_id),
            KEY stage (stage),
            KEY arrival_date (arrival_date)
        ) $charset_collate;";
        dbDelta( $sql_opportunities );

        // 3. Quotations Table
        $table_quotations = self::get_table( 'quotations' );
        $sql_quotations = "CREATE TABLE $table_quotations (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            quote_number varchar(50) NOT NULL,
            opportunity_id bigint(20) unsigned NOT NULL,
            customer_id bigint(20) unsigned NOT NULL,
            version int(11) NOT NULL DEFAULT 1,
            status varchar(50) NOT NULL DEFAULT 'draft',
            valid_until date NOT NULL,
            subtotal decimal(10,2) NOT NULL DEFAULT 0.00,
            discount decimal(10,2) NOT NULL DEFAULT 0.00,
            tax decimal(10,2) NOT NULL DEFAULT 0.00,
            total decimal(10,2) NOT NULL DEFAULT 0.00,
            deposit_required decimal(10,2) NOT NULL DEFAULT 0.00,
            currency varchar(10) NOT NULL DEFAULT 'USD',
            items_json longtext,
            inclusions text,
            exclusions text,
            terms text,
            created_by bigint(20) unsigned NOT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY quote_number (quote_number),
            KEY opportunity_id (opportunity_id),
            KEY customer_id (customer_id)
        ) $charset_collate;";
        dbDelta( $sql_quotations );

        // 4. Bookings Table
        $table_bookings = self::get_table( 'bookings' );
        $sql_bookings = "CREATE TABLE $table_bookings (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            booking_ref varchar(50) NOT NULL,
            opportunity_id bigint(20) unsigned DEFAULT NULL,
            quotation_id bigint(20) unsigned DEFAULT NULL,
            customer_id bigint(20) unsigned NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'confirmed',
            arrival_date date DEFAULT NULL,
            departure_date date DEFAULT NULL,
            adults int(11) NOT NULL DEFAULT 2,
            children int(11) NOT NULL DEFAULT 0,
            total_selling_price decimal(10,2) NOT NULL DEFAULT 0.00,
            total_supplier_cost decimal(10,2) NOT NULL DEFAULT 0.00,
            gross_profit decimal(10,2) NOT NULL DEFAULT 0.00,
            currency varchar(10) NOT NULL DEFAULT 'USD',
            payment_status varchar(50) NOT NULL DEFAULT 'unpaid',
            operational_instructions text,
            emergency_contact text,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY booking_ref (booking_ref),
            KEY customer_id (customer_id),
            KEY status (status),
            KEY arrival_date (arrival_date)
        ) $charset_collate;";
        dbDelta( $sql_bookings );

        // 5. Payments Table
        $table_payments = self::get_table( 'payments' );
        $sql_payments = "CREATE TABLE $table_payments (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            booking_id bigint(20) unsigned NOT NULL,
            customer_id bigint(20) unsigned NOT NULL,
            payment_type varchar(50) NOT NULL DEFAULT 'customer_payment',
            amount decimal(10,2) NOT NULL DEFAULT 0.00,
            currency varchar(10) NOT NULL DEFAULT 'USD',
            payment_method varchar(50) NOT NULL DEFAULT 'bank_transfer',
            payment_reference varchar(191) NOT NULL DEFAULT '',
            payment_date date NOT NULL,
            notes text,
            recorded_by bigint(20) unsigned NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY booking_id (booking_id),
            KEY customer_id (customer_id)
        ) $charset_collate;";
        dbDelta( $sql_payments );

        // 6. Tasks & Follow-ups Table
        $table_tasks = self::get_table( 'tasks' );
        $sql_tasks = "CREATE TABLE $table_tasks (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            task_type varchar(50) NOT NULL DEFAULT 'follow_up',
            opportunity_id bigint(20) unsigned DEFAULT NULL,
            customer_id bigint(20) unsigned DEFAULT NULL,
            booking_id bigint(20) unsigned DEFAULT NULL,
            assigned_to bigint(20) unsigned DEFAULT NULL,
            due_date date NOT NULL,
            due_time time DEFAULT NULL,
            priority varchar(20) NOT NULL DEFAULT 'medium',
            status varchar(20) NOT NULL DEFAULT 'pending',
            notes text,
            completed_at datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY status (status),
            KEY due_date (due_date)
        ) $charset_collate;";
        dbDelta( $sql_tasks );

        // 7. Suppliers Table
        $table_suppliers = self::get_table( 'suppliers' );
        $sql_suppliers = "CREATE TABLE $table_suppliers (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            supplier_type varchar(50) NOT NULL DEFAULT 'accommodation',
            contact_person varchar(100) NOT NULL DEFAULT '',
            email varchar(191) NOT NULL DEFAULT '',
            phone varchar(50) NOT NULL DEFAULT '',
            whatsapp varchar(50) NOT NULL DEFAULT '',
            location varchar(191) NOT NULL DEFAULT 'Victoria Falls',
            services_offered text,
            contract_reference varchar(100) NOT NULL DEFAULT '',
            payment_terms varchar(100) NOT NULL DEFAULT '30 days invoice',
            status varchar(20) NOT NULL DEFAULT 'active',
            notes text,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY supplier_type (supplier_type),
            KEY status (status)
        ) $charset_collate;";
        dbDelta( $sql_suppliers );

        // 8. Activity Logs & Timeline Table
        $table_logs = self::get_table( 'logs' );
        $sql_logs = "CREATE TABLE $table_logs (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            customer_id bigint(20) unsigned DEFAULT NULL,
            opportunity_id bigint(20) unsigned DEFAULT NULL,
            booking_id bigint(20) unsigned DEFAULT NULL,
            log_type varchar(50) NOT NULL,
            title varchar(255) NOT NULL,
            details text,
            created_by bigint(20) unsigned NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY customer_id (customer_id),
            KEY opportunity_id (opportunity_id)
        ) $charset_collate;";
        if ( function_exists( 'dbDelta' ) ) {
            dbDelta( $sql_logs );
        }

        update_option( 'outbound_crm_db_version', self::DB_VERSION );
    }

    public static function log_activity( $args ) {
        global $wpdb;
        $table = self::get_table( 'logs' );
        $wpdb->insert( $table, [
            'customer_id'    => $args['customer_id'] ?? null,
            'opportunity_id' => $args['opportunity_id'] ?? null,
            'booking_id'     => $args['booking_id'] ?? null,
            'log_type'       => $args['log_type'] ?? 'note',
            'title'          => $args['title'] ?? 'Updated record',
            'details'        => $args['details'] ?? '',
            'created_by'     => get_current_user_id() ?: 1,
            'created_at'     => current_time( 'mysql' ),
        ] );
    }

    public static function create_opportunity_from_enquiry( $data ) {
        return Outbound_CRM_Enquiries::create_from_enquiry( $data );
    }

    public static function get_dashboard_metrics() {
        return Outbound_CRM_Reports::get_dashboard_metrics();
    }
}
endif;

// Compatibility class aliases (guarded against duplicate declaration)
if ( ! class_exists( 'Outbound_CRM_Schema' ) ) {
    class_alias( 'Outbound_CRM_Database', 'Outbound_CRM_Schema' );
}
if ( ! class_exists( 'Outbound_CRM_Data' ) ) {
    class_alias( 'Outbound_CRM_Database', 'Outbound_CRM_Data' );
}
