<?php
/**
 * Outbound Holidays CRM Enquiries & Opportunities Management
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Outbound_CRM_Enquiries' ) ) :
class Outbound_CRM_Enquiries {

    public static function get_all( $limit = 100, $offset = 0 ) {
        global $wpdb;
        $table_opps = Outbound_CRM_Database::get_table( 'opportunities' );
        $table_cust = Outbound_CRM_Database::get_table( 'customers' );

        return $wpdb->get_results( $wpdb->prepare( "
            SELECT o.*, c.first_name, c.last_name, c.email, c.phone, c.whatsapp 
            FROM {$table_opps} o
            LEFT JOIN {$table_cust} c ON o.customer_id = c.id
            ORDER BY o.id DESC
            LIMIT %d OFFSET %d
        ", $limit, $offset ), ARRAY_A );
    }

    public static function get( $id ) {
        global $wpdb;
        $table = Outbound_CRM_Database::get_table( 'opportunities' );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A );
    }

    public static function create_from_enquiry( $data ) {
        global $wpdb;

        $name = sanitize_text_field( $data['name'] ?? '' );
        $parts = explode( ' ', $name, 2 );
        $first_name = $parts[0] ?? 'Traveller';
        $last_name  = $parts[1] ?? '';
        $email = sanitize_email( $data['email'] ?? '' );
        $phone = sanitize_text_field( $data['phone'] ?? '' );

        $customer_id = Outbound_CRM_Customers::get_or_create( $email, $first_name, $last_name, $phone );

        $trip = $data['trip'] ?? [];
        $title = ! empty( $trip['packageTitle'] ) ? sanitize_text_field( $trip['packageTitle'] ) : ( ! empty( $trip['accommodationTitle'] ) ? 'Stay at ' . sanitize_text_field( $trip['accommodationTitle'] ) : 'Victoria Falls Holiday Enquiry' );

        $now = current_time( 'mysql' );
        $table_opps = Outbound_CRM_Database::get_table( 'opportunities' );

        $wpdb->insert( $table_opps, [
            'reference'      => sanitize_text_field( $data['reference'] ?? ( 'OH-' . current_time( 'Ymd' ) . '-' . strtoupper( wp_generate_password( 4, false ) ) ) ),
            'customer_id'    => $customer_id,
            'title'          => $title,
            'lead_source'    => sanitize_text_field( $data['source'] ?? 'website' ),
            'stage'          => 'new',
            'value'          => floatval( $trip['estimatedTotal'] ?? 1500.00 ),
            'currency'       => 'USD',
            'arrival_date'   => ! empty( $trip['dates']['startDate'] ) ? sanitize_text_field( $trip['dates']['startDate'] ) : null,
            'departure_date' => ! empty( $trip['dates']['endDate'] ) ? sanitize_text_field( $trip['dates']['endDate'] ) : null,
            'adults'         => intval( $trip['adults'] ?? 2 ),
            'children'       => intval( $trip['children'] ?? 0 ),
            'priority'       => 'medium',
            'trip_payload'   => wp_json_encode( $trip ),
            'customer_notes' => sanitize_textarea_field( $data['message'] ?? '' ),
            'created_at'     => $now,
            'updated_at'     => $now,
        ] );

        $opp_id = $wpdb->insert_id;

        Outbound_CRM_Database::log_activity( [
            'customer_id'    => $customer_id,
            'opportunity_id' => $opp_id,
            'log_type'       => 'enquiry_received',
            'title'          => sprintf( __( 'New enquiry %s created from %s', 'outbound-headless' ), $data['reference'], $data['source'] ?? 'website' ),
        ] );

        // Schedule automated follow-up task for 24h
        $table_tasks = Outbound_CRM_Database::get_table( 'tasks' );
        $wpdb->insert( $table_tasks, [
            'title'          => sprintf( __( 'Follow up enquiry [%s] from %s', 'outbound-headless' ), $data['reference'], $first_name ),
            'task_type'      => 'follow_up',
            'opportunity_id' => $opp_id,
            'customer_id'    => $customer_id,
            'due_date'       => date( 'Y-m-d', strtotime( '+1 day' ) ),
            'priority'       => 'high',
            'status'         => 'pending',
            'notes'          => __( 'Review guest dates & accommodation preference and dispatch initial itinerary.', 'outbound-headless' ),
            'created_at'     => $now,
        ] );

        return $opp_id;
    }

    public static function update_stage( $opp_id, $new_stage ) {
        global $wpdb;
        $table = Outbound_CRM_Database::get_table( 'opportunities' );
        $now = current_time( 'mysql' );

        $wpdb->update(
            $table,
            [ 'stage' => sanitize_text_field( $new_stage ), 'updated_at' => $now ],
            [ 'id' => intval( $opp_id ) ]
        );

        $opp = self::get( $opp_id );
        if ( $opp ) {
            Outbound_CRM_Database::log_activity( [
                'customer_id'    => $opp['customer_id'],
                'opportunity_id' => $opp_id,
                'log_type'       => 'stage_change',
                'title'          => sprintf( __( 'Pipeline stage changed to %s', 'outbound-headless' ), ucfirst( $new_stage ) ),
            ] );
        }
    }
}
endif;
