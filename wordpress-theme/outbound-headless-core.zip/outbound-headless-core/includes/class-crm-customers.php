<?php
/**
 * Outbound Holidays CRM Customers Management
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Outbound_CRM_Customers' ) ) :
class Outbound_CRM_Customers {

    public static function get_all( $limit = 100, $offset = 0 ) {
        global $wpdb;
        $table = Outbound_CRM_Database::get_table( 'customers' );
        $opps_table = Outbound_CRM_Database::get_table( 'opportunities' );
        $bks_table  = Outbound_CRM_Database::get_table( 'bookings' );

        return $wpdb->get_results( $wpdb->prepare( "
            SELECT c.*, 
            (SELECT COUNT(*) FROM {$opps_table} WHERE customer_id = c.id) as total_enquiries,
            (SELECT COUNT(*) FROM {$bks_table} WHERE customer_id = c.id AND status = 'confirmed') as total_bookings
            FROM {$table} c
            ORDER BY c.id DESC
            LIMIT %d OFFSET %d
        ", $limit, $offset ), ARRAY_A );
    }

    public static function get( $id ) {
        global $wpdb;
        $table = Outbound_CRM_Database::get_table( 'customers' );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A );
    }

    public static function save( $data ) {
        global $wpdb;
        $table = Outbound_CRM_Database::get_table( 'customers' );
        $id = intval( $data['id'] ?? 0 );
        $now = current_time( 'mysql' );

        $payload = [
            'first_name'        => sanitize_text_field( $data['first_name'] ?? '' ),
            'last_name'         => sanitize_text_field( $data['last_name'] ?? '' ),
            'email'             => sanitize_email( $data['email'] ?? '' ),
            'phone'             => sanitize_text_field( $data['phone'] ?? '' ),
            'whatsapp'          => sanitize_text_field( $data['whatsapp'] ?? '' ),
            'country'           => sanitize_text_field( $data['country'] ?? '' ),
            'city'              => sanitize_text_field( $data['city'] ?? '' ),
            'customer_type'     => sanitize_text_field( $data['customer_type'] ?? 'individual' ),
            'preferred_contact' => sanitize_text_field( $data['preferred_contact'] ?? 'email' ),
            'notes'             => sanitize_textarea_field( $data['notes'] ?? '' ),
            'status'            => sanitize_text_field( $data['status'] ?? 'active' ),
            'updated_at'        => $now,
        ];

        if ( $id > 0 ) {
            $wpdb->update( $table, $payload, [ 'id' => $id ] );
        } else {
            $payload['created_at'] = $now;
            $wpdb->insert( $table, $payload );
            $id = $wpdb->insert_id;
        }

        Outbound_CRM_Database::log_activity( [
            'customer_id' => $id,
            'log_type'    => 'customer_saved',
            'title'       => sprintf( __( 'Traveller profile %s saved', 'outbound-headless' ), trim( $payload['first_name'] . ' ' . $payload['last_name'] ) ),
        ] );

        return $id;
    }

    public static function get_or_create( $email, $first_name, $last_name = '', $phone = '' ) {
        global $wpdb;
        $table = Outbound_CRM_Database::get_table( 'customers' );
        $customer = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE email = %s", $email ), ARRAY_A );
        if ( $customer ) {
            return $customer['id'];
        }

        return self::save( [
            'email'      => $email,
            'first_name' => $first_name,
            'last_name'  => $last_name,
            'phone'      => $phone,
            'whatsapp'   => $phone,
        ] );
    }
}
endif;
