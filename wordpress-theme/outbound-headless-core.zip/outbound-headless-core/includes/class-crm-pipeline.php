<?php
/**
 * Outbound Holidays CRM Sales Pipeline & Kanban
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Outbound_CRM_Pipeline' ) ) :
class Outbound_CRM_Pipeline {

    public static function get_stages() {
        return [
            'new'        => __( 'New Enquiry', 'outbound-headless' ),
            'contacted'  => __( 'Contacted', 'outbound-headless' ),
            'qualified'  => __( 'Qualified', 'outbound-headless' ),
            'planning'   => __( 'Preparing Quote', 'outbound-headless' ),
            'quote_sent' => __( 'Quotation Sent', 'outbound-headless' ),
            'confirmed'  => __( 'Confirmed Booking', 'outbound-headless' ),
            'lost'       => __( 'Lost / Closed', 'outbound-headless' ),
        ];
    }

    public static function get_grouped() {
        $opps = Outbound_CRM_Enquiries::get_all( 200 );
        $stages = self::get_stages();
        $grouped = [];
        foreach ( array_keys( $stages ) as $s ) {
            $grouped[$s] = [];
        }

        foreach ( $opps as $o ) {
            $st = $o['stage'] ?: 'new';
            if ( isset( $grouped[$st] ) ) {
                $grouped[$st][] = $o;
            } else {
                $grouped['new'][] = $o;
            }
        }

        return $grouped;
    }
}
endif;
