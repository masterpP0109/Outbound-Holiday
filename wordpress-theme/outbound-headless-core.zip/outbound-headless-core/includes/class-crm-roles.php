<?php
/**
 * Outbound Holidays CRM Role-Based Access Control (RBAC) & Capabilities
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Outbound_CRM_Roles' ) ) :
class Outbound_CRM_Roles {

    public static function init() {
        add_action( 'init', [ __CLASS__, 'setup_roles_and_caps' ] );
    }

    public static function setup_roles_and_caps() {
        // Capabilities:
        // outbound_crm_view         - View dashboard, enquiries, customers, pipeline
        // outbound_crm_manage_leads - Create quotes, edit opportunities, update stages
        // outbound_crm_manage_ops   - Manage confirmed bookings, supplier assignments
        // outbound_crm_finance      - Record payments, view financial totals & margins
        // outbound_crm_admin        - Full access, settings, export/import, supplier rates

        // Ensure Administrator has all CRM capabilities
        $admin = get_role( 'administrator' );
        if ( $admin ) {
            $admin->add_cap( 'outbound_crm_view' );
            $admin->add_cap( 'outbound_crm_manage_leads' );
            $admin->add_cap( 'outbound_crm_manage_ops' );
            $admin->add_cap( 'outbound_crm_finance' );
            $admin->add_cap( 'outbound_crm_admin' );
        }

        // 1. Travel Advisor / Sales Role
        if ( ! get_role( 'outbound_travel_advisor' ) ) {
            add_role(
                'outbound_travel_advisor',
                __( 'Outbound Travel Advisor', 'outbound-headless' ),
                [
                    'read'                      => true,
                    'outbound_crm_view'         => true,
                    'outbound_crm_manage_leads' => true,
                ]
            );
        }

        // 2. Operations / Ground Handling Role
        if ( ! get_role( 'outbound_operations' ) ) {
            add_role(
                'outbound_operations',
                __( 'Outbound Operations Coordinator', 'outbound-headless' ),
                [
                    'read'                    => true,
                    'outbound_crm_view'       => true,
                    'outbound_crm_manage_ops' => true,
                ]
            );
        }

        // 3. Finance Manager Role
        if ( ! get_role( 'outbound_finance' ) ) {
            add_role(
                'outbound_finance',
                __( 'Outbound Finance Manager', 'outbound-headless' ),
                [
                    'read'                 => true,
                    'outbound_crm_view'    => true,
                    'outbound_crm_finance' => true,
                ]
            );
        }
    }
}
endif;
