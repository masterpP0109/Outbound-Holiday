<?php
/**
 * Outbound Holidays CRM Reports & Analytics Engine
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Outbound_CRM_Reports' ) ) :
class Outbound_CRM_Reports {

    public static function get_dashboard_metrics() {
        global $wpdb;

        $table_opps  = Outbound_CRM_Database::get_table( 'opportunities' );
        $table_bks   = Outbound_CRM_Database::get_table( 'bookings' );
        $table_pmts  = Outbound_CRM_Database::get_table( 'payments' );
        $table_tasks = Outbound_CRM_Database::get_table( 'tasks' );

        $total_enquiries = intval( $wpdb->get_var( "SELECT COUNT(*) FROM {$table_opps}" ) );
        $new_enquiries   = intval( $wpdb->get_var( "SELECT COUNT(*) FROM {$table_opps} WHERE stage = 'new'" ) );
        $qualified_leads = intval( $wpdb->get_var( "SELECT COUNT(*) FROM {$table_opps} WHERE stage IN ('qualified', 'planning')" ) );
        $quotes_sent     = intval( $wpdb->get_var( "SELECT COUNT(*) FROM {$table_opps} WHERE stage = 'quote_sent'" ) );
        $confirmed_bks   = intval( $wpdb->get_var( "SELECT COUNT(*) FROM {$table_bks} WHERE status = 'confirmed'" ) );

        $total_booking_val = floatval( $wpdb->get_var( "SELECT SUM(total_selling_price) FROM {$table_bks} WHERE status != 'cancelled'" ) );
        $total_gross_prof  = floatval( $wpdb->get_var( "SELECT SUM(gross_profit) FROM {$table_bks} WHERE status != 'cancelled'" ) );
        $payments_received = floatval( $wpdb->get_var( "SELECT SUM(amount) FROM {$table_pmts}" ) );
        $outstanding_bal   = max( 0.0, $total_booking_val - $payments_received );

        $conversion_rate = $total_enquiries > 0 ? round( ( $confirmed_bks / $total_enquiries ) * 100, 1 ) : 0.0;

        $today = current_time( 'Y-m-d' );
        $next_30 = date( 'Y-m-d', strtotime( '+30 days' ) );

        $active_travellers = intval( $wpdb->get_var( $wpdb->prepare( "
            SELECT COUNT(*) FROM {$table_bks} 
            WHERE status IN ('confirmed', 'in_progress') 
            AND arrival_date <= %s AND departure_date >= %s
        ", $today, $today ) ) );

        $upcoming_arrivals = intval( $wpdb->get_var( $wpdb->prepare( "
            SELECT COUNT(*) FROM {$table_bks} 
            WHERE status = 'confirmed' 
            AND arrival_date > %s AND arrival_date <= %s
        ", $today, $next_30 ) ) );

        $completed_trips = intval( $wpdb->get_var( $wpdb->prepare( "
            SELECT COUNT(*) FROM {$table_bks} 
            WHERE status = 'completed' OR (status = 'confirmed' AND departure_date < %s)
        ", $today ) ) );

        $tasks_due_today = intval( $wpdb->get_var( $wpdb->prepare( "
            SELECT COUNT(*) FROM {$table_tasks} 
            WHERE status = 'pending' AND due_date = %s
        ", $today ) ) );

        $tasks_overdue = intval( $wpdb->get_var( $wpdb->prepare( "
            SELECT COUNT(*) FROM {$table_tasks} 
            WHERE status = 'pending' AND due_date < %s
        ", $today ) ) );

        $lead_sources = $wpdb->get_results( "
            SELECT lead_source, COUNT(*) as count 
            FROM {$table_opps} 
            GROUP BY lead_source 
            ORDER BY count DESC
        ", ARRAY_A );

        return [
            'total_enquiries'   => $total_enquiries,
            'new_enquiries'     => $new_enquiries,
            'qualified_leads'   => $qualified_leads,
            'quotes_sent'       => $quotes_sent,
            'confirmed_bookings'=> $confirmed_bks,
            'conversion_rate'   => $conversion_rate,
            'total_booking_val' => $total_booking_val,
            'total_gross_profit'=> $total_gross_prof,
            'payments_received' => $payments_received,
            'outstanding_bal'   => $outstanding_bal,
            'active_travellers' => $active_travellers,
            'upcoming_arrivals' => $upcoming_arrivals,
            'completed_trips'   => $completed_trips,
            'tasks_due_today'   => $tasks_due_today,
            'tasks_overdue'     => $tasks_overdue,
            'lead_sources'      => $lead_sources,
        ];
    }
}
endif;
