<?php
/**
 * Outbound Holidays CRM Bookings & Operations Management
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Outbound_CRM_Bookings' ) ) :
class Outbound_CRM_Bookings {

    public static function get_all( $limit = 100, $offset = 0 ) {
        global $wpdb;
        $table_bks  = Outbound_CRM_Database::get_table( 'bookings' );
        $table_cust = Outbound_CRM_Database::get_table( 'customers' );

        return $wpdb->get_results( $wpdb->prepare( "
            SELECT b.*, c.first_name, c.last_name, c.email, c.phone, c.whatsapp
            FROM {$table_bks} b
            LEFT JOIN {$table_cust} c ON b.customer_id = c.id
            ORDER BY b.id DESC
            LIMIT %d OFFSET %d
        ", $limit, $offset ), ARRAY_A );
    }

    public static function get( $id ) {
        global $wpdb;
        $table = Outbound_CRM_Database::get_table( 'bookings' );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A );
    }

    public static function confirm_from_opportunity( $opp_id, $data = [] ) {
        global $wpdb;
        $opp = Outbound_CRM_Enquiries::get( $opp_id );
        if ( ! $opp ) {
            return false;
        }

        $b_ref         = 'BK-' . current_time( 'Ymd' ) . '-' . strtoupper( wp_generate_password( 4, false ) );
        $selling_price = floatval( $data['selling_price'] ?? $opp['value'] );
        $supplier_cost = floatval( $data['supplier_cost'] ?? ( $selling_price * 0.75 ) );
        $gross_profit  = max( 0.0, $selling_price - $supplier_cost );
        $now           = current_time( 'mysql' );

        $table_bks = Outbound_CRM_Database::get_table( 'bookings' );
        $wpdb->insert( $table_bks, [
            'booking_ref'              => $b_ref,
            'opportunity_id'           => $opp_id,
            'customer_id'              => $opp['customer_id'],
            'status'                   => 'confirmed',
            'arrival_date'             => $opp['arrival_date'],
            'departure_date'           => $opp['departure_date'],
            'adults'                   => $opp['adults'],
            'children'                 => $opp['children'],
            'total_selling_price'      => $selling_price,
            'total_supplier_cost'      => $supplier_cost,
            'gross_profit'             => $gross_profit,
            'currency'                 => 'USD',
            'payment_status'           => 'unpaid',
            'operational_instructions' => sanitize_textarea_field( $data['operational_instructions'] ?? '' ),
            'created_at'               => $now,
            'updated_at'               => $now,
        ] );

        $booking_id = $wpdb->insert_id;

        // Advance opportunity to confirmed
        Outbound_CRM_Enquiries::update_stage( $opp_id, 'confirmed' );

        Outbound_CRM_Database::log_activity( [
            'customer_id'    => $opp['customer_id'],
            'opportunity_id' => $opp_id,
            'booking_id'     => $booking_id,
            'log_type'       => 'booking_confirmed',
            'title'          => sprintf( __( 'Booking %s confirmed ($%s)', 'outbound-headless' ), $b_ref, number_format( $selling_price, 2 ) ),
        ] );

        return $booking_id;
    }
}
endif;
