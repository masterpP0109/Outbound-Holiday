<?php
/**
 * Outbound Holidays — Visual Content Studio (Headless CMS Controller)
 *
 * Provides a comprehensive 14-section visual editing interface inside WordPress
 * for every editable element of the Outbound Holidays React frontend.
 *
 * @package OutboundHeadlessCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-cms-studio-catalog.php';
require_once __DIR__ . '/class-cms-studio-sections.php';

class Outbound_CMS_Studio {

	const OPTION_KEY         = 'outbound_cms_snapshot';
	const DRAFT_OPTION_KEY   = 'outbound_cms_draft_snapshot';
	const REVISIONS_KEY      = 'outbound_cms_revisions';
	const LEGACY_CACHE_KEY   = 'outbound_snapshot_cache';

	/**
	 * Static guard to prevent duplicate rendering on the same admin request
	 */
	private static $initialized = false;
	private static $rendered    = false;

	/**
	 * Authoritative 14-section navigation structure required by Outbound CMS
	 */
	public static function get_tabs(): array {
		return [
			'overview'        => [ 'label' => '1. Website Overview',        'icon' => 'dashicons-dashboard' ],
			'homepage'        => [ 'label' => '2. Homepage & Hero',         'icon' => 'dashicons-format-image' ],
			'experiences'     => [ 'label' => '3. Experiences',             'icon' => 'dashicons-Compass' ],
			'accommodation'   => [ 'label' => '4. Accommodation',           'icon' => 'dashicons-building' ],
			'packages'        => [ 'label' => '5. Holiday Packages',        'icon' => 'dashicons-palmtree' ],
			'guides'          => [ 'label' => '6. Guides & Articles',       'icon' => 'dashicons-book-alt' ],
			'galleries'       => [ 'label' => '7. Galleries & Media',       'icon' => 'dashicons-format-gallery' ],
			'reviews'         => [ 'label' => '8. Testimonials & Reviews',  'icon' => 'dashicons-star-filled' ],
			'about-contact'   => [ 'label' => '9. About & Contact',         'icon' => 'dashicons-id-alt' ],
			'header-nav'      => [ 'label' => '10. Header & Navigation',    'icon' => 'dashicons-menu' ],
			'footer-global'   => [ 'label' => '11. Footer & Global Content','icon' => 'dashicons-admin-site' ],
			'holiday-builder' => [ 'label' => '12. Holiday Builder Settings','icon' => 'dashicons-Forms' ],
			'design-layout'   => [ 'label' => '13. Design & Layout',        'icon' => 'dashicons-layout' ],
			'seo-publishing'  => [ 'label' => '14. SEO & Publishing',       'icon' => 'dashicons-chart-area' ],
		];
	}

	/**
	 * Resolve legacy tab aliases to canonical 14-section slugs
	 */
	public static function normalize_tab( string $tab ): string {
		$aliases = [
			'hero'      => 'homepage',
			'stays'     => 'accommodation',
			'gallery'   => 'galleries',
			'header'    => 'header-nav',
			'enquiries' => 'overview',
		];
		$tab = $aliases[ $tab ] ?? $tab;
		$tabs = self::get_tabs();
		return isset( $tabs[ $tab ] ) ? $tab : 'overview';
	}

	/**
	 * Initialize hooks (guarded against multiple calls)
	 */
	public static function init(): void {
		if ( self::$initialized ) {
			return;
		}
		self::$initialized = true;
		add_action( 'admin_menu', [ __CLASS__, 'register_menu' ], 99 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
	}

	/**
	 * Register WordPress Admin Menu "Outbound CMS" & 14 Submenu Items
	 * Ensures any legacy or duplicate menu/callback on `outbound-cms` is cleared first.
	 */
	public static function register_menu(): void {
		global $submenu;

		// Remove any legacy/duplicate menu page or callbacks registered earlier on this hook
		remove_menu_page( 'outbound-cms' );
		remove_menu_page( 'outbound-settings' );
		remove_all_actions( 'toplevel_page_outbound-cms' );
		if ( isset( $submenu['outbound-cms'] ) ) {
			unset( $submenu['outbound-cms'] );
		}

		add_menu_page(
			__( 'Outbound CMS — Content Studio', 'outbound-headless' ),
			__( 'Outbound CMS', 'outbound-headless' ),
			'edit_posts',
			'outbound-cms',
			[ __CLASS__, 'render_studio' ],
			'dashicons-welcome-widgets-menus',
			25
		);

		foreach ( self::get_tabs() as $slug => $info ) {
			$is_first  = ( 'overview' === $slug );
			$menu_slug = $is_first ? 'outbound-cms' : 'outbound-cms-' . $slug;
			// CRITICAL: Pass the exact same array callback [ __CLASS__, 'render_studio' ] for the first submenu item
			// so WordPress does NOT attach a second anonymous Closure callback to `toplevel_page_outbound-cms`!
			$callback  = $is_first
				? [ __CLASS__, 'render_studio' ]
				: function () use ( $slug ) {
					$_GET['tab'] = $slug;
					self::render_studio();
				};

			add_submenu_page(
				'outbound-cms',
				$info['label'] . ' — Outbound CMS',
				$info['label'],
				'edit_posts',
				$menu_slug,
				$callback
			);
		}
	}

	/**
	 * Enqueue WP Media Uploader & Studio Assets
	 */
	public static function enqueue_assets( $hook ): void {
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		if ( false === strpos( (string) $hook, 'outbound-cms' ) && 0 !== strpos( $page, 'outbound-cms' ) ) {
			return;
		}

		wp_enqueue_media();

		$plugin_url = defined( 'OUTBOUND_CORE_URL' ) ? OUTBOUND_CORE_URL : plugin_dir_url( dirname( __FILE__ ) );
		$version    = defined( 'OUTBOUND_CORE_VERSION' ) ? OUTBOUND_CORE_VERSION : '2.2.0';

		wp_enqueue_style(
			'outbound-cms-studio',
			$plugin_url . 'assets/css/cms-studio.css',
			[],
			$version . '.' . time()
		);

		wp_enqueue_script(
			'outbound-cms-studio',
			$plugin_url . 'assets/js/cms-studio.js',
			[ 'jquery' ],
			$version . '.' . time(),
			true
		);
	}

	/**
	 * Load authoritative default snapshot from published-content.json
	 */
	public static function get_default_snapshot(): array {
		$plugin_dir = defined( 'OUTBOUND_CORE_DIR' ) ? OUTBOUND_CORE_DIR : plugin_dir_path( dirname( __FILE__ ) );
		$json_file  = $plugin_dir . 'published-content.json';

		if ( ! file_exists( $json_file ) && function_exists( 'get_template_directory' ) ) {
			$theme_file = get_template_directory() . '/published-content.json';
			if ( file_exists( $theme_file ) ) {
				$json_file = $theme_file;
			}
		}

		if ( file_exists( $json_file ) ) {
			$raw  = file_get_contents( $json_file );
			$data = json_decode( (string) $raw, true );
			if ( is_array( $data ) && ! empty( $data['accommodations'] ) ) {
				return $data;
			}
		}

		return [];
	}

	/**
	 * Get live published snapshot (used by REST API & SSR hydration)
	 */
	public static function get_live_snapshot(): array {
		$saved = get_option( self::OPTION_KEY );
		if ( is_array( $saved ) && ! empty( $saved['accommodations'] ) ) {
			return self::sanitize_strict_snapshot( $saved );
		}

		$legacy = get_option( self::LEGACY_CACHE_KEY );
		if ( is_array( $legacy ) && ! empty( $legacy['accommodations'] ) ) {
			$clean = self::sanitize_strict_snapshot( $legacy );
			update_option( self::OPTION_KEY, $clean, false );
			return $clean;
		}

		$default = self::get_default_snapshot();
		if ( ! empty( $default ) ) {
			update_option( self::OPTION_KEY, $default, false );
			update_option( self::LEGACY_CACHE_KEY, $default, false );
		}

		return $default;
	}

	/**
	 * Get working snapshot for CMS Studio (prefers unpublished draft if present)
	 */
	public static function get_working_snapshot(): array {
		$draft = get_option( self::DRAFT_OPTION_KEY );
		if ( is_array( $draft ) && ! empty( $draft['accommodations'] ) ) {
			return self::sanitize_strict_snapshot( $draft );
		}
		return self::get_live_snapshot();
	}

	public static function has_draft(): bool {
		$draft = get_option( self::DRAFT_OPTION_KEY );
		return is_array( $draft ) && ! empty( $draft['accommodations'] );
	}

	/**
	 * Strip any non-schema keys from strict records so Zod SnapshotSchema.safeParse always succeeds
	 */
	public static function sanitize_strict_snapshot( array $snapshot ): array {
		foreach ( [ 'accommodations', 'experiences', 'packages', 'guides' ] as $collection ) {
			if ( ! empty( $snapshot[ $collection ] ) && is_array( $snapshot[ $collection ] ) ) {
				foreach ( $snapshot[ $collection ] as $i => $item ) {
					if ( is_array( $item ) && array_key_exists( 'featured', $item ) ) {
						unset( $snapshot[ $collection ][ $i ]['featured'] );
					}
					if ( 'accommodations' === $collection && ! empty( $item['roomTypes'] ) && is_array( $item['roomTypes'] ) ) {
						foreach ( $item['roomTypes'] as $r_idx => $rt ) {
							if ( is_array( $rt ) ) {
								if ( ! empty( $rt['image'] ) && empty( $rt['imageUrl'] ) ) {
									$snapshot[ $collection ][ $i ]['roomTypes'][ $r_idx ]['imageUrl'] = $rt['image'];
								}
								unset( $snapshot[ $collection ][ $i ]['roomTypes'][ $r_idx ]['image'] );
							}
						}
					}
				}
			}
		}
		return $snapshot;
	}

	/**
	 * Save draft snapshot without updating live website yet
	 */
	public static function save_draft_snapshot( array $snapshot ): void {
		$snapshot = self::sanitize_strict_snapshot( $snapshot );
		$snapshot['version'] = gmdate( 'Y-m-d\TH:i:s.v\Z' );
		update_option( self::DRAFT_OPTION_KEY, $snapshot, false );
	}

	/**
	 * Publish snapshot to live website, record revision history, and sync options
	 */
	public static function save_live_snapshot( array $snapshot, string $tab = 'general' ): void {
		$snapshot = self::sanitize_strict_snapshot( $snapshot );
		$snapshot['version'] = gmdate( 'Y-m-d\TH:i:s.v\Z' );

		update_option( self::OPTION_KEY, $snapshot, false );
		update_option( self::LEGACY_CACHE_KEY, $snapshot, false );
		delete_option( self::DRAFT_OPTION_KEY );

		// Keep secondary WordPress options synchronized
		if ( isset( $snapshot['albums'] ) ) {
			update_option( 'outbound_albums_data', $snapshot['albums'], false );
		}
		if ( isset( $snapshot['builderActivities'] ) ) {
			update_option( 'outbound_builder_activities', $snapshot['builderActivities'], false );
		}
		if ( isset( $snapshot['stayTiers'] ) ) {
			update_option( 'outbound_stay_tiers', $snapshot['stayTiers'], false );
		}
		if ( isset( $snapshot['site'] ) ) {
			update_option( 'outbound_site_data', $snapshot['site'], false );
		}

		self::record_revision( $snapshot, $tab );
	}

	/**
	 * Record a timestamped snapshot revision (retains latest 12 revisions)
	 */
	public static function record_revision( array $snapshot, string $tab ): void {
		$revisions = get_option( self::REVISIONS_KEY, [] );
		if ( ! is_array( $revisions ) ) {
			$revisions = [];
		}
		$user = function_exists( 'wp_get_current_user' ) ? wp_get_current_user() : null;
		array_unshift( $revisions, [
			'id'        => uniqid( 'rev_', false ),
			'timestamp' => gmdate( 'Y-m-d H:i:s' ),
			'tab'       => $tab,
			'user'      => ( $user && ! empty( $user->user_login ) ) ? $user->user_login : 'admin',
			'version'   => $snapshot['version'] ?? '',
			'snapshot'  => $snapshot,
		] );
		$revisions = array_slice( $revisions, 0, 12 );
		update_option( self::REVISIONS_KEY, $revisions, false );
	}

	public static function get_revisions(): array {
		$revs = get_option( self::REVISIONS_KEY, [] );
		return is_array( $revs ) ? $revs : [];
	}

	/**
	 * Helper: Apply generic `strings[...]` and `structure_images[...]` from any tab form
	 */
	private static function apply_common_editorial_fields( array &$snapshot ): void {
		if ( ! empty( $_POST['strings'] ) && is_array( $_POST['strings'] ) ) {
			foreach ( wp_unslash( $_POST['strings'] ) as $k => $v ) {
				$snapshot['site']['editorial']['strings'][ sanitize_text_field( $k ) ] = sanitize_textarea_field( $v );
			}
		}
		if ( ! empty( $_POST['structure_images'] ) && is_array( $_POST['structure_images'] ) ) {
			foreach ( wp_unslash( $_POST['structure_images'] ) as $k => $v ) {
				$snapshot['site']['editorial']['structures'][ sanitize_text_field( $k ) ] = esc_url_raw( $v );
			}
		}
	}

	/**
	 * Process POST submissions across all 14 sections
	 */
	private static function process_save(): ?string {
		if ( empty( $_POST['outbound_cms_nonce'] ) || ! wp_verify_nonce( $_POST['outbound_cms_nonce'], 'outbound_cms_save' ) ) {
			return null;
		}

		if ( ! current_user_can( 'edit_posts' ) ) {
			return null;
		}

		// Action 1: Reset to Factory Seed
		if ( ! empty( $_POST['cms_action'] ) && 'reset_defaults' === $_POST['cms_action'] ) {
			$default = self::get_default_snapshot();
			if ( ! empty( $default ) ) {
				self::save_live_snapshot( $default, 'factory-reset' );
				return 'Reset to factory default content snapshot completed!';
			}
		}

		// Action 2: Publish Pending Draft Immediately
		if ( ! empty( $_POST['cms_action'] ) && 'publish_draft' === $_POST['cms_action'] ) {
			$draft = get_option( self::DRAFT_OPTION_KEY );
			if ( is_array( $draft ) && ! empty( $draft['accommodations'] ) ) {
				self::save_live_snapshot( $draft, 'publish-draft' );
				return 'Draft published to live website!';
			}
		}

		// Action 3: Discard Draft
		if ( ! empty( $_POST['cms_action'] ) && 'discard_draft' === $_POST['cms_action'] ) {
			delete_option( self::DRAFT_OPTION_KEY );
			return 'Unpublished draft discarded. Reverted to live snapshot.';
		}

		// Action 4: Restore Historical Revision
		if ( ! empty( $_POST['cms_restore_revision'] ) ) {
			$rev_id = sanitize_text_field( wp_unslash( $_POST['cms_restore_revision'] ) );
			foreach ( self::get_revisions() as $idx => $rev ) {
				if ( ( $rev['id'] ?? (string) $idx ) === $rev_id && ! empty( $rev['snapshot'] ) && is_array( $rev['snapshot'] ) ) {
					self::save_live_snapshot( $rev['snapshot'], 'restore-revision' );
					return 'Revision from ' . ( $rev['timestamp'] ?? '' ) . ' restored and published live!';
				}
			}
		}

		// Action 5: Full Snapshot JSON Import
		if ( ! empty( $_POST['cms_import_snapshot_json'] ) ) {
			$raw_import = trim( wp_unslash( $_POST['cms_import_snapshot_json'] ) );
			if ( '' !== $raw_import ) {
				$decoded = json_decode( $raw_import, true );
				if ( is_array( $decoded ) && ! empty( $decoded['accommodations'] ) && ! empty( $decoded['site'] ) ) {
					self::save_live_snapshot( $decoded, 'json-import' );
					return 'Full ContentSnapshot JSON imported and published live!';
				}
			}
		}

		$tab         = self::normalize_tab( sanitize_key( $_POST['cms_tab'] ?? 'overview' ) );
		$submit_mode = sanitize_key( $_POST['cms_submit_mode'] ?? 'publish' );
		$snapshot    = self::get_working_snapshot();

		// Always apply any `strings[...]` and `structure_images[...]` present in the form
		self::apply_common_editorial_fields( $snapshot );

		// ---------------------------------------------------------------------
		// TAB 2: HOMEPAGE & HERO
		// ---------------------------------------------------------------------
		if ( 'homepage' === $tab ) {
			if ( isset( $_POST['slides'] ) && is_array( $_POST['slides'] ) ) {
				$existing_slides = $snapshot['site']['editorial']['structures']['travel/TravelHero.slides'] ?? [];
				$new_slides      = [];
				foreach ( wp_unslash( $_POST['slides'] ) as $i => $s ) {
					$base      = $existing_slides[ $i ] ?? ( $existing_slides[0] ?? [] );
					$line1     = sanitize_text_field( $s['headline_1'] ?? '' );
					$line2     = sanitize_text_field( $s['headline_2'] ?? '' );
					$img_url   = esc_url_raw( $s['imageUrl'] ?? ( $base['imageUrl'] ?? '' ) );
					$icon_name = in_array( $s['iconName'] ?? '', [ 'Users', 'Heart', 'Compass' ], true ) ? $s['iconName'] : 'Compass';

					$new_slides[] = [
						'id'             => sanitize_text_field( $s['id'] ?? 'slide-' . ( count( $new_slides ) + 1 ) ),
						'altText'        => sanitize_text_field( $s['altText'] ?? '' ),
						'headline'       => [
							'$element' => [
								'name'     => '#fragment',
								'props'    => new stdClass(),
								'children' => [
									$line1 . ' ',
									[
										'$element' => [
											'name'     => 'br',
											'props'    => [ 'className' => 'hidden sm:inline' ],
											'children' => [],
										],
									],
									$line2,
								],
							],
						],
						'imageUrl'       => $img_url,
						'titleTag'       => sanitize_text_field( $s['titleTag'] ?? '' ),
						'badgeIcon'      => [
							'$element' => [
								'name'     => $icon_name,
								'props'    => [ 'className' => 'w-3.5 h-3.5 text-[#C9A66B]' ],
								'children' => [],
							],
						],
						'description'    => sanitize_textarea_field( $s['description'] ?? '' ),
						'fallbackUrl'    => $img_url,
						'primaryCtaText' => sanitize_text_field( $s['primaryCtaText'] ?? 'Plan My Holiday' ),
					];
				}
				if ( ! empty( $new_slides ) ) {
					$snapshot['site']['editorial']['structures']['travel/TravelHero.slides'] = array_values( $new_slides );
				}
			}

			if ( isset( $_POST['why_cards'] ) && is_array( $_POST['why_cards'] ) ) {
				$existing = $snapshot['site']['editorial']['structures']['travel/WhyChooseOutbound.section1'] ?? [];
				foreach ( wp_unslash( $_POST['why_cards'] ) as $idx => $wc ) {
					if ( isset( $existing[ $idx ] ) ) {
						$existing[ $idx ]['title']       = sanitize_text_field( $wc['title'] ?? '' );
						$existing[ $idx ]['label']       = sanitize_text_field( $wc['label'] ?? '' );
						$existing[ $idx ]['description'] = sanitize_textarea_field( $wc['description'] ?? '' );
					}
				}
				$snapshot['site']['editorial']['structures']['travel/WhyChooseOutbound.section1'] = $existing;
			}

			if ( isset( $_POST['guide_preview_cards'] ) && is_array( $_POST['guide_preview_cards'] ) ) {
				$existing = $snapshot['site']['editorial']['structures']['travel/VicFallsGuide.section1'] ?? [];
				foreach ( wp_unslash( $_POST['guide_preview_cards'] ) as $idx => $gc ) {
					if ( isset( $existing[ $idx ] ) ) {
						$existing[ $idx ]['title']       = sanitize_text_field( $gc['title'] ?? '' );
						$existing[ $idx ]['description'] = sanitize_textarea_field( $gc['description'] ?? '' );
					}
				}
				$snapshot['site']['editorial']['structures']['travel/VicFallsGuide.section1'] = $existing;
			}

			if ( isset( $_POST['how_we_help_cards'] ) && is_array( $_POST['how_we_help_cards'] ) ) {
				$existing = $snapshot['site']['editorial']['structures']['travel/HowWeHelp.section1'] ?? [];
				foreach ( wp_unslash( $_POST['how_we_help_cards'] ) as $idx => $hc ) {
					if ( isset( $existing[ $idx ] ) ) {
						$existing[ $idx ]['title']       = sanitize_text_field( $hc['title'] ?? '' );
						$existing[ $idx ]['description'] = sanitize_textarea_field( $hc['description'] ?? '' );
					}
				}
				$snapshot['site']['editorial']['structures']['travel/HowWeHelp.section1'] = $existing;
			}
		}

		// ---------------------------------------------------------------------
		// TAB 3: EXPERIENCES
		// ---------------------------------------------------------------------
		if ( 'experiences' === $tab && isset( $_POST['experiences'] ) && is_array( $_POST['experiences'] ) ) {
			$existing     = $snapshot['experiences'] ?? [];
			$by_id        = array_column( $existing, null, 'id' );
			$template     = $existing[0] ?? [];
			$updated      = [];
			$featured_ids = [];

			foreach ( wp_unslash( $_POST['experiences'] ) as $idx => $in ) {
				$id   = sanitize_text_field( $in['id'] ?? 'exp-' . ( $idx + 1 ) );
				$exp  = $by_id[ $id ] ?? ( $existing[ $idx ] ?? $template );
				unset( $exp['featured'] );

				$exp['id']               = $id;
				$exp['title']            = sanitize_text_field( $in['title'] ?? ( $exp['title'] ?? '' ) );
				$exp['slug']             = sanitize_title( $in['slug'] ?: $exp['title'] );
				$exp['subtitle']         = sanitize_text_field( $in['subtitle'] ?? ( $exp['subtitle'] ?? '' ) );
				$exp['duration']         = sanitize_text_field( $in['duration'] ?? ( $exp['duration'] ?? '' ) );
				$exp['priceAmount']      = floatval( $in['priceAmount'] ?? ( $exp['priceAmount'] ?? 0 ) );
				$exp['fromPrice']        = ! empty( $in['fromPrice'] ) ? sanitize_text_field( $in['fromPrice'] ) : 'From $' . intval( $exp['priceAmount'] ) . ' pp';
				$exp['location']         = sanitize_text_field( $in['location'] ?? ( $exp['location'] ?? 'Victoria Falls, Zimbabwe' ) );
				$exp['shortDescription'] = sanitize_textarea_field( $in['shortDescription'] ?? ( $exp['shortDescription'] ?? '' ) );
				$exp['fullOverview']     = sanitize_textarea_field( $in['fullOverview'] ?? ( $exp['fullOverview'] ?? '' ) );
				$exp['whyWeRecommend']   = sanitize_textarea_field( $in['whyWeRecommend'] ?? ( $exp['whyWeRecommend'] ?? '' ) );
				$exp['localExpertTip']   = sanitize_textarea_field( $in['localExpertTip'] ?? ( $exp['localExpertTip'] ?? '' ) );
				$exp['featuredImage']    = esc_url_raw( $in['featuredImage'] ?? ( $exp['featuredImage'] ?? '' ) );

				$badge = sanitize_text_field( $in['badge'] ?? '' );
				if ( '' !== $badge ) {
					$exp['badge'] = $badge;
				} else {
					unset( $exp['badge'] );
				}

				if ( isset( $in['categories_csv'] ) ) {
					$exp['categories'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', $in['categories_csv'] ) ) ) ) );
				}
				if ( isset( $in['relatedIds_csv'] ) ) {
					$exp['relatedIds'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', $in['relatedIds_csv'] ) ) ) ) );
				}
				if ( isset( $in['highlights_raw'] ) ) {
					$exp['highlights'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( "\n", $in['highlights_raw'] ) ) ) ) );
				}
				if ( isset( $in['included_raw'] ) ) {
					$exp['whatsIncluded'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( "\n", $in['included_raw'] ) ) ) ) );
				}
				if ( isset( $in['excluded_raw'] ) ) {
					$exp['whatsExcluded'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( "\n", $in['excluded_raw'] ) ) ) ) );
				}
				if ( isset( $in['goodToKnow_raw'] ) ) {
					$exp['goodToKnow'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( "\n", $in['goodToKnow_raw'] ) ) ) ) );
				}

				if ( isset( $in['galleryImages'] ) && is_array( $in['galleryImages'] ) ) {
					$exp['galleryImages'] = array_values( array_filter( array_map( 'esc_url_raw', $in['galleryImages'] ) ) );
				}
				if ( empty( $exp['galleryImages'] ) && ! empty( $exp['featuredImage'] ) ) {
					$exp['galleryImages'] = [ $exp['featuredImage'] ];
				}

				if ( ! empty( $in['steps_json'] ) ) {
					$decoded_steps = json_decode( $in['steps_json'], true );
					if ( is_array( $decoded_steps ) ) {
						$exp['steps'] = array_values( $decoded_steps );
					}
				}
				if ( ! empty( $in['faqs_json'] ) ) {
					$decoded_faqs = json_decode( $in['faqs_json'], true );
					if ( is_array( $decoded_faqs ) ) {
						$exp['faqs'] = array_values( $decoded_faqs );
					}
				}

				if ( ! empty( $in['is_featured'] ) ) {
					$featured_ids[] = $exp['id'];
				}

				$updated[] = $exp;
			}

			$snapshot['experiences'] = $updated;
			$snapshot['site']['featured']['experienceIds'] = array_values( array_unique( $featured_ids ) );

			if ( ! empty( $_POST['exp_cat_details'] ) && is_array( $_POST['exp_cat_details'] ) ) {
				$cat_details = $snapshot['site']['editorial']['structures']['travel/ExperienceCategoryPage.CATEGORY_DETAILS'] ?? [];
				foreach ( wp_unslash( $_POST['exp_cat_details'] ) as $c_key => $c_in ) {
					if ( isset( $cat_details[ $c_key ] ) ) {
						$cat_details[ $c_key ]['title']      = sanitize_text_field( $c_in['title'] ?? '' );
						$cat_details[ $c_key ]['introTitle'] = sanitize_text_field( $c_in['introTitle'] ?? '' );
						$cat_details[ $c_key ]['subtitle']   = sanitize_text_field( $c_in['subtitle'] ?? '' );
						$cat_details[ $c_key ]['heroImage']  = esc_url_raw( $c_in['heroImage'] ?? '' );
					}
				}
				$snapshot['site']['editorial']['structures']['travel/ExperienceCategoryPage.CATEGORY_DETAILS'] = $cat_details;
			}
		}

		// ---------------------------------------------------------------------
		// TAB 4: ACCOMMODATION
		// ---------------------------------------------------------------------
		if ( 'accommodation' === $tab && isset( $_POST['accommodations'] ) && is_array( $_POST['accommodations'] ) ) {
			$existing     = $snapshot['accommodations'] ?? [];
			$by_id        = array_column( $existing, null, 'id' );
			$template     = $existing[0] ?? [];
			$updated      = [];
			$featured_ids = [];
			$valid_cats   = [ 'Luxury Lodge', 'Boutique Hotel', 'Guest Lodge', 'Safari Lodge', 'Resort', 'Self-Catering' ];
			$valid_badges = [ 'Luxury', 'Boutique', 'Best Value', 'Family Friendly', 'Safari', 'Romantic' ];
			$valid_tags   = [ 'walking-distance', 'luxury-stays', 'boutique-quiet', 'family-friendly', 'romantic-escapes', 'best-value' ];

			foreach ( wp_unslash( $_POST['accommodations'] ) as $idx => $in ) {
				$id  = sanitize_text_field( $in['id'] ?? 'stay-' . ( $idx + 1 ) );
				$acc = $by_id[ $id ] ?? ( $existing[ $idx ] ?? $template );
				unset( $acc['featured'] );

				$acc['id']                = $id;
				$acc['name']              = sanitize_text_field( $in['name'] ?? ( $acc['name'] ?? '' ) );
				$acc['slug']              = sanitize_title( $in['slug'] ?: $acc['name'] );
				$acc['category']          = in_array( $in['category'] ?? '', $valid_cats, true ) ? $in['category'] : 'Boutique Hotel';
				$acc['priceFromUSD']      = floatval( $in['priceFromUSD'] ?? ( $acc['priceFromUSD'] ?? 0 ) );
				$acc['rating']            = floatval( $in['rating'] ?? ( $acc['rating'] ?? 4.8 ) );
				$acc['reviewCount']       = intval( $in['reviewCount'] ?? ( $acc['reviewCount'] ?? 100 ) );
				$acc['location']          = sanitize_text_field( $in['location'] ?? ( $acc['location'] ?? '' ) );
				$acc['distanceFromFalls'] = sanitize_text_field( $in['distanceFromFalls'] ?? ( $acc['distanceFromFalls'] ?? '' ) );
				$acc['airportDistance']   = sanitize_text_field( $in['airportDistance'] ?? ( $acc['airportDistance'] ?? '' ) );
				$acc['tagline']           = sanitize_text_field( $in['tagline'] ?? ( $acc['tagline'] ?? '' ) );
				$acc['shortDescription']  = sanitize_textarea_field( $in['shortDescription'] ?? ( $acc['shortDescription'] ?? '' ) );
				$acc['editorialOverview'] = sanitize_textarea_field( $in['editorialOverview'] ?? ( $acc['editorialOverview'] ?? '' ) );
				$acc['whyWeRecommend']    = sanitize_textarea_field( $in['whyWeRecommend'] ?? ( $acc['whyWeRecommend'] ?? '' ) );
				$acc['heroImage']         = esc_url_raw( $in['heroImage'] ?? ( $acc['heroImage'] ?? '' ) );

				$badge = sanitize_text_field( $in['badge'] ?? '' );
				if ( in_array( $badge, $valid_badges, true ) ) {
					$acc['badge'] = $badge;
				} else {
					unset( $acc['badge'] );
				}

				if ( isset( $in['filterTags_csv'] ) ) {
					$raw_tags = array_map( 'trim', explode( ',', $in['filterTags_csv'] ) );
					$acc['filterTags'] = array_values( array_intersect( $raw_tags, $valid_tags ) );
				}

				if ( isset( $in['galleryImages'] ) && is_array( $in['galleryImages'] ) ) {
					$acc['galleryImages'] = array_values( array_filter( array_map( 'esc_url_raw', $in['galleryImages'] ) ) );
				}
				if ( empty( $acc['galleryImages'] ) && ! empty( $acc['heroImage'] ) ) {
					$acc['galleryImages'] = [ $acc['heroImage'] ];
				}

				if ( ! empty( $in['atAGlance'] ) && is_array( $in['atAGlance'] ) ) {
					foreach ( $in['atAGlance'] as $gk => $gv ) {
						$acc['atAGlance'][ sanitize_text_field( $gk ) ] = sanitize_text_field( $gv );
					}
				}

				if ( ! empty( $in['roomTypes'] ) && is_array( $in['roomTypes'] ) ) {
					foreach ( $in['roomTypes'] as $r_idx => $r_in ) {
						if ( isset( $acc['roomTypes'][ $r_idx ] ) ) {
							$acc['roomTypes'][ $r_idx ]['name']        = sanitize_text_field( $r_in['name'] ?? '' );
							$acc['roomTypes'][ $r_idx ]['occupancy']   = sanitize_text_field( $r_in['occupancy'] ?? '' );
							$acc['roomTypes'][ $r_idx ]['description'] = sanitize_textarea_field( $r_in['description'] ?? '' );
							$acc['roomTypes'][ $r_idx ]['image']       = esc_url_raw( $r_in['image'] ?? '' );
							if ( isset( $r_in['features_csv'] ) ) {
								$acc['roomTypes'][ $r_idx ]['features'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', $r_in['features_csv'] ) ) ) ) );
							}
						}
					}
				}

				if ( isset( $in['locationInfo']['address'] ) ) {
					$acc['locationInfo']['address'] = sanitize_text_field( $in['locationInfo']['address'] );
				}
				if ( isset( $in['nearbyExperienceIds_csv'] ) ) {
					$acc['nearbyExperienceIds'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', $in['nearbyExperienceIds_csv'] ) ) ) ) );
				}
				if ( isset( $in['relatedPropertyIds_csv'] ) ) {
					$acc['relatedPropertyIds'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', $in['relatedPropertyIds_csv'] ) ) ) ) );
				}

				if ( ! empty( $in['is_featured'] ) ) {
					$featured_ids[] = $acc['slug'];
				}

				$updated[] = $acc;
			}

			$snapshot['accommodations'] = $updated;
			$snapshot['site']['featured']['accommodationIds'] = array_values( array_unique( $featured_ids ) );
		}

		// ---------------------------------------------------------------------
		// TAB 5: HOLIDAY PACKAGES
		// ---------------------------------------------------------------------
		if ( 'packages' === $tab && isset( $_POST['packages'] ) && is_array( $_POST['packages'] ) ) {
			$existing     = $snapshot['packages'] ?? [];
			$by_id        = array_column( $existing, null, 'id' );
			$template     = $existing[0] ?? [];
			$updated      = [];
			$featured_ids = [];
			$valid_badges = [ 'Best Value', 'Luxury', 'Family Favourites', 'Adventure', 'Signature', 'Popular' ];
			$valid_cats   = [ 'value', 'luxury', 'family', 'adventure', 'safari', 'first-visit', 'couples' ];
			$valid_filter_cats = [ 'first-visit', 'couples', 'families', 'luxury', 'adventure', 'safari', 'value' ];

			foreach ( wp_unslash( $_POST['packages'] ) as $idx => $in ) {
				$id  = sanitize_text_field( $in['id'] ?? 'pkg-' . ( $idx + 1 ) );
				$pkg = $by_id[ $id ] ?? ( $existing[ $idx ] ?? $template );
				unset( $pkg['featured'] );

				$pkg['id']                = $id;
				$pkg['title']             = sanitize_text_field( $in['title'] ?? ( $pkg['title'] ?? '' ) );
				$pkg['slug']              = sanitize_title( $in['slug'] ?: $pkg['title'] );
				$pkg['duration']          = sanitize_text_field( $in['duration'] ?? ( $pkg['duration'] ?? '' ) );
				$pkg['priceUSD']          = floatval( $in['priceUSD'] ?? ( $pkg['priceUSD'] ?? 0 ) );
				$pkg['badge']             = in_array( $in['badge'] ?? '', $valid_badges, true ) ? $in['badge'] : ( in_array( $pkg['badge'] ?? '', $valid_badges, true ) ? $pkg['badge'] : 'Popular' );
				$pkg['category']          = in_array( $in['category'] ?? '', $valid_cats, true ) ? $in['category'] : ( in_array( $pkg['category'] ?? '', $valid_cats, true ) ? $pkg['category'] : 'first-visit' );
				$pkg['travellerType']     = sanitize_text_field( $in['travellerType'] ?? ( $pkg['travellerType'] ?? '' ) );
				$pkg['tagline']           = sanitize_text_field( $in['tagline'] ?? ( $pkg['tagline'] ?? '' ) );
				$pkg['description']       = sanitize_textarea_field( $in['description'] ?? ( $pkg['description'] ?? '' ) );
				$pkg['storyIntroduction'] = sanitize_textarea_field( $in['storyIntroduction'] ?? ( $pkg['storyIntroduction'] ?? '' ) );
				$pkg['whyWeRecommend']    = sanitize_textarea_field( $in['whyWeRecommend'] ?? ( $pkg['whyWeRecommend'] ?? '' ) );
				$pkg['whyWeChoseStay']    = sanitize_textarea_field( $in['whyWeChoseStay'] ?? ( $pkg['whyWeChoseStay'] ?? '' ) );
				$pkg['imageUrl']          = esc_url_raw( $in['imageUrl'] ?? ( $pkg['imageUrl'] ?? '' ) );

				if ( isset( $in['categories_csv'] ) ) {
					$raw_cats = array_map( 'trim', explode( ',', $in['categories_csv'] ) );
					$filtered = array_values( array_intersect( $raw_cats, $valid_filter_cats ) );
					$pkg['categories'] = ! empty( $filtered ) ? $filtered : [ 'first-visit' ];
				}

				if ( isset( $in['highlights_raw'] ) ) {
					$pkg['highlights'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( "\n", $in['highlights_raw'] ) ) ) ) );
				}
				if ( isset( $in['included_raw'] ) ) {
					$pkg['included'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( "\n", $in['included_raw'] ) ) ) ) );
				}
				if ( isset( $in['notIncluded_raw'] ) ) {
					$pkg['notIncluded'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( "\n", $in['notIncluded_raw'] ) ) ) ) );
				}
				if ( isset( $in['includedExperienceIds_csv'] ) ) {
					$pkg['includedExperienceIds'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', $in['includedExperienceIds_csv'] ) ) ) ) );
				}
				if ( isset( $in['relatedPackageIds_csv'] ) ) {
					$pkg['relatedPackageIds'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', $in['relatedPackageIds_csv'] ) ) ) ) );
				}

				if ( ! empty( $in['highlightsMeta'] ) && is_array( $in['highlightsMeta'] ) ) {
					foreach ( $in['highlightsMeta'] as $hmk => $hmv ) {
						$pkg['highlightsMeta'][ sanitize_text_field( $hmk ) ] = sanitize_text_field( $hmv );
					}
				}

				if ( isset( $in['galleryImages'] ) && is_array( $in['galleryImages'] ) ) {
					$pkg['galleryImages'] = array_values( array_filter( array_map( 'esc_url_raw', $in['galleryImages'] ) ) );
				}
				if ( empty( $pkg['galleryImages'] ) && ! empty( $pkg['imageUrl'] ) ) {
					$pkg['galleryImages'] = [ $pkg['imageUrl'] ];
				}

				foreach ( [ 'detailedItinerary', 'recommendedHotels', 'faqs' ] as $json_field ) {
					$post_key = $json_field . '_json';
					if ( ! empty( $in[ $post_key ] ) ) {
						$decoded = json_decode( $in[ $post_key ], true );
						if ( is_array( $decoded ) ) {
							$pkg[ $json_field ] = array_values( $decoded );
						}
					}
				}

				if ( ! empty( $in['is_featured'] ) ) {
					$featured_ids[] = $pkg['id'];
				}

				$updated[] = $pkg;
			}

			$snapshot['packages'] = $updated;
			$snapshot['site']['featured']['packageIds'] = array_values( array_unique( $featured_ids ) );
		}

		// ---------------------------------------------------------------------
		// TAB 6: GUIDES & ARTICLES
		// ---------------------------------------------------------------------
		if ( 'guides' === $tab ) {
			if ( isset( $_POST['guides'] ) && is_array( $_POST['guides'] ) ) {
				$existing = $snapshot['guides'] ?? [];
				$by_id    = array_column( $existing, null, 'id' );
				$template = $existing[0] ?? [];
				$updated  = [];

				foreach ( wp_unslash( $_POST['guides'] ) as $idx => $in ) {
					$id  = sanitize_text_field( $in['id'] ?? 'guide-' . ( $idx + 1 ) );
					$gde = $by_id[ $id ] ?? ( $existing[ $idx ] ?? $template );
					unset( $gde['featured'] );

					$gde['id']              = $id;
					$gde['title']           = sanitize_text_field( $in['title'] ?? ( $gde['title'] ?? '' ) );
					$gde['slug']            = sanitize_title( $in['slug'] ?: $gde['title'] );
					$gde['category']        = sanitize_text_field( $in['category'] ?? ( $gde['category'] ?? '' ) );
					$gde['readingTime']     = sanitize_text_field( $in['readingTime'] ?? ( $gde['readingTime'] ?? '' ) );
					$gde['publishedDate']   = sanitize_text_field( $in['publishedDate'] ?? ( $gde['publishedDate'] ?? '' ) );
					$gde['lastUpdatedDate'] = sanitize_text_field( $in['lastUpdatedDate'] ?? ( $gde['lastUpdatedDate'] ?? '' ) );
					$gde['subtitle']        = sanitize_textarea_field( $in['subtitle'] ?? ( $gde['subtitle'] ?? '' ) );
					$gde['heroImageUrl']    = esc_url_raw( $in['heroImageUrl'] ?? ( $gde['heroImageUrl'] ?? '' ) );
					$gde['heroImageAlt']    = sanitize_text_field( $in['heroImageAlt'] ?? ( $gde['heroImageAlt'] ?? '' ) );

					if ( ! empty( $in['author'] ) && is_array( $in['author'] ) ) {
						$gde['author']['name']      = sanitize_text_field( $in['author']['name'] ?? ( $gde['author']['name'] ?? '' ) );
						$gde['author']['role']      = sanitize_text_field( $in['author']['role'] ?? ( $gde['author']['role'] ?? '' ) );
						$gde['author']['avatarUrl'] = esc_url_raw( $in['author']['avatarUrl'] ?? ( $gde['author']['avatarUrl'] ?? '' ) );
					}
					if ( ! empty( $in['seo'] ) && is_array( $in['seo'] ) ) {
						$gde['seo']['metaTitle']       = sanitize_text_field( $in['seo']['metaTitle'] ?? ( $gde['seo']['metaTitle'] ?? '' ) );
						$gde['seo']['metaDescription'] = sanitize_textarea_field( $in['seo']['metaDescription'] ?? ( $gde['seo']['metaDescription'] ?? '' ) );
					}

					if ( ! empty( $in['sections'] ) && is_array( $in['sections'] ) ) {
						foreach ( $in['sections'] as $s_idx => $s_in ) {
							if ( isset( $gde['sections'][ $s_idx ] ) ) {
								$gde['sections'][ $s_idx ]['tocTitle'] = sanitize_text_field( $s_in['tocTitle'] ?? '' );
								$gde['sections'][ $s_idx ]['heading']  = sanitize_text_field( $s_in['heading'] ?? '' );
								if ( ! empty( $s_in['blocks'] ) && is_array( $s_in['blocks'] ) ) {
									foreach ( $s_in['blocks'] as $b_idx => $b_in ) {
										if ( isset( $gde['sections'][ $s_idx ]['blocks'][ $b_idx ]['content'] ) && isset( $b_in['content'] ) ) {
											$gde['sections'][ $s_idx ]['blocks'][ $b_idx ]['content'] = sanitize_textarea_field( $b_in['content'] );
										}
									}
								}
							}
						}
					}

					foreach ( [ 'quickFacts', 'faqs' ] as $json_field ) {
						$post_key = $json_field . '_json';
						if ( ! empty( $in[ $post_key ] ) ) {
							$decoded = json_decode( $in[ $post_key ], true );
							if ( is_array( $decoded ) ) {
								$gde[ $json_field ] = array_values( $decoded );
							}
						}
					}

					$updated[] = $gde;
				}
				$snapshot['guides'] = $updated;
			}

			if ( ! empty( $_POST['guide_categories_json'] ) ) {
				$decoded_cats = json_decode( wp_unslash( $_POST['guide_categories_json'] ), true );
				if ( is_array( $decoded_cats ) ) {
					$snapshot['site']['guideCategories'] = array_values( $decoded_cats );
				}
			}
		}

		// ---------------------------------------------------------------------
		// TAB 7: GALLERIES & MEDIA
		// ---------------------------------------------------------------------
		if ( 'galleries' === $tab ) {
			if ( ! isset( $snapshot['albums'][0] ) ) {
				$snapshot['albums'][0] = [
					'id'       => 'album-client-memories',
					'slug'     => 'client-memories',
					'title'    => 'Client Memories',
					'featured' => true,
					'images'   => [],
				];
			}
			if ( empty( $snapshot['albums'][0]['id'] ) ) {
				$snapshot['albums'][0]['id'] = 'album-client-memories';
			}
			if ( isset( $_POST['album_meta'] ) && is_array( $_POST['album_meta'] ) ) {
				$am = wp_unslash( $_POST['album_meta'] );
				$snapshot['albums'][0]['title']    = sanitize_text_field( $am['title'] ?? 'Client Memories' );
				$snapshot['albums'][0]['slug']     = sanitize_title( $am['slug'] ?? 'client-memories' );
				$snapshot['albums'][0]['featured'] = ! empty( $am['featured'] );
			}

			if ( isset( $_POST['gallery'] ) && is_array( $_POST['gallery'] ) ) {
				$images = [];
				$order  = 0;
				foreach ( wp_unslash( $_POST['gallery'] ) as $img ) {
					$url = esc_url_raw( $img['url'] ?? '' );
					if ( empty( $url ) ) {
						continue;
					}
					$images[] = [
						'id'           => sanitize_text_field( $img['id'] ?? 'photo-' . ( $order + 1 ) ),
						'url'          => $url,
						'alt'          => sanitize_text_field( $img['alt'] ?? 'Outbound Holidays client photo' ),
						'caption'      => sanitize_text_field( $img['caption'] ?? '' ),
						'displayOrder' => $order++,
						'role'         => sanitize_text_field( $img['role'] ?? 'gallery' ),
					];
				}
				$snapshot['albums'][0]['images'] = $images;
			}

			if ( isset( $_POST['fungai_memories'] ) && is_array( $_POST['fungai_memories'] ) ) {
				$f_imgs = [];
				foreach ( wp_unslash( $_POST['fungai_memories'] ) as $fm ) {
					$src = esc_url_raw( $fm['src'] ?? '' );
					if ( empty( $src ) ) {
						continue;
					}
					$f_imgs[] = [
						'src'    => $src,
						'alt'    => sanitize_text_field( $fm['alt'] ?? 'Outbound Holidays memory' ),
						'width'  => 1080,
						'height' => 810,
					];
				}
				$snapshot['site']['editorial']['structures']['travel/AboutPage.fungaiMemories'] = $f_imgs;
			}

			if ( isset( $_POST['boma_gallery'] ) && is_array( $_POST['boma_gallery'] ) ) {
				$boma_urls = array_values( array_filter( array_map( 'esc_url_raw', wp_unslash( $_POST['boma_gallery'] ) ) ) );
				$snapshot['site']['editorial']['structures']['travel/BomaExperiencePage.section3'] = $boma_urls;
				$snapshot['site']['editorial']['structures']['travel/BomaExperiencePage.section4'] = $boma_urls;
			}

			if ( isset( $_POST['bungee_gallery'] ) && is_array( $_POST['bungee_gallery'] ) ) {
				$bungee_urls = array_values( array_filter( array_map( 'esc_url_raw', wp_unslash( $_POST['bungee_gallery'] ) ) ) );
				$snapshot['site']['editorial']['structures']['travel/BungeeExperiencePage.section5'] = $bungee_urls;
				$snapshot['site']['editorial']['structures']['travel/BungeeExperiencePage.section6'] = $bungee_urls;
			}
		}

		// ---------------------------------------------------------------------
		// TAB 8: TESTIMONIALS & REVIEWS
		// ---------------------------------------------------------------------
		if ( 'reviews' === $tab ) {
			if ( isset( $_POST['stories'] ) && is_array( $_POST['stories'] ) ) {
				$stories = [];
				foreach ( wp_unslash( $_POST['stories'] ) as $st ) {
					if ( empty( $st['text'] ) ) continue;
					$stories[] = [
						'text'     => sanitize_textarea_field( $st['text'] ?? '' ),
						'type'     => sanitize_text_field( $st['type'] ?? '' ),
						'initials' => sanitize_text_field( $st['initials'] ?? '' ),
						'location' => sanitize_text_field( $st['location'] ?? '' ),
					];
				}
				$snapshot['site']['editorial']['structures']['travel/TravellerStories.section1'] = $stories;
			}

			if ( isset( $_POST['reviews'] ) && is_array( $_POST['reviews'] ) ) {
				$revs = [];
				foreach ( wp_unslash( $_POST['reviews'] ) as $idx => $rv ) {
					if ( empty( $rv['author'] ) && empty( $rv['comment'] ) ) continue;
					$revs[] = [
						'id'            => sanitize_text_field( $rv['id'] ?? 'rev-' . ( $idx + 1 ) ),
						'author'        => sanitize_text_field( $rv['author'] ?? '' ),
						'roleOrCity'    => sanitize_text_field( $rv['roleOrCity'] ?? '' ),
						'avatar'        => esc_url_raw( $rv['avatar'] ?? '' ),
						'rating'        => max( 1, min( 5, intval( $rv['rating'] ?? 5 ) ) ),
						'date'          => sanitize_text_field( $rv['date'] ?? '' ),
						'title'         => sanitize_text_field( $rv['title'] ?? '' ),
						'comment'       => sanitize_textarea_field( $rv['comment'] ?? '' ),
						'verifiedBuyer' => ! empty( $rv['verifiedBuyer'] ),
					];
				}
				$snapshot['site']['legacy']['TRAVEL_REVIEWS'] = $revs;
			}
		}

		// ---------------------------------------------------------------------
		// TAB 9: ABOUT & CONTACT
		// ---------------------------------------------------------------------
		if ( 'about-contact' === $tab ) {
			if ( ! empty( $_POST['contact'] ) && is_array( $_POST['contact'] ) ) {
				$c = wp_unslash( $_POST['contact'] );
				$snapshot['site']['contact']['whatsappNumber'] = preg_replace( '/[^0-9]/', '', $c['whatsappNumber'] ?? '263714701721' );
				$snapshot['site']['contact']['displayNumber']  = sanitize_text_field( $c['displayNumber'] ?? '' );
				$snapshot['site']['contact']['email']          = sanitize_email( $c['email'] ?? '' );
				$snapshot['site']['contact']['address']        = sanitize_text_field( $c['address'] ?? '' );
				$snapshot['site']['contact']['hours']          = sanitize_text_field( $c['hours'] ?? '' );

				// Keep Contact Us & Footer address/hours strings synced when updated
				if ( ! empty( $snapshot['site']['contact']['address'] ) ) {
					$snapshot['site']['editorial']['strings']['travel/ContactUsView.text7'] = $snapshot['site']['contact']['address'];
					$snapshot['site']['editorial']['strings']['common/Footer.text4']        = $snapshot['site']['contact']['address'];
				}
				if ( ! empty( $snapshot['site']['contact']['hours'] ) ) {
					$snapshot['site']['editorial']['strings']['travel/ContactUsView.text11'] = $snapshot['site']['contact']['hours'];
				}
			}

			if ( isset( $_POST['notification_email'] ) ) {
				update_option( 'outbound_notification_email', sanitize_email( wp_unslash( $_POST['notification_email'] ) ) );
			}

			if ( isset( $_POST['about_services'] ) && is_array( $_POST['about_services'] ) ) {
				$existing = $snapshot['site']['editorial']['structures']['travel/AboutPage.services'] ?? [];
				foreach ( wp_unslash( $_POST['about_services'] ) as $idx => $srv ) {
					if ( isset( $existing[ $idx ] ) ) {
						$existing[ $idx ]['title'] = sanitize_text_field( $srv['title'] ?? '' );
						$existing[ $idx ]['copy']  = sanitize_textarea_field( $srv['copy'] ?? '' );
					}
				}
				$snapshot['site']['editorial']['structures']['travel/AboutPage.services'] = $existing;
			}

			if ( isset( $_POST['about_principles'] ) && is_array( $_POST['about_principles'] ) ) {
				$existing = $snapshot['site']['editorial']['structures']['travel/AboutPage.principles'] ?? [];
				foreach ( wp_unslash( $_POST['about_principles'] ) as $idx => $pr ) {
					if ( isset( $existing[ $idx ] ) ) {
						$existing[ $idx ]['title'] = sanitize_text_field( $pr['title'] ?? '' );
						$existing[ $idx ]['copy']  = sanitize_textarea_field( $pr['copy'] ?? '' );
					}
				}
				$snapshot['site']['editorial']['structures']['travel/AboutPage.principles'] = $existing;
			}
		}

		// ---------------------------------------------------------------------
		// TAB 10: HEADER & NAVIGATION
		// ---------------------------------------------------------------------
		if ( 'header-nav' === $tab ) {
			$nav_Input = isset( $_POST['nav_config'] ) && is_array( $_POST['nav_config'] ) ? wp_unslash( $_POST['nav_config'] ) : [];
			$snapshot['site']['editorial']['structures']['cms/navigation'] = [
				'showGuide'         => ! empty( $nav_Input['showGuide'] ),
				'showExperiences'   => ! empty( $nav_Input['showExperiences'] ),
				'showAccommodation' => ! empty( $nav_Input['showAccommodation'] ),
				'showPackages'      => ! empty( $nav_Input['showPackages'] ),
				'showGallery'       => ! empty( $nav_Input['showGallery'] ),
				'showAbout'         => ! empty( $nav_Input['showAbout'] ),
				'showContact'       => ! empty( $nav_Input['showContact'] ),
			];

			if ( ! empty( $_POST['rates'] ) && is_array( $_POST['rates'] ) ) {
				foreach ( wp_unslash( $_POST['rates'] ) as $code => $r ) {
					$c = sanitize_text_field( $code );
					$snapshot['site']['currencyRates'][ $c ] = [
						'symbol' => sanitize_text_field( $r['symbol'] ?? '$' ),
						'rate'   => floatval( $r['rate'] ?? 1 ),
					];
				}
			}
		}

		// ---------------------------------------------------------------------
		// TAB 11: FOOTER & GLOBAL CONTENT
		// ---------------------------------------------------------------------
		if ( 'footer-global' === $tab ) {
			if ( ! empty( $_POST['whatsapp_templates'] ) && is_array( $_POST['whatsapp_templates'] ) ) {
				$wt = wp_unslash( $_POST['whatsapp_templates'] );
				$snapshot['site']['editorial']['structures']['cms/whatsappTemplates'] = [
					'defaultGreeting'           => sanitize_textarea_field( $wt['defaultGreeting'] ?? '' ),
					'specialistTopicTemplate'   => sanitize_textarea_field( $wt['specialistTopicTemplate'] ?? '' ),
					'specialistGeneralTemplate' => sanitize_textarea_field( $wt['specialistGeneralTemplate'] ?? '' ),
					'closingLine'               => sanitize_text_field( $wt['closingLine'] ?? 'Thank you.' ),
				];
			}
		}

		// ---------------------------------------------------------------------
		// TAB 12: HOLIDAY BUILDER SETTINGS
		// ---------------------------------------------------------------------
		if ( 'holiday-builder' === $tab ) {
			if ( isset( $_POST['tiers'] ) && is_array( $_POST['tiers'] ) ) {
				$tiers = [];
				foreach ( wp_unslash( $_POST['tiers'] ) as $idx => $t ) {
					$tiers[] = [
						'id'               => sanitize_text_field( $t['id'] ?? 'tier-' . ( $idx + 1 ) ),
						'name'             => sanitize_text_field( $t['name'] ?? '' ),
						'tagline'          => sanitize_text_field( $t['tagline'] ?? '' ),
						'pricePerNightUSD' => floatval( $t['pricePerNightUSD'] ?? 0 ),
						'imageUrl'         => esc_url_raw( $t['imageUrl'] ?? '' ),
						'desc'             => sanitize_textarea_field( $t['desc'] ?? '' ),
						'highlights'       => array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( "\n", $t['highlights_raw'] ?? '' ) ) ) ) ),
					];
				}
				$snapshot['stayTiers'] = $tiers;
			}

			if ( isset( $_POST['bacts'] ) && is_array( $_POST['bacts'] ) ) {
				$bacts = [];
				foreach ( wp_unslash( $_POST['bacts'] ) as $idx => $ba ) {
					$bacts[] = [
						'id'           => sanitize_text_field( $ba['id'] ?? 'act-' . ( $idx + 1 ) ),
						'title'        => sanitize_text_field( $ba['title'] ?? '' ),
						'duration'     => sanitize_text_field( $ba['duration'] ?? '' ),
						'priceUSD'     => floatval( $ba['priceUSD'] ?? 0 ),
						'imageUrl'     => esc_url_raw( $ba['imageUrl'] ?? '' ),
						'badge'        => sanitize_text_field( $ba['badge'] ?? '' ),
						'shortDesc'    => sanitize_textarea_field( $ba['shortDesc'] ?? '' ),
						'whyRecommend' => sanitize_textarea_field( $ba['whyRecommend'] ?? '' ),
						'idealFor'     => array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', $ba['idealFor_csv'] ?? '' ) ) ) ) ),
					];
				}
				$snapshot['builderActivities'] = $bacts;
			}

			if ( isset( $_POST['builder_intents'] ) && is_array( $_POST['builder_intents'] ) ) {
				$existing = $snapshot['site']['editorial']['structures']['travel/HolidayBuilderModal.section1'] ?? [];
				foreach ( wp_unslash( $_POST['builder_intents'] ) as $idx => $it ) {
					if ( isset( $existing[ $idx ] ) ) {
						$existing[ $idx ]['icon']  = sanitize_text_field( $it['icon'] ?? '' );
						$existing[ $idx ]['title'] = sanitize_text_field( $it['title'] ?? '' );
						$existing[ $idx ]['desc']  = sanitize_text_field( $it['desc'] ?? '' );
					}
				}
				$snapshot['site']['editorial']['structures']['travel/HolidayBuilderModal.section1'] = $existing;
			}

			if ( isset( $_POST['builder_durations'] ) && is_array( $_POST['builder_durations'] ) ) {
				$existing = $snapshot['site']['editorial']['structures']['travel/HolidayBuilderModal.section3'] ?? [];
				foreach ( wp_unslash( $_POST['builder_durations'] ) as $idx => $dur ) {
					if ( isset( $existing[ $idx ] ) ) {
						$existing[ $idx ]['nights'] = intval( $dur['nights'] ?? 3 );
						$existing[ $idx ]['label']  = sanitize_text_field( $dur['label'] ?? '' );
						$existing[ $idx ]['badge']  = sanitize_text_field( $dur['badge'] ?? '' );
					}
				}
				$snapshot['site']['editorial']['structures']['travel/HolidayBuilderModal.section3'] = $existing;
			}

			if ( isset( $_POST['builder_stay_prefs_raw'] ) ) {
				$prefs = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( "\n", wp_unslash( $_POST['builder_stay_prefs_raw'] ) ) ) ) ) );
				$snapshot['site']['editorial']['structures']['travel/HolidayBuilderModal.section5'] = $prefs;
			}

			if ( isset( $_POST['builder_transfers'] ) && is_array( $_POST['builder_transfers'] ) ) {
				$existing = $snapshot['site']['editorial']['structures']['travel/HolidayBuilderModal.section6'] ?? [];
				foreach ( wp_unslash( $_POST['builder_transfers'] ) as $idx => $tr ) {
					if ( isset( $existing[ $idx ] ) ) {
						$existing[ $idx ]['title'] = sanitize_text_field( $tr['title'] ?? '' );
						$existing[ $idx ]['badge'] = sanitize_text_field( $tr['badge'] ?? '' );
						$existing[ $idx ]['desc']  = sanitize_textarea_field( $tr['desc'] ?? '' );
					}
				}
				$snapshot['site']['editorial']['structures']['travel/HolidayBuilderModal.section6'] = $existing;
			}
		}

		// ---------------------------------------------------------------------
		// TAB 13: DESIGN & LAYOUT
		// ---------------------------------------------------------------------
		if ( 'design-layout' === $tab ) {
			$dl_in = isset( $_POST['design_layout'] ) && is_array( $_POST['design_layout'] ) ? wp_unslash( $_POST['design_layout'] ) : [];
			$sec_in = isset( $_POST['homepage_sections'] ) && is_array( $_POST['homepage_sections'] ) ? wp_unslash( $_POST['homepage_sections'] ) : [];

			$homepage_sections = [];
			foreach ( $sec_in as $sec ) {
				if ( empty( $sec['id'] ) ) continue;
				$homepage_sections[] = [
					'id'      => sanitize_text_field( $sec['id'] ),
					'label'   => sanitize_text_field( $sec['label'] ?? $sec['id'] ),
					'visible' => ! empty( $sec['visible'] ),
				];
			}

			$snapshot['site']['editorial']['structures']['cms/designLayout'] = [
				'homepageSections'        => $homepage_sections,
				'heroAutoplayMs'          => max( 2000, intval( $dl_in['heroAutoplayMs'] ?? 5500 ) ),
				'heroImageFit'            => in_array( $dl_in['heroImageFit'] ?? '', [ 'fill', 'cover' ], true ) ? $dl_in['heroImageFit'] : 'fill',
				'heroOverlayOpacity'      => in_array( $dl_in['heroOverlayOpacity'] ?? '', [ 'default', 'light', 'dark' ], true ) ? $dl_in['heroOverlayOpacity'] : 'default',
				'showTopAnnouncementBar'  => ! empty( $dl_in['showTopAnnouncementBar'] ),
				'showCurrencySelector'    => ! empty( $dl_in['showCurrencySelector'] ),
				'showHeaderSearch'        => ! empty( $dl_in['showHeaderSearch'] ),
				'showReassuranceBullets'  => ! empty( $dl_in['showReassuranceBullets'] ),
				'showFloatingSupportCard' => ! empty( $dl_in['showFloatingSupportCard'] ),
				'showNewsletterSection'   => ! empty( $dl_in['showNewsletterSection'] ),
				'showMobileStickyCta'     => ! empty( $dl_in['showMobileStickyCta'] ),
			];
		}

		// ---------------------------------------------------------------------
		// TAB 14: SEO & PUBLISHING
		// ---------------------------------------------------------------------
		if ( 'seo-publishing' === $tab ) {
			$seo_cfg = $snapshot['site']['editorial']['structures']['cms/seoConfig'] ?? [
				'canonicalBaseUrl' => 'https://outboundholidays.co.zw',
				'defaultOgImage'   => '',
				'routeMeta'        => [],
			];
			if ( ! empty( $_POST['seo_config'] ) && is_array( $_POST['seo_config'] ) ) {
				$sc = wp_unslash( $_POST['seo_config'] );
				$seo_cfg['canonicalBaseUrl'] = esc_url_raw( $sc['canonicalBaseUrl'] ?? 'https://outboundholidays.co.zw' );
				$seo_cfg['defaultOgImage']   = esc_url_raw( $sc['defaultOgImage'] ?? '' );
			}

			if ( ! empty( $_POST['route_seo'] ) && is_array( $_POST['route_seo'] ) ) {
				foreach ( wp_unslash( $_POST['route_seo'] ) as $item ) {
					$path = sanitize_text_field( $item['path'] ?? '' );
					if ( '' === $path ) continue;
					$snapshot['site']['routeSeo'][ $path ] = [
						'title'       => sanitize_text_field( $item['title'] ?? '' ),
						'description' => sanitize_textarea_field( $item['description'] ?? '' ),
					];
					$seo_cfg['routeMeta'][ $path ] = [
						'canonicalUrl' => esc_url_raw( $item['canonicalUrl'] ?? '' ),
						'ogImage'      => esc_url_raw( $item['ogImage'] ?? '' ),
						'noindex'      => ! empty( $item['noindex'] ),
					];
				}
			}

			$snapshot['site']['editorial']['structures']['cms/seoConfig'] = $seo_cfg;
		}

		// Save Draft vs. Publish Live
		if ( 'draft' === $submit_mode ) {
			self::save_draft_snapshot( $snapshot );
			return 'Draft saved! You can continue editing or click "Publish Changes" when ready to push live.';
		}

		self::save_live_snapshot( $snapshot, $tab );
		return 'Changes published! Your live website content has been updated immediately.';
	}

	/**
	 * Render the Main Visual Content Studio Admin Page
	 */
	public static function render_studio(): void {
		// Prevent duplicate rendering on the same page load under all circumstances
		if ( self::$rendered ) {
			return;
		}
		self::$rendered = true;

		// Support direct submenu navigation (`admin.php?page=outbound-cms-experiences`) when `tab` query param is omitted
		$raw_tab = '';
		if ( ! empty( $_GET['tab'] ) ) {
			$raw_tab = sanitize_key( $_GET['tab'] );
		} elseif ( ! empty( $_GET['page'] ) && 0 === strpos( sanitize_key( $_GET['page'] ), 'outbound-cms-' ) ) {
			$raw_tab = substr( sanitize_key( $_GET['page'] ), strlen( 'outbound-cms-' ) );
		}

		$notice     = self::process_save();
		$snapshot   = self::get_working_snapshot();
		$tabs       = self::get_tabs();
		$active_tab = self::normalize_tab( $raw_tab ?: 'overview' );
		$has_draft  = self::has_draft();
		?>
		<div class="wrap outbound-cms-wrap outbound-cms-studio-wrap">
			<!-- Studio Top Bar -->
			<div class="outbound-cms-topbar">
				<div class="outbound-cms-brand">
					<span class="dashicons dashicons-palmtree outbound-cms-logo-icon"></span>
					<div>
						<h1>Outbound CMS — Content Studio</h1>
						<p>Manage all 14 website sections, multi-photo galleries, pricing, layout &amp; SEO — synchronized with your React frontend &amp; Outbound CRM.</p>
					</div>
				</div>
				<div class="outbound-cms-topbar-actions">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" class="button button-secondary">
						<span class="dashicons dashicons-external"></span> View Live Website
					</a>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=outbound-crm' ) ); ?>" class="button button-secondary">
						<span class="dashicons dashicons-businessman"></span> Open Outbound CRM
					</a>
					<form method="post" style="display:inline;" onsubmit="return confirm('Reset all website content back to the original factory seed?');">
						<?php wp_nonce_field( 'outbound_cms_save', 'outbound_cms_nonce' ); ?>
						<input type="hidden" name="cms_action" value="reset_defaults">
						<button type="submit" class="button button-link-delete">Reset to Factory Defaults</button>
					</form>
				</div>
			</div>

			<?php if ( $notice ) : ?>
				<div class="outbound-cms-toast">
					<span class="dashicons dashicons-yes-alt"></span>
					<span><?php echo esc_html( $notice ); ?></span>
				</div>
			<?php endif; ?>

			<?php if ( $has_draft ) : ?>
				<div class="outbound-cms-draft-banner" style="background:#fffbeb;border:1px solid #f59e0b;border-radius:12px;padding:12px 18px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;">
					<div style="display:flex;align-items:center;gap:10px;color:#92400e;font-weight:600;">
						<span class="dashicons dashicons-warning" style="color:#d97706;"></span>
						<span>You are viewing an unpublished Draft. Click "Publish Draft Now" to push all draft changes to the live website.</span>
					</div>
					<div style="display:flex;gap:8px;">
						<form method="post" style="display:inline;">
							<?php wp_nonce_field( 'outbound_cms_save', 'outbound_cms_nonce' ); ?>
							<input type="hidden" name="cms_action" value="publish_draft">
							<button type="submit" class="button button-primary">Publish Draft Now</button>
						</form>
						<form method="post" style="display:inline;">
							<?php wp_nonce_field( 'outbound_cms_save', 'outbound_cms_nonce' ); ?>
							<input type="hidden" name="cms_action" value="discard_draft">
							<button type="submit" class="button">Discard Draft</button>
						</form>
					</div>
				</div>
			<?php endif; ?>

			<!-- 14-Section Navigation Tabs -->
			<nav class="outbound-cms-tabs" style="display:flex;flex-wrap:wrap;gap:6px;">
				<?php foreach ( $tabs as $slug => $t ) : ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=outbound-cms&tab=' . $slug ) ); ?>"
					   class="outbound-cms-tab <?php echo $active_tab === $slug ? 'is-active' : ''; ?>">
						<span class="dashicons <?php echo esc_attr( $t['icon'] ); ?>"></span>
						<span><?php echo esc_html( $t['label'] ); ?></span>
					</a>
				<?php endforeach; ?>
			</nav>

			<!-- Main Studio Form -->
			<form method="post" class="outbound-cms-form" id="outbound-cms-main-form">
				<?php wp_nonce_field( 'outbound_cms_save', 'outbound_cms_nonce' ); ?>
				<input type="hidden" name="cms_tab" value="<?php echo esc_attr( $active_tab ); ?>">
				<input type="hidden" name="cms_submit_mode" id="cms-submit-mode" value="publish">

				<?php
				switch ( $active_tab ) {
					case 'overview':
						Outbound_CMS_Studio_Catalog::render_tab_overview( $snapshot, $tabs );
						break;
					case 'homepage':
						Outbound_CMS_Studio_Catalog::render_tab_homepage( $snapshot );
						break;
					case 'experiences':
						Outbound_CMS_Studio_Catalog::render_tab_experiences( $snapshot );
						break;
					case 'accommodation':
						Outbound_CMS_Studio_Catalog::render_tab_accommodation( $snapshot );
						break;
					case 'packages':
						Outbound_CMS_Studio_Catalog::render_tab_packages( $snapshot );
						break;
					case 'guides':
						Outbound_CMS_Studio_Catalog::render_tab_guides( $snapshot );
						break;
					case 'galleries':
						Outbound_CMS_Studio_Catalog::render_tab_galleries( $snapshot );
						break;
					case 'reviews':
						Outbound_CMS_Studio_Sections::render_tab_reviews( $snapshot );
						break;
					case 'about-contact':
						Outbound_CMS_Studio_Sections::render_tab_about_contact( $snapshot );
						break;
					case 'header-nav':
						Outbound_CMS_Studio_Sections::render_tab_header_nav( $snapshot );
						break;
					case 'footer-global':
						Outbound_CMS_Studio_Sections::render_tab_footer_global( $snapshot );
						break;
					case 'holiday-builder':
						Outbound_CMS_Studio_Sections::render_tab_holiday_builder( $snapshot );
						break;
					case 'design-layout':
						Outbound_CMS_Studio_Sections::render_tab_design_layout( $snapshot );
						break;
					case 'seo-publishing':
						Outbound_CMS_Studio_Sections::render_tab_seo_publishing( $snapshot );
						break;
				}
				?>

				<?php if ( 'overview' !== $active_tab ) : ?>
					<div class="outbound-cms-sticky-bar">
						<div class="outbound-cms-sticky-info">
							<span class="dashicons dashicons-info-outline"></span>
							<span>Save as Draft to preview internally, or click <strong>Publish Changes</strong> to update the live React frontend immediately.</span>
						</div>
						<div style="display:flex;gap:10px;align-items:center;">
							<button type="submit" class="button button-secondary cms-save-draft-btn" onclick="document.getElementById('cms-submit-mode').value='draft';">
								<span class="dashicons dashicons-saved" style="vertical-align:middle;"></span> Save Draft
							</button>
							<button type="submit" class="button button-primary button-hero outbound-cms-save-btn" onclick="document.getElementById('cms-submit-mode').value='publish';">
								<span class="dashicons dashicons-cloud-saved"></span> Publish Changes to Website
							</button>
						</div>
					</div>
				<?php endif; ?>
			</form>
		</div>
		<?php
	}
}

Outbound_CMS_Studio::init();
