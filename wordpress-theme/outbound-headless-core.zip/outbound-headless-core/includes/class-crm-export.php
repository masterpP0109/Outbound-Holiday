<?php
/**
 * Outbound Holidays CRM Data Export & Backup Tools
 *
 * @package OutboundHolidaysCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Outbound_CRM_Export' ) ) :
class Outbound_CRM_Export {

    public static function init() {
        add_action( 'admin_post_outbound_crm_export', [ __CLASS__, 'handle_export' ] );
    }

    public static function handle_export() {
        check_admin_referer( 'outbound_crm_export_nonce' );

        if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'outbound_crm_admin' ) ) {
            wp_die( __( 'Unauthorized permission', 'outbound-headless' ) );
        }

        global $wpdb;
        $type = sanitize_text_field( $_POST['export_type'] ?? 'all' );
        $filename = 'outbound-crm-export-' . $type . '-' . current_time( 'Y-m-d' ) . '.json';

        $data = [
            'version'     => '1.1.0',
            'exported_at' => current_time( 'c' ),
            'type'        => $type,
        ];

        if ( in_array( $type, [ 'all', 'customers' ], true ) ) {
            $data['customers'] = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}outbound_crm_customers", ARRAY_A );
        }
        if ( in_array( $type, [ 'all', 'opportunities' ], true ) ) {
            $data['opportunities'] = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}outbound_crm_opportunities", ARRAY_A );
        }
        if ( in_array( $type, [ 'all', 'quotations' ], true ) ) {
            $data['quotations'] = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}outbound_crm_quotations", ARRAY_A );
        }
        if ( in_array( $type, [ 'all', 'bookings' ], true ) ) {
            $data['bookings'] = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}outbound_crm_bookings", ARRAY_A );
        }
        if ( in_array( $type, [ 'all', 'payments' ], true ) ) {
            $data['payments'] = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}outbound_crm_payments", ARRAY_A );
        }
        if ( in_array( $type, [ 'all', 'suppliers' ], true ) ) {
            $data['suppliers'] = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}outbound_crm_suppliers", ARRAY_A );
        }

        header( 'Content-Type: application/json; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=' . $filename );
        echo wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
        exit;
    }
}
endif;
