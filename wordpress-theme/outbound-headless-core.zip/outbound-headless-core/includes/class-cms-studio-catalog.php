<?php
/**
 * Outbound Holidays — Visual Content Studio Catalogue & Media Renderers (Tabs 1 to 7)
 *
 * Renders:
 *  1. Website Overview (overview)
 *  2. Homepage & Hero (homepage)
 *  3. Experiences (experiences)
 *  4. Accommodation (accommodation)
 *  5. Holiday Packages (packages)
 *  6. Guides & Articles (guides)
 *  7. Galleries & Media (galleries)
 *
 * @package OutboundHeadlessCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Outbound_CMS_Studio_Catalog' ) ) :
class Outbound_CMS_Studio_Catalog {

	/**
	 * =========================================================================
	 * SECTION 1: WEBSITE OVERVIEW
	 * =========================================================================
	 */
	public static function render_tab_overview( array $snapshot, array $tabs ): void {
		global $wpdb;
		$acc_count   = count( $snapshot['accommodations'] ?? [] );
		$exp_count   = count( $snapshot['experiences'] ?? [] );
		$pkg_count   = count( $snapshot['packages'] ?? [] );
		$gde_count   = count( $snapshot['guides'] ?? [] );
		$photo_count = count( $snapshot['albums'][0]['images'] ?? [] );
		$rev_count   = count( $snapshot['site']['legacy']['TRAVEL_REVIEWS'] ?? [] );

		$enquiries = [];
		if ( class_exists( 'Outbound_CRM_Enquiries' ) && class_exists( 'Outbound_CRM_Database' ) ) {
			$opps_table = Outbound_CRM_Database::get_table( 'opportunities' );
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $opps_table ) ) === $opps_table ) {
				$enquiries = Outbound_CRM_Enquiries::get_all( 10, 0 );
			}
		}

		$has_draft = Outbound_CMS_Studio::has_draft();
		$revisions = Outbound_CMS_Studio::get_revisions();
		?>
		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>1A. Website Content &amp; Publishing Overview</h2>
					<p>Authoritative summary of all published records, media collections, and active CRM enquiries powering the Outbound Holidays React frontend.</p>
				</div>
				<div style="display:flex;gap:10px;align-items:center;">
					<span class="cms-status-pill" style="background:<?php echo $has_draft ? '#fef3c7;color:#92400e;' : '#dcfce7;color:#166534;'; ?>padding:6px 12px;border-radius:999px;font-weight:700;font-size:12px;">
						<?php echo $has_draft ? '● Draft Pending Publication' : '● Live & Synchronized'; ?>
					</span>
					<code class="cms-key-pill">Snapshot: <?php echo esc_html( $snapshot['version'] ?? '' ); ?></code>
				</div>
			</div>

			<div class="cms-stats-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:14px;margin-bottom:24px;">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=outbound-cms&tab=accommodation' ) ); ?>" class="cms-stat-box" style="text-decoration:none;background:#f8fafc;border:1px solid #cbd5e1;border-radius:12px;padding:16px;text-align:center;">
					<span style="font-size:28px;font-weight:800;color:#0b5e8e;display:block;"><?php echo intval( $acc_count ); ?></span>
					<span style="font-size:12px;font-weight:700;color:#475569;">Accommodations</span>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=outbound-cms&tab=experiences' ) ); ?>" class="cms-stat-box" style="text-decoration:none;background:#f8fafc;border:1px solid #cbd5e1;border-radius:12px;padding:16px;text-align:center;">
					<span style="font-size:28px;font-weight:800;color:#0b5e8e;display:block;"><?php echo intval( $exp_count ); ?></span>
					<span style="font-size:12px;font-weight:700;color:#475569;">Experiences</span>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=outbound-cms&tab=packages' ) ); ?>" class="cms-stat-box" style="text-decoration:none;background:#f8fafc;border:1px solid #cbd5e1;border-radius:12px;padding:16px;text-align:center;">
					<span style="font-size:28px;font-weight:800;color:#0b5e8e;display:block;"><?php echo intval( $pkg_count ); ?></span>
					<span style="font-size:12px;font-weight:700;color:#475569;">Holiday Packages</span>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=outbound-cms&tab=guides' ) ); ?>" class="cms-stat-box" style="text-decoration:none;background:#f8fafc;border:1px solid #cbd5e1;border-radius:12px;padding:16px;text-align:center;">
					<span style="font-size:28px;font-weight:800;color:#0b5e8e;display:block;"><?php echo intval( $gde_count ); ?></span>
					<span style="font-size:12px;font-weight:700;color:#475569;">Travel Guides</span>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=outbound-cms&tab=galleries' ) ); ?>" class="cms-stat-box" style="text-decoration:none;background:#f8fafc;border:1px solid #cbd5e1;border-radius:12px;padding:16px;text-align:center;">
					<span style="font-size:28px;font-weight:800;color:#c9a66b;display:block;"><?php echo intval( $photo_count ); ?></span>
					<span style="font-size:12px;font-weight:700;color:#475569;">Client Gallery Photos</span>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=outbound-cms&tab=reviews' ) ); ?>" class="cms-stat-box" style="text-decoration:none;background:#f8fafc;border:1px solid #cbd5e1;border-radius:12px;padding:16px;text-align:center;">
					<span style="font-size:28px;font-weight:800;color:#c9a66b;display:block;"><?php echo intval( $rev_count ); ?></span>
					<span style="font-size:12px;font-weight:700;color:#475569;">Verified Reviews</span>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=outbound-crm-leads' ) ); ?>" class="cms-stat-box" style="text-decoration:none;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:16px;text-align:center;">
					<span style="font-size:28px;font-weight:800;color:#16a34a;display:block;"><?php echo intval( count( $enquiries ) ); ?>+</span>
					<span style="font-size:12px;font-weight:700;color:#15803d;">CRM Enquiries</span>
				</a>
			</div>

			<h3 style="margin:0 0 12px;">Content Studio Directory — All 14 Sections</h3>
			<div class="cms-grid-3">
				<?php foreach ( $tabs as $t_slug => $t_info ) :
					if ( 'overview' === $t_slug ) continue;
					?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=outbound-cms&tab=' . $t_slug ) ); ?>" style="display:flex;align-items:center;gap:12px;padding:14px 16px;background:#fff;border:1px solid #e2e8f0;border-radius:10px;text-decoration:none;color:#1e293b;transition:all .15s;">
						<span class="dashicons <?php echo esc_attr( $t_info['icon'] ); ?>" style="color:#0b5e8e;font-size:22px;width:22px;height:22px;"></span>
						<div>
							<strong style="display:block;font-size:13px;color:#0b5e8e;"><?php echo esc_html( $t_info['label'] ); ?></strong>
							<span style="font-size:11px;color:#64748b;">Manage section content &amp; media →</span>
						</div>
					</a>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>1B. Recent Website Enquiries &amp; CRM Lead Sync</h2>
					<p>Website enquiries submitted via Contact Us or the Holiday Builder modal automatically create Customers, Opportunities, and Follow-up Tasks in Outbound CRM.</p>
				</div>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=outbound-crm' ) ); ?>" class="button button-primary">
					Open Full Outbound CRM Suite →
				</a>
			</div>
			<?php if ( empty( $enquiries ) ) : ?>
				<p style="color:#64748b;">No enquiries recorded yet, or visit <a href="<?php echo esc_url( admin_url( 'admin.php?page=outbound-crm-leads' ) ); ?>">Outbound CRM → Enquiries &amp; Leads</a>.</p>
			<?php else : ?>
				<table class="wp-list-table widefat fixed striped">
					<thead>
						<tr>
							<th style="width:140px;">Reference</th>
							<th>Traveller</th>
							<th>Email / Phone</th>
							<th>Trip / Enquiry Summary</th>
							<th style="width:110px;">Stage</th>
							<th style="width:150px;">Created</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( array_slice( $enquiries, 0, 8 ) as $enq ) : ?>
							<tr>
								<td><strong><code><?php echo esc_html( $enq['reference'] ?? '' ); ?></code></strong></td>
								<td><?php echo esc_html( trim( ( $enq['first_name'] ?? '' ) . ' ' . ( $enq['last_name'] ?? '' ) ) ); ?></td>
								<td><?php echo esc_html( ( $enq['email'] ?? '' ) . ' / ' . ( $enq['phone'] ?? '' ) ); ?></td>
								<td><?php echo esc_html( $enq['title'] ?? '' ); ?></td>
								<td><span class="cms-badge"><?php echo esc_html( strtoupper( $enq['stage'] ?? 'NEW' ) ); ?></span></td>
								<td><?php echo esc_html( $enq['created_at'] ?? '' ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * =========================================================================
	 * SECTION 2: HOMEPAGE & HERO
	 * =========================================================================
	 */
	public static function render_tab_homepage( array $snapshot ): void {
		$strings       = $snapshot['site']['editorial']['strings'] ?? [];
		$structures    = $snapshot['site']['editorial']['structures'] ?? [];
		$slides        = $structures['travel/TravelHero.slides'] ?? [];
		$why_cards     = $structures['travel/WhyChooseOutbound.section1'] ?? [];
		$guide_cards   = $structures['travel/VicFallsGuide.section1'] ?? [];
		$help_cards    = $structures['travel/HowWeHelp.section1'] ?? [];
		$featured      = $snapshot['site']['featured'] ?? [ 'accommodationIds' => [], 'experienceIds' => [], 'packageIds' => [] ];
		?>
		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>2A. Hero Banner Carousel Slides (<?php echo count( $slides ); ?>)</h2>
					<p>Manage the full-bleed rotating hero slides on the Homepage (<code>TravelHero.tsx</code>). Add, remove, or reorder slides and choose images from the WordPress Media Library.</p>
				</div>
				<button type="button" class="button button-secondary" id="cms-add-hero-slide-btn">
					<span class="dashicons dashicons-plus-alt2"></span> Add Hero Slide
				</button>
			</div>

			<div id="cms-hero-slides-list" class="cms-slides-grid">
				<?php foreach ( $slides as $idx => $slide ) :
					$line1 = '';
					$line2 = '';
					if ( isset( $slide['headline']['$element']['children'] ) && is_array( $slide['headline']['$element']['children'] ) ) {
						$children = $slide['headline']['$element']['children'];
						$line1    = is_string( $children[0] ?? null ) ? trim( $children[0] ) : '';
						if ( isset( $children[2] ) && is_string( $children[2] ) && '' !== trim( $children[2] ) ) {
							$line2 = trim( $children[2] );
						} else {
							foreach ( $children as $ch ) {
								if ( is_array( $ch ) && isset( $ch['$element']['children'][0] ) && is_string( $ch['$element']['children'][0] ) ) {
									$line2 = trim( $ch['$element']['children'][0] );
								}
							}
						}
					} elseif ( is_string( $slide['headline'] ?? null ) ) {
						$line1 = $slide['headline'];
					}
					$icon_name = $slide['badgeIcon']['$element']['name'] ?? 'Compass';
					?>
					<div class="cms-slide-editor cms-hero-slide-card">
						<div class="cms-slide-badge cms-flex-between">
							<span>Slide #<?php echo intval( $idx + 1 ); ?> — <?php echo esc_html( $slide['titleTag'] ?? '' ); ?></span>
							<div class="cms-inline-actions">
								<button type="button" class="button button-small cms-move-up" title="Move Up">↑</button>
								<button type="button" class="button button-small cms-move-down" title="Move Down">↓</button>
								<button type="button" class="button-link-delete cms-remove-card">Remove</button>
							</div>
						</div>
						<input type="hidden" name="slides[<?php echo intval( $idx ); ?>][id]" value="<?php echo esc_attr( $slide['id'] ?? 'slide-' . ( $idx + 1 ) ); ?>">

						<div class="cms-field">
							<label>Slide Background Photo (Desktop ~1920×900)</label>
							<div class="cms-media-picker">
								<div class="cms-media-preview">
									<?php if ( ! empty( $slide['imageUrl'] ) ) : ?>
										<img src="<?php echo esc_url( $slide['imageUrl'] ); ?>" alt="">
									<?php else : ?>
										<span class="cms-no-img">No image selected</span>
									<?php endif; ?>
								</div>
								<div class="cms-media-controls">
									<input type="text" name="slides[<?php echo intval( $idx ); ?>][imageUrl]" value="<?php echo esc_attr( $slide['imageUrl'] ?? '' ); ?>" class="cms-media-url" placeholder="https://...">
									<button type="button" class="button cms-pick-media"><span class="dashicons dashicons-format-image"></span> Select / Upload Image</button>
								</div>
							</div>
						</div>

						<div class="cms-field">
							<label>Mobile Crop / Portrait Photo (Optional — for mobile screens &lt; 768px)</label>
							<div class="cms-media-picker">
								<div class="cms-media-preview">
									<?php if ( ! empty( $slide['mobileImageUrl'] ) ) : ?>
										<img src="<?php echo esc_url( $slide['mobileImageUrl'] ); ?>" alt="">
									<?php else : ?>
										<span class="cms-no-img">No mobile image (defaults to responsive desktop crop)</span>
									<?php endif; ?>
								</div>
								<div class="cms-media-controls">
									<input type="text" name="slides[<?php echo intval( $idx ); ?>][mobileImageUrl]" value="<?php echo esc_attr( $slide['mobileImageUrl'] ?? '' ); ?>" class="cms-media-url" placeholder="https://...">
									<button type="button" class="button cms-pick-media"><span class="dashicons dashicons-format-image"></span> Select / Upload Mobile Image</button>
								</div>
							</div>
						</div>

						<div class="cms-grid-3">
							<div class="cms-field">
								<label>Category Pill Badge Text</label>
								<input type="text" name="slides[<?php echo intval( $idx ); ?>][titleTag]" value="<?php echo esc_attr( $slide['titleTag'] ?? '' ); ?>">
							</div>
							<div class="cms-field">
								<label>Badge Icon</label>
								<select name="slides[<?php echo intval( $idx ); ?>][iconName]">
									<?php foreach ( [ 'Users', 'Heart', 'Compass' ] as $ic ) : ?>
										<option value="<?php echo esc_attr( $ic ); ?>" <?php selected( $icon_name, $ic ); ?>><?php echo esc_html( $ic ); ?></option>
									<?php endforeach; ?>
								</select>
							</div>
							<div class="cms-field">
								<label>Primary CTA Button Text</label>
								<input type="text" name="slides[<?php echo intval( $idx ); ?>][primaryCtaText]" value="<?php echo esc_attr( $slide['primaryCtaText'] ?? 'Plan My Holiday' ); ?>">
							</div>
						</div>

						<div class="cms-grid-2">
							<div class="cms-field">
								<label>Main Headline (Line 1 — White)</label>
								<input type="text" name="slides[<?php echo intval( $idx ); ?>][headline_1]" value="<?php echo esc_attr( $line1 ); ?>">
							</div>
							<div class="cms-field">
								<label>Highlighted Headline (Line 2 — Gold)</label>
								<input type="text" name="slides[<?php echo intval( $idx ); ?>][headline_2]" value="<?php echo esc_attr( $line2 ); ?>">
							</div>
						</div>

						<div class="cms-field">
							<label>Subtitle / Description</label>
							<textarea name="slides[<?php echo intval( $idx ); ?>][description]" rows="2"><?php echo esc_textarea( $slide['description'] ?? '' ); ?></textarea>
						</div>

						<div class="cms-field">
							<label>Image Alt Text (SEO &amp; Accessibility)</label>
							<input type="text" name="slides[<?php echo intval( $idx ); ?>][altText]" value="<?php echo esc_attr( $slide['altText'] ?? '' ); ?>">
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>2B. Hero Secondary CTA, Reassurance Bullets &amp; Floating Local Support Card</h2>
					<p>Edit the reassurance line and floating "Local Team On the Ground" badge inside <code>TravelHero.tsx</code>.</p>
				</div>
			</div>
			<div class="cms-grid-3">
				<?php
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/TravelHero.text10', 'Secondary Hero Button Label (Explore Packages)' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/TravelHero.text11', 'Reassurance Bullet 1 (Based in Victoria Falls)' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/TravelHero.text12', 'Reassurance Bullet 2 (Personal Support)' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/TravelHero.text13', 'Reassurance Bullet 3 (Trusted Local Partners)' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/TravelHero.text14', 'Floating Support Card Title' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/TravelHero.text15', 'Floating Support Card Subtitle' );
				?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>2C. Quick Planning Bar &amp; Why Plan With Outbound Section</h2>
					<p>Controls <code>QuickPlanningBar.tsx</code> and the 4 value proposition cards in <code>WhyChooseOutbound.tsx</code>.</p>
				</div>
			</div>
			<div class="cms-grid-3">
				<?php
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/QuickPlanningBar.text1', 'Quick Planning Eyebrow' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/QuickPlanningBar.text2', 'Quick Planning Heading' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/QuickPlanningBar.text3', 'Quick Planning Guide Link Text' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/WhyChooseOutbound.text13', 'Why Plan With Us Eyebrow' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/WhyChooseOutbound.text14', 'Why Plan With Us Main Heading' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/WhyChooseOutbound.text15', 'Why Plan With Us Intro', true, 2 );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/WhyChooseOutbound.text16', 'Budget Callout Heading' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/WhyChooseOutbound.text17', 'Budget Callout Description', true, 2 );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/WhyChooseOutbound.text18', 'Why Plan With Us CTA Button' );
				?>
			</div>

			<h3 style="margin:20px 0 10px;">Why Plan With Outbound — 4 Pillar Cards (<code>WhyChooseOutbound.section1</code>)</h3>
			<div class="cms-grid-2">
				<?php foreach ( $why_cards as $idx => $wc ) : ?>
					<div class="cms-subcard" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px;">
						<div class="cms-grid-2">
							<div class="cms-field">
								<label>Card #<?php echo intval( $idx + 1 ); ?> Title</label>
								<input type="text" name="why_cards[<?php echo intval( $idx ); ?>][title]" value="<?php echo esc_attr( $wc['title'] ?? '' ); ?>">
							</div>
							<div class="cms-field">
								<label>Highlight Tag / Label</label>
								<input type="text" name="why_cards[<?php echo intval( $idx ); ?>][label]" value="<?php echo esc_attr( $wc['label'] ?? '' ); ?>">
							</div>
							<div class="cms-field cms-col-span-2">
								<label>Card Description</label>
								<textarea name="why_cards[<?php echo intval( $idx ); ?>][description]" rows="2"><?php echo esc_textarea( $wc['description'] ?? '' ); ?></textarea>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>2D. Homepage Featured Sections, Guide Preview, How We Help &amp; Final CTA Banner</h2>
					<p>Manage all remaining section headings, cards, and call-to-action banners on the Homepage.</p>
				</div>
			</div>
			<div class="cms-grid-3">
				<?php
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FeaturedExperiences.text1', 'Featured Experiences Eyebrow' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FeaturedExperiences.text2', 'Featured Experiences Heading' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FeaturedExperiences.text3', 'Featured Experiences Description', true, 2 );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FeaturedExperiences.text4', 'Explore All Experiences Button' );

				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/WhereToStaySection.text1', 'Where to Stay Eyebrow' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/WhereToStaySection.text2', 'Where to Stay Heading' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/WhereToStaySection.text3', 'Where to Stay Description', true, 2 );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/WhereToStaySection.text4', 'Explore All Stays Button' );

				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/VicFallsGuide.text9', 'Guide Preview Eyebrow' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/VicFallsGuide.text10', 'Guide Preview Heading' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/VicFallsGuide.text11', 'Guide Preview Description', true, 2 );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/VicFallsGuide.text13', 'Open Full Guide Button' );

				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FeaturedPackages.text1', 'Featured Packages Eyebrow' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FeaturedPackages.text2', 'Featured Packages Heading' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FeaturedPackages.text3', 'Featured Packages Description', true, 2 );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FeaturedPackages.text4', 'Explore All Packages Button' );

				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/HowWeHelp.text13', 'How We Help Eyebrow' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/HowWeHelp.text14', 'How We Help Heading' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/HowWeHelp.text15', 'How We Help Description', true, 2 );

				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FinalCtaBanner.text1', 'Final CTA Eyebrow Badge' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FinalCtaBanner.text2', 'Final CTA Heading Line 1' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FinalCtaBanner.text3', 'Final CTA Heading Highlight' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FinalCtaBanner.text4', 'Final CTA Description', true, 2 );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FinalCtaBanner.text5', 'Final CTA Primary Button' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/FinalCtaBanner.text6', 'Final CTA Secondary WhatsApp Button' );
				?>
			</div>
			<div style="margin-top:14px;">
				<?php Outbound_CMS_Studio_Sections::render_structure_image( $structures, 'travel/FinalCtaBanner.fallsTour1', 'Final CTA Banner Background Image' ); ?>
			</div>

			<h3 style="margin:20px 0 10px;">Victoria Falls Guide Preview Cards (<code>VicFallsGuide.section1</code>)</h3>
			<div class="cms-grid-2">
				<?php foreach ( $guide_cards as $idx => $gc ) : ?>
					<div class="cms-subcard" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px;">
						<div class="cms-field">
							<label>Card #<?php echo intval( $idx + 1 ); ?> Title</label>
							<input type="text" name="guide_preview_cards[<?php echo intval( $idx ); ?>][title]" value="<?php echo esc_attr( $gc['title'] ?? '' ); ?>">
						</div>
						<div class="cms-field" style="margin-top:6px;">
							<label>Description</label>
							<textarea name="guide_preview_cards[<?php echo intval( $idx ); ?>][description]" rows="2"><?php echo esc_textarea( $gc['description'] ?? '' ); ?></textarea>
						</div>
					</div>
				<?php endforeach; ?>
			</div>

			<h3 style="margin:20px 0 10px;">How We Help — 6 Service Cards (<code>HowWeHelp.section1</code>)</h3>
			<div class="cms-grid-3">
				<?php foreach ( $help_cards as $idx => $hc ) : ?>
					<div class="cms-subcard" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px;">
						<div class="cms-field">
							<label>Service #<?php echo intval( $idx + 1 ); ?> Title</label>
							<input type="text" name="how_we_help_cards[<?php echo intval( $idx ); ?>][title]" value="<?php echo esc_attr( $hc['title'] ?? '' ); ?>">
						</div>
						<div class="cms-field" style="margin-top:6px;">
							<label>Description</label>
							<textarea name="how_we_help_cards[<?php echo intval( $idx ); ?>][description]" rows="2"><?php echo esc_textarea( $hc['description'] ?? '' ); ?></textarea>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * =========================================================================
	 * SECTION 3: EXPERIENCES
	 * =========================================================================
	 */
	public static function render_tab_experiences( array $snapshot ): void {
		$experiences = $snapshot['experiences'] ?? [];
		$featured_ids = $snapshot['site']['featured']['experienceIds'] ?? [];
		$strings     = $snapshot['site']['editorial']['strings'] ?? [];
		$structures  = $snapshot['site']['editorial']['structures'] ?? [];
		$cat_details = $structures['travel/ExperienceCategoryPage.CATEGORY_DETAILS'] ?? [];
		?>
		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>3A. Experiences &amp; Activities Catalogue (<?php echo count( $experiences ); ?>)</h2>
					<p>Manage all Victoria Falls experiences, prices, galleries, step-by-step timelines, inclusions, exclusions, FAQs, and homepage featured status.</p>
				</div>
				<div style="display:flex;gap:10px;align-items:center;">
					<input type="search" class="cms-record-search" data-target="#cms-experiences-list > .cms-accordion-item" placeholder="Search experiences..." style="padding:7px 12px;border-radius:8px;border:1px solid #cbd5e1;">
					<button type="button" class="button button-secondary" id="cms-add-exp-btn">
						<span class="dashicons dashicons-plus-alt2"></span> Add New Experience
					</button>
				</div>
			</div>

			<div id="cms-experiences-list" class="cms-accordion-list">
				<?php foreach ( $experiences as $idx => $exp ) :
					$exp_id = $exp['id'] ?? '';
					$exp_slug = $exp['slug'] ?? '';
					$is_featured = in_array( $exp_id, $featured_ids, true ) || in_array( $exp_slug, $featured_ids, true );
					$gallery = $exp['galleryImages'] ?? [];
					$steps   = $exp['steps'] ?? [];
					$faqs    = $exp['faqs'] ?? [];
					?>
					<div class="cms-accordion-item <?php echo 0 === $idx ? 'is-open' : ''; ?>" data-search="<?php echo esc_attr( strtolower( ( $exp['title'] ?? '' ) . ' ' . $exp_slug . ' ' . implode( ' ', $exp['categories'] ?? [] ) ) ); ?>">
						<div class="cms-accordion-header">
							<div class="cms-acc-title-wrap">
								<?php if ( ! empty( $exp['featuredImage'] ) ) : ?>
									<img src="<?php echo esc_url( $exp['featuredImage'] ); ?>" class="cms-acc-thumb" alt="">
								<?php endif; ?>
								<div class="cms-acc-meta">
									<strong><?php echo esc_html( $exp['title'] ?? 'Untitled Experience' ); ?></strong>
									<span><?php echo esc_html( ( $exp['duration'] ?? '' ) . ' • From $' . ( $exp['priceAmount'] ?? 0 ) . ' • ' . count( $gallery ) . ' photos' ); ?></span>
								</div>
							</div>
							<div class="cms-acc-actions">
								<?php if ( $is_featured ) : ?>
									<span class="cms-badge" style="background:#fef3c7;color:#92400e;">★ Featured on Home</span>
								<?php endif; ?>
								<button type="button" class="button button-small cms-move-up" title="Move Up">↑</button>
								<button type="button" class="button button-small cms-move-down" title="Move Down">↓</button>
								<button type="button" class="button-link-delete cms-remove-card">Remove</button>
								<span class="dashicons dashicons-arrow-down-alt2 cms-acc-chevron"></span>
							</div>
						</div>

						<div class="cms-accordion-body">
							<input type="hidden" name="experiences[<?php echo intval( $idx ); ?>][id]" value="<?php echo esc_attr( $exp_id ?: 'exp-' . ( $idx + 1 ) ); ?>">

							<div class="cms-grid-4">
								<div class="cms-field">
									<label>Experience Title</label>
									<input type="text" name="experiences[<?php echo intval( $idx ); ?>][title]" value="<?php echo esc_attr( $exp['title'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>URL Slug</label>
									<input type="text" name="experiences[<?php echo intval( $idx ); ?>][slug]" value="<?php echo esc_attr( $exp_slug ); ?>">
								</div>
								<div class="cms-field">
									<label>Duration</label>
									<input type="text" name="experiences[<?php echo intval( $idx ); ?>][duration]" value="<?php echo esc_attr( $exp['duration'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Starting Price (USD)</label>
									<input type="number" name="experiences[<?php echo intval( $idx ); ?>][priceAmount]" value="<?php echo esc_attr( $exp['priceAmount'] ?? 0 ); ?>">
								</div>
								<div class="cms-field">
									<label>Display Price Label (e.g. From $45 pp)</label>
									<input type="text" name="experiences[<?php echo intval( $idx ); ?>][fromPrice]" value="<?php echo esc_attr( $exp['fromPrice'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Card Badge (Optional)</label>
									<input type="text" name="experiences[<?php echo intval( $idx ); ?>][badge]" value="<?php echo esc_attr( $exp['badge'] ?? '' ); ?>" placeholder="e.g. Must-Do, Best Seller">
								</div>
								<div class="cms-field">
									<label>Location</label>
									<input type="text" name="experiences[<?php echo intval( $idx ); ?>][location]" value="<?php echo esc_attr( $exp['location'] ?? 'Victoria Falls, Zimbabwe' ); ?>">
								</div>
								<div class="cms-field cms-checkbox-field">
									<label>
										<input type="checkbox" name="experiences[<?php echo intval( $idx ); ?>][is_featured]" value="1" <?php checked( $is_featured ); ?>>
										Featured on Homepage
									</label>
								</div>
							</div>

							<div class="cms-grid-2">
								<div class="cms-field">
									<label>Subtitle / Tagline</label>
									<input type="text" name="experiences[<?php echo intval( $idx ); ?>][subtitle]" value="<?php echo esc_attr( $exp['subtitle'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Categories (Comma-separated: first-visit, wildlife, adventure, river, culture, day-trips, wellness)</label>
									<input type="text" name="experiences[<?php echo intval( $idx ); ?>][categories_csv]" value="<?php echo esc_attr( implode( ', ', $exp['categories'] ?? [] ) ); ?>">
								</div>
							</div>

							<div class="cms-grid-2">
								<div class="cms-field">
									<label>Short Card Description</label>
									<textarea name="experiences[<?php echo intval( $idx ); ?>][shortDescription]" rows="2"><?php echo esc_textarea( $exp['shortDescription'] ?? '' ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Why We Recommend It (Editorial Callout)</label>
									<textarea name="experiences[<?php echo intval( $idx ); ?>][whyWeRecommend]" rows="2"><?php echo esc_textarea( $exp['whyWeRecommend'] ?? '' ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Full Editorial Overview</label>
									<textarea name="experiences[<?php echo intval( $idx ); ?>][fullOverview]" rows="3"><?php echo esc_textarea( $exp['fullOverview'] ?? '' ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Local Expert Tip</label>
									<textarea name="experiences[<?php echo intval( $idx ); ?>][localExpertTip]" rows="3"><?php echo esc_textarea( $exp['localExpertTip'] ?? '' ); ?></textarea>
								</div>
							</div>

							<div class="cms-grid-4">
								<div class="cms-field">
									<label>Key Highlights (One per line)</label>
									<textarea name="experiences[<?php echo intval( $idx ); ?>][highlights_raw]" rows="4"><?php echo esc_textarea( implode( "\n", $exp['highlights'] ?? [] ) ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>What's Included (One per line)</label>
									<textarea name="experiences[<?php echo intval( $idx ); ?>][included_raw]" rows="4"><?php echo esc_textarea( implode( "\n", $exp['whatsIncluded'] ?? [] ) ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>What's Excluded (One per line)</label>
									<textarea name="experiences[<?php echo intval( $idx ); ?>][excluded_raw]" rows="4"><?php echo esc_textarea( implode( "\n", $exp['whatsExcluded'] ?? [] ) ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Good To Know (One per line)</label>
									<textarea name="experiences[<?php echo intval( $idx ); ?>][goodToKnow_raw]" rows="4"><?php echo esc_textarea( implode( "\n", $exp['goodToKnow'] ?? [] ) ); ?></textarea>
								</div>
							</div>

							<div class="cms-grid-2">
								<div class="cms-field">
									<label>Featured Hero Image</label>
									<div class="cms-media-picker">
										<div class="cms-media-preview">
											<?php if ( ! empty( $exp['featuredImage'] ) ) : ?>
												<img src="<?php echo esc_url( $exp['featuredImage'] ); ?>" alt="">
											<?php endif; ?>
										</div>
										<div class="cms-media-controls">
											<input type="text" name="experiences[<?php echo intval( $idx ); ?>][featuredImage]" value="<?php echo esc_attr( $exp['featuredImage'] ?? '' ); ?>" class="cms-media-url">
											<button type="button" class="button cms-pick-media"><span class="dashicons dashicons-format-image"></span> Select / Upload</button>
										</div>
									</div>
								</div>
								<div class="cms-field">
									<label>Related Experience IDs / Slugs (Comma-separated)</label>
									<input type="text" name="experiences[<?php echo intval( $idx ); ?>][relatedIds_csv]" value="<?php echo esc_attr( implode( ', ', $exp['relatedIds'] ?? [] ) ); ?>">
								</div>
							</div>

							<!-- Interactive Multi-Photo Gallery Manager -->
							<div class="cms-field" style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:10px;padding:14px;margin-top:10px;">
								<div class="cms-flex-between" style="margin-bottom:10px;">
									<label style="margin:0;font-weight:700;">Experience Photo Gallery (<?php echo count( $gallery ); ?> photos) — Add, Upload, Replace, Reorder &amp; Remove</label>
									<button type="button" class="button button-small cms-add-string-gallery-photo" data-input-name="experiences[<?php echo intval( $idx ); ?>][galleryImages][]">
										<span class="dashicons dashicons-plus-alt2"></span> Add / Upload Gallery Photos
									</button>
								</div>
								<div class="cms-string-gallery-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:10px;">
									<?php foreach ( $gallery as $g_url ) : ?>
										<div class="cms-string-gallery-item" style="background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:8px;">
											<img src="<?php echo esc_url( $g_url ); ?>" alt="" style="width:100%;height:105px;object-fit:cover;border-radius:6px;display:block;margin-bottom:6px;">
											<input type="text" name="experiences[<?php echo intval( $idx ); ?>][galleryImages][]" value="<?php echo esc_attr( $g_url ); ?>" class="cms-media-url" style="width:100%;font-size:11px;margin-bottom:6px;">
											<div style="display:flex;justify-content:space-between;gap:4px;">
												<button type="button" class="button button-small cms-pick-single-gallery-url">Replace</button>
												<button type="button" class="button button-small cms-move-up" title="Move Left">←</button>
												<button type="button" class="button button-small cms-move-down" title="Move Right">→</button>
												<button type="button" class="button-link-delete cms-remove-gallery-url">✕</button>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
							</div>

							<!-- Step-by-Step Journey & FAQs JSON / Structured Editors -->
							<div class="cms-grid-2" style="margin-top:12px;">
								<div class="cms-field">
									<label>Step-by-Step Journey (<code>steps</code> JSON array: <code>stepNumber, time, title, description, highlight, image</code>)</label>
									<textarea name="experiences[<?php echo intval( $idx ); ?>][steps_json]" rows="4" style="font-family:monospace;font-size:11px;"><?php echo esc_textarea( wp_json_encode( $steps, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Experience FAQs (<code>faqs</code> JSON array: <code>[{"q":"...","a":"..."}]</code>)</label>
									<textarea name="experiences[<?php echo intval( $idx ); ?>][faqs_json]" rows="4" style="font-family:monospace;font-size:11px;"><?php echo esc_textarea( wp_json_encode( $faqs, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></textarea>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>3B. Experiences Directory, Category Pages &amp; Flagship Boma / Bungee Pages</h2>
					<p>Manage the Experiences Directory hero (<code>/things-to-do-in-victoria-falls</code>), Category headers (<code>/things-to-do/category/*</code>), and flagship Boma &amp; Bungee pages.</p>
				</div>
			</div>
			<div class="cms-grid-3">
				<?php
				Outbound_CMS_Studio_Sections::render_structure_image( $structures, 'travel/ExperiencesDirectoryPage.fallsTour1', 'Experiences Directory Hero Photo' );
				Outbound_CMS_Studio_Sections::render_structure_image( $structures, 'travel/BomaExperiencePage.bomaDinnerImg', 'The Boma Page Hero Photo' );
				Outbound_CMS_Studio_Sections::render_structure_image( $structures, 'travel/BungeeExperiencePage.bungeeImg', 'Bungee Jump Page Hero Photo' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/ExperiencesDirectoryPage.text2', 'Directory Hero Main Heading' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/ExperiencesDirectoryPage.text3', 'Directory Hero Subtitle', true, 2 );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/BomaExperiencePage.text34', 'Boma Page Hero Headline' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/BomaExperiencePage.text35', 'Boma Page Hero Subtitle', true, 2 );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/BomaExperiencePage.text154', 'Boma Dinner Typical Price Label (e.g. $55 - $65)' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/BungeeExperiencePage.text32', 'Bungee Page Hero Headline' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/BungeeExperiencePage.text33', 'Bungee Page Hero Subtitle', true, 2 );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/BungeeExperiencePage.text92', 'Bungee Page Sidebar Price Display (e.g. $160)' );
				?>
			</div>

			<h3 style="margin:20px 0 10px;">7 Experience Category Pages (<code>ExperienceCategoryPage.CATEGORY_DETAILS</code>)</h3>
			<div class="cms-grid-2">
				<?php foreach ( $cat_details as $c_key => $c_data ) : ?>
					<div class="cms-subcard" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px;">
						<strong>Category: <code><?php echo esc_html( $c_key ); ?></code></strong>
						<div class="cms-grid-2" style="margin-top:8px;">
							<div class="cms-field">
								<label>Category Title</label>
								<input type="text" name="exp_cat_details[<?php echo esc_attr( $c_key ); ?>][title]" value="<?php echo esc_attr( $c_data['title'] ?? '' ); ?>">
							</div>
							<div class="cms-field">
								<label>Intro Heading</label>
								<input type="text" name="exp_cat_details[<?php echo esc_attr( $c_key ); ?>][introTitle]" value="<?php echo esc_attr( $c_data['introTitle'] ?? '' ); ?>">
							</div>
							<div class="cms-field cms-col-span-2">
								<label>Subtitle</label>
								<input type="text" name="exp_cat_details[<?php echo esc_attr( $c_key ); ?>][subtitle]" value="<?php echo esc_attr( $c_data['subtitle'] ?? '' ); ?>">
							</div>
							<div class="cms-field cms-col-span-2">
								<label>Hero Image URL</label>
								<div class="cms-media-picker">
									<div class="cms-media-controls">
										<input type="text" name="exp_cat_details[<?php echo esc_attr( $c_key ); ?>][heroImage]" value="<?php echo esc_attr( $c_data['heroImage'] ?? '' ); ?>" class="cms-media-url">
										<button type="button" class="button cms-pick-media">Select</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * =========================================================================
	 * SECTION 4: ACCOMMODATION
	 * =========================================================================
	 */
	public static function render_tab_accommodation( array $snapshot ): void {
		$accommodations = $snapshot['accommodations'] ?? [];
		$featured_ids   = $snapshot['site']['featured']['accommodationIds'] ?? [];
		$strings        = $snapshot['site']['editorial']['strings'] ?? [];
		$valid_cats     = [ 'Luxury Lodge', 'Boutique Hotel', 'Guest Lodge', 'Safari Lodge', 'Resort', 'Self-Catering' ];
		$valid_badges   = [ '', 'Luxury', 'Family Favourite', 'Romantic', 'Best Value', 'Walking Distance', 'Boutique' ];
		$valid_tags     = [ 'luxury-lodges', 'boutique-hotels', 'family-friendly', 'romantic-escapes', 'best-value', 'safari-lodges', 'self-catering', 'walking-distance' ];
		?>
		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>4A. Accommodations — Hotels, Lodges &amp; Stays (<?php echo count( $accommodations ); ?>)</h2>
					<p>Manage all recommended Victoria Falls properties, room types, multi-photo galleries, At-A-Glance specifications, facilities, and location details.</p>
				</div>
				<div style="display:flex;gap:10px;align-items:center;">
					<input type="search" class="cms-record-search" data-target="#cms-stays-list > .cms-accordion-item" placeholder="Search hotels & lodges..." style="padding:7px 12px;border-radius:8px;border:1px solid #cbd5e1;">
					<button type="button" class="button button-secondary" id="cms-add-stay-btn">
						<span class="dashicons dashicons-plus-alt2"></span> Add New Property
					</button>
				</div>
			</div>

			<div id="cms-stays-list" class="cms-accordion-list">
				<?php foreach ( $accommodations as $idx => $acc ) :
					$acc_id      = $acc['id'] ?? '';
					$acc_slug    = $acc['slug'] ?? '';
					$is_featured = in_array( $acc_slug, $featured_ids, true ) || in_array( $acc_id, $featured_ids, true );
					$gallery     = $acc['galleryImages'] ?? [];
					$glance      = $acc['atAGlance'] ?? [];
					$loc_info    = $acc['locationInfo'] ?? [];
					$rooms       = $acc['roomTypes'] ?? [];
					?>
					<div class="cms-accordion-item <?php echo 0 === $idx ? 'is-open' : ''; ?>" data-search="<?php echo esc_attr( strtolower( ( $acc['name'] ?? '' ) . ' ' . $acc_slug . ' ' . ( $acc['category'] ?? '' ) ) ); ?>">
						<div class="cms-accordion-header">
							<div class="cms-acc-title-wrap">
								<?php if ( ! empty( $acc['heroImage'] ) ) : ?>
									<img src="<?php echo esc_url( $acc['heroImage'] ); ?>" class="cms-acc-thumb" alt="">
								<?php endif; ?>
								<div class="cms-acc-meta">
									<strong><?php echo esc_html( $acc['name'] ?? 'Untitled Property' ); ?></strong>
									<span><?php echo esc_html( ( $acc['category'] ?? '' ) . ' • From $' . ( $acc['priceFromUSD'] ?? 0 ) . '/night • ' . count( $gallery ) . ' photos • ' . count( $rooms ) . ' room types' ); ?></span>
								</div>
							</div>
							<div class="cms-acc-actions">
								<?php if ( $is_featured ) : ?>
									<span class="cms-badge" style="background:#fef3c7;color:#92400e;">★ Featured on Home</span>
								<?php endif; ?>
								<button type="button" class="button button-small cms-move-up" title="Move Up">↑</button>
								<button type="button" class="button button-small cms-move-down" title="Move Down">↓</button>
								<button type="button" class="button-link-delete cms-remove-card">Remove</button>
								<span class="dashicons dashicons-arrow-down-alt2 cms-acc-chevron"></span>
							</div>
						</div>

						<div class="cms-accordion-body">
							<input type="hidden" name="accommodations[<?php echo intval( $idx ); ?>][id]" value="<?php echo esc_attr( $acc_id ?: 'stay-' . ( $idx + 1 ) ); ?>">

							<div class="cms-grid-4">
								<div class="cms-field">
									<label>Property Name</label>
									<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][name]" value="<?php echo esc_attr( $acc['name'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>URL Slug</label>
									<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][slug]" value="<?php echo esc_attr( $acc_slug ); ?>">
								</div>
								<div class="cms-field">
									<label>Property Category</label>
									<select name="accommodations[<?php echo intval( $idx ); ?>][category]">
										<?php foreach ( $valid_cats as $cat_opt ) : ?>
											<option value="<?php echo esc_attr( $cat_opt ); ?>" <?php selected( $acc['category'] ?? 'Boutique Hotel', $cat_opt ); ?>><?php echo esc_html( $cat_opt ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>
								<div class="cms-field">
									<label>Card Badge</label>
									<select name="accommodations[<?php echo intval( $idx ); ?>][badge]">
										<?php foreach ( $valid_badges as $b_opt ) : ?>
											<option value="<?php echo esc_attr( $b_opt ); ?>" <?php selected( $acc['badge'] ?? '', $b_opt ); ?>><?php echo esc_html( $b_opt ?: '— None —' ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>
								<div class="cms-field">
									<label>Starting Rate (USD / Night)</label>
									<input type="number" name="accommodations[<?php echo intval( $idx ); ?>][priceFromUSD]" value="<?php echo esc_attr( $acc['priceFromUSD'] ?? 0 ); ?>">
								</div>
								<div class="cms-field">
									<label>Star / Guest Rating</label>
									<input type="number" step="0.1" name="accommodations[<?php echo intval( $idx ); ?>][rating]" value="<?php echo esc_attr( $acc['rating'] ?? 4.8 ); ?>">
								</div>
								<div class="cms-field">
									<label>Review Count</label>
									<input type="number" name="accommodations[<?php echo intval( $idx ); ?>][reviewCount]" value="<?php echo esc_attr( $acc['reviewCount'] ?? 100 ); ?>">
								</div>
								<div class="cms-field cms-checkbox-field">
									<label>
										<input type="checkbox" name="accommodations[<?php echo intval( $idx ); ?>][is_featured]" value="1" <?php checked( $is_featured ); ?>>
										Featured on Homepage
									</label>
								</div>
							</div>

							<div class="cms-grid-3">
								<div class="cms-field">
									<label>Location Summary</label>
									<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][location]" value="<?php echo esc_attr( $acc['location'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Distance from Falls</label>
									<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][distanceFromFalls]" value="<?php echo esc_attr( $acc['distanceFromFalls'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Airport Distance</label>
									<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][airportDistance]" value="<?php echo esc_attr( $acc['airportDistance'] ?? '' ); ?>">
								</div>
							</div>

							<div class="cms-field">
								<label>Filter Tags (Allowed: <?php echo esc_html( implode( ', ', $valid_tags ) ); ?>)</label>
								<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][filterTags_csv]" value="<?php echo esc_attr( implode( ', ', $acc['filterTags'] ?? [] ) ); ?>">
							</div>

							<div class="cms-grid-2">
								<div class="cms-field">
									<label>Tagline</label>
									<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][tagline]" value="<?php echo esc_attr( $acc['tagline'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Short Card Description</label>
									<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][shortDescription]" value="<?php echo esc_attr( $acc['shortDescription'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Editorial Overview</label>
									<textarea name="accommodations[<?php echo intval( $idx ); ?>][editorialOverview]" rows="3"><?php echo esc_textarea( $acc['editorialOverview'] ?? '' ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Why We Recommend This Stay</label>
									<textarea name="accommodations[<?php echo intval( $idx ); ?>][whyWeRecommend]" rows="3"><?php echo esc_textarea( $acc['whyWeRecommend'] ?? '' ); ?></textarea>
								</div>
							</div>

							<div class="cms-field">
								<label>Hero Image</label>
								<div class="cms-media-picker">
									<div class="cms-media-preview">
										<?php if ( ! empty( $acc['heroImage'] ) ) : ?>
											<img src="<?php echo esc_url( $acc['heroImage'] ); ?>" alt="">
										<?php endif; ?>
									</div>
									<div class="cms-media-controls">
										<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][heroImage]" value="<?php echo esc_attr( $acc['heroImage'] ?? '' ); ?>" class="cms-media-url">
										<button type="button" class="button cms-pick-media"><span class="dashicons dashicons-format-image"></span> Select / Upload</button>
									</div>
								</div>
							</div>

							<!-- Interactive Multi-Photo Property Gallery Manager -->
							<div class="cms-field" style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:10px;padding:14px;margin-top:10px;">
								<div class="cms-flex-between" style="margin-bottom:10px;">
									<label style="margin:0;font-weight:700;">Property Photo Gallery (<?php echo count( $gallery ); ?> photos) — Add, Upload, Replace, Reorder &amp; Remove</label>
									<button type="button" class="button button-small cms-add-string-gallery-photo" data-input-name="accommodations[<?php echo intval( $idx ); ?>][galleryImages][]">
										<span class="dashicons dashicons-plus-alt2"></span> Add / Upload Gallery Photos
									</button>
								</div>
								<div class="cms-string-gallery-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:10px;">
									<?php foreach ( $gallery as $g_url ) : ?>
										<div class="cms-string-gallery-item" style="background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:8px;">
											<img src="<?php echo esc_url( $g_url ); ?>" alt="" style="width:100%;height:105px;object-fit:cover;border-radius:6px;display:block;margin-bottom:6px;">
											<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][galleryImages][]" value="<?php echo esc_attr( $g_url ); ?>" class="cms-media-url" style="width:100%;font-size:11px;margin-bottom:6px;">
											<div style="display:flex;justify-content:space-between;gap:4px;">
												<button type="button" class="button button-small cms-pick-single-gallery-url">Replace</button>
												<button type="button" class="button button-small cms-move-up" title="Move Left">←</button>
												<button type="button" class="button button-small cms-move-down" title="Move Right">→</button>
												<button type="button" class="button-link-delete cms-remove-gallery-url">✕</button>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
							</div>

							<!-- At A Glance Specs -->
							<h4 style="margin:18px 0 8px;">At-A-Glance Specifications</h4>
							<div class="cms-grid-5" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;">
								<?php
								$glance_fields = [
									'type'              => 'Property Type',
									'starRating'        => 'Star Rating',
									'bestFor'           => 'Best For',
									'distanceFromFalls' => 'Distance From Falls',
									'pool'              => 'Swimming Pool',
									'restaurant'        => 'Restaurant & Bar',
									'wifi'              => 'Wi-Fi',
									'familyFriendly'    => 'Family Policy',
									'transfers'         => 'Transfers',
									'roomTypesSummary'  => 'Room Summary',
								];
								foreach ( $glance_fields as $gk => $gl ) :
									?>
									<div class="cms-field">
										<label><?php echo esc_html( $gl ); ?></label>
										<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][atAGlance][<?php echo esc_attr( $gk ); ?>]" value="<?php echo esc_attr( $glance[ $gk ] ?? '' ); ?>">
									</div>
								<?php endforeach; ?>
							</div>

							<!-- Room Types -->
							<?php if ( ! empty( $rooms ) ) : ?>
								<h4 style="margin:18px 0 8px;">Room Categories &amp; Suites (<?php echo count( $rooms ); ?>)</h4>
								<div class="cms-rooms-grid">
									<?php foreach ( $rooms as $r_idx => $room ) : ?>
										<div class="cms-room-card">
											<div class="cms-field">
												<label>Room Name</label>
												<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][roomTypes][<?php echo intval( $r_idx ); ?>][name]" value="<?php echo esc_attr( $room['name'] ?? '' ); ?>">
											</div>
											<div class="cms-field">
												<label>Max Occupancy</label>
												<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][roomTypes][<?php echo intval( $r_idx ); ?>][occupancy]" value="<?php echo esc_attr( $room['occupancy'] ?? '' ); ?>">
											</div>
											<div class="cms-field">
												<label>Room Description</label>
												<textarea name="accommodations[<?php echo intval( $idx ); ?>][roomTypes][<?php echo intval( $r_idx ); ?>][description]" rows="2"><?php echo esc_textarea( $room['description'] ?? '' ); ?></textarea>
											</div>
											<div class="cms-field">
												<label>Room Features (Comma-separated)</label>
												<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][roomTypes][<?php echo intval( $r_idx ); ?>][features_csv]" value="<?php echo esc_attr( implode( ', ', $room['features'] ?? [] ) ); ?>">
											</div>
											<div class="cms-field">
												<label>Room Image</label>
												<div class="cms-media-picker">
													<div class="cms-media-preview">
														<?php if ( ! empty( $room['imageUrl'] ) ) : ?>
															<img src="<?php echo esc_url( $room['imageUrl'] ); ?>" alt="">
														<?php endif; ?>
													</div>
													<div class="cms-media-controls">
														<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][roomTypes][<?php echo intval( $r_idx ); ?>][imageUrl]" value="<?php echo esc_attr( $room['imageUrl'] ?? '' ); ?>" class="cms-media-url">
														<button type="button" class="button cms-pick-media">Select</button>
													</div>
												</div>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>

							<div class="cms-grid-3" style="margin-top:12px;">
								<div class="cms-field">
									<label>Full Street / Location Address</label>
									<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][locationInfo][address]" value="<?php echo esc_attr( $loc_info['address'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Nearby Experience IDs (Comma-separated)</label>
									<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][nearbyExperienceIds_csv]" value="<?php echo esc_attr( implode( ', ', $acc['nearbyExperienceIds'] ?? [] ) ); ?>">
								</div>
								<div class="cms-field">
									<label>Related Property Slugs (Comma-separated)</label>
									<input type="text" name="accommodations[<?php echo intval( $idx ); ?>][relatedPropertyIds_csv]" value="<?php echo esc_attr( implode( ', ', $acc['relatedPropertyIds'] ?? [] ) ); ?>">
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>4B. Accommodation Directory &amp; Interactive Advisor Copy</h2>
					<p>Edit headings and guidance on <code>/victoria-falls-accommodation</code> and <code>AccommodationAdvisor.tsx</code>.</p>
				</div>
			</div>
			<div class="cms-grid-3">
				<?php
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/AccommodationDirectoryPage.text2', 'Directory Hero Badge' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/AccommodationDirectoryPage.text3', 'Directory Hero Main Heading' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/AccommodationDirectoryPage.text4', 'Directory Hero Subtitle', true, 2 );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/AccommodationAdvisor.text1', 'Stay Advisor Badge' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/AccommodationAdvisor.text2', 'Stay Advisor Heading' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/AccommodationAdvisor.text3', 'Stay Advisor Subtitle', true, 2 );
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * =========================================================================
	 * SECTION 5: HOLIDAY PACKAGES
	 * =========================================================================
	 */
	public static function render_tab_packages( array $snapshot ): void {
		$packages     = $snapshot['packages'] ?? [];
		$featured_ids = $snapshot['site']['featured']['packageIds'] ?? [];
		$strings      = $snapshot['site']['editorial']['strings'] ?? [];
		$structures   = $snapshot['site']['editorial']['structures'] ?? [];
		$valid_badges = [ 'Best Value', 'Luxury', 'Family Favourites', 'Adventure', 'Signature', 'Popular' ];
		$valid_cats   = [ 'value', 'luxury', 'family', 'adventure', 'safari', 'first-visit', 'couples' ];
		?>
		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>5A. Curated Holiday Packages (<?php echo count( $packages ); ?>)</h2>
					<p>Manage multi-day itineraries, pricing, galleries, recommended hotels, route maps, inclusions, exclusions, and FAQs.</p>
				</div>
				<div style="display:flex;gap:10px;align-items:center;">
					<input type="search" class="cms-record-search" data-target="#cms-packages-list > .cms-accordion-item" placeholder="Search packages..." style="padding:7px 12px;border-radius:8px;border:1px solid #cbd5e1;">
					<button type="button" class="button button-secondary" id="cms-add-pkg-btn">
						<span class="dashicons dashicons-plus-alt2"></span> Add New Package
					</button>
				</div>
			</div>

			<div id="cms-packages-list" class="cms-accordion-list">
				<?php foreach ( $packages as $idx => $pkg ) :
					$pkg_id      = $pkg['id'] ?? '';
					$pkg_slug    = $pkg['slug'] ?? '';
					$is_featured = in_array( $pkg_id, $featured_ids, true ) || in_array( $pkg_slug, $featured_ids, true );
					$gallery     = $pkg['galleryImages'] ?? [];
					$h_meta      = $pkg['highlightsMeta'] ?? [];
					?>
					<div class="cms-accordion-item <?php echo 0 === $idx ? 'is-open' : ''; ?>" data-search="<?php echo esc_attr( strtolower( ( $pkg['title'] ?? '' ) . ' ' . $pkg_slug . ' ' . ( $pkg['category'] ?? '' ) ) ); ?>">
						<div class="cms-accordion-header">
							<div class="cms-acc-title-wrap">
								<?php if ( ! empty( $pkg['imageUrl'] ) ) : ?>
									<img src="<?php echo esc_url( $pkg['imageUrl'] ); ?>" class="cms-acc-thumb" alt="">
								<?php endif; ?>
								<div class="cms-acc-meta">
									<strong><?php echo esc_html( $pkg['title'] ?? 'Untitled Package' ); ?></strong>
									<span><?php echo esc_html( ( $pkg['duration'] ?? '' ) . ' • From $' . ( $pkg['priceUSD'] ?? 0 ) . ' pp • ' . count( $gallery ) . ' photos' ); ?></span>
								</div>
							</div>
							<div class="cms-acc-actions">
								<?php if ( $is_featured ) : ?>
									<span class="cms-badge" style="background:#fef3c7;color:#92400e;">★ Featured on Home</span>
								<?php endif; ?>
								<button type="button" class="button button-small cms-move-up" title="Move Up">↑</button>
								<button type="button" class="button button-small cms-move-down" title="Move Down">↓</button>
								<button type="button" class="button-link-delete cms-remove-card">Remove</button>
								<span class="dashicons dashicons-arrow-down-alt2 cms-acc-chevron"></span>
							</div>
						</div>

						<div class="cms-accordion-body">
							<input type="hidden" name="packages[<?php echo intval( $idx ); ?>][id]" value="<?php echo esc_attr( $pkg_id ?: 'pkg-' . ( $idx + 1 ) ); ?>">

							<div class="cms-grid-4">
								<div class="cms-field">
									<label>Package Title</label>
									<input type="text" name="packages[<?php echo intval( $idx ); ?>][title]" value="<?php echo esc_attr( $pkg['title'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>URL Slug</label>
									<input type="text" name="packages[<?php echo intval( $idx ); ?>][slug]" value="<?php echo esc_attr( $pkg_slug ); ?>">
								</div>
								<div class="cms-field">
									<label>Duration</label>
									<input type="text" name="packages[<?php echo intval( $idx ); ?>][duration]" value="<?php echo esc_attr( $pkg['duration'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Starting Price (USD pp)</label>
									<input type="number" name="packages[<?php echo intval( $idx ); ?>][priceUSD]" value="<?php echo esc_attr( $pkg['priceUSD'] ?? 0 ); ?>">
								</div>
								<div class="cms-field">
									<label>Badge</label>
									<select name="packages[<?php echo intval( $idx ); ?>][badge]">
										<?php foreach ( $valid_badges as $b_opt ) : ?>
											<option value="<?php echo esc_attr( $b_opt ); ?>" <?php selected( $pkg['badge'] ?? 'Most Popular', $b_opt ); ?>><?php echo esc_html( $b_opt ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>
								<div class="cms-field">
									<label>Primary Category</label>
									<select name="packages[<?php echo intval( $idx ); ?>][category]">
										<?php foreach ( $valid_cats as $c_opt ) : ?>
											<option value="<?php echo esc_attr( $c_opt ); ?>" <?php selected( $pkg['category'] ?? 'first-time', $c_opt ); ?>><?php echo esc_html( $c_opt ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>
								<div class="cms-field">
									<label>Traveller Type Label</label>
									<input type="text" name="packages[<?php echo intval( $idx ); ?>][travellerType]" value="<?php echo esc_attr( $pkg['travellerType'] ?? '' ); ?>">
								</div>
								<div class="cms-field cms-checkbox-field">
									<label>
										<input type="checkbox" name="packages[<?php echo intval( $idx ); ?>][is_featured]" value="1" <?php checked( $is_featured ); ?>>
										Featured on Homepage
									</label>
								</div>
							</div>

							<div class="cms-grid-2">
								<div class="cms-field">
									<label>Tagline</label>
									<input type="text" name="packages[<?php echo intval( $idx ); ?>][tagline]" value="<?php echo esc_attr( $pkg['tagline'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Filter Categories (Allowed: <?php echo esc_html( implode( ', ', $valid_cats ) ); ?>)</label>
									<input type="text" name="packages[<?php echo intval( $idx ); ?>][categories_csv]" value="<?php echo esc_attr( implode( ', ', $pkg['categories'] ?? [] ) ); ?>">
								</div>
								<div class="cms-field">
									<label>Short Card Summary</label>
									<textarea name="packages[<?php echo intval( $idx ); ?>][description]" rows="2"><?php echo esc_textarea( $pkg['description'] ?? '' ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Why We Recommend</label>
									<textarea name="packages[<?php echo intval( $idx ); ?>][whyWeRecommend]" rows="2"><?php echo esc_textarea( $pkg['whyWeRecommend'] ?? '' ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Story Introduction</label>
									<textarea name="packages[<?php echo intval( $idx ); ?>][storyIntroduction]" rows="3"><?php echo esc_textarea( $pkg['storyIntroduction'] ?? '' ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Why We Chose These Stays</label>
									<textarea name="packages[<?php echo intval( $idx ); ?>][whyWeChoseStay]" rows="3"><?php echo esc_textarea( $pkg['whyWeChoseStay'] ?? '' ); ?></textarea>
								</div>
							</div>

							<div class="cms-grid-3">
								<div class="cms-field">
									<label>Highlights (One per line)</label>
									<textarea name="packages[<?php echo intval( $idx ); ?>][highlights_raw]" rows="4"><?php echo esc_textarea( implode( "\n", $pkg['highlights'] ?? [] ) ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Included (One per line)</label>
									<textarea name="packages[<?php echo intval( $idx ); ?>][included_raw]" rows="4"><?php echo esc_textarea( implode( "\n", $pkg['included'] ?? [] ) ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Not Included (One per line)</label>
									<textarea name="packages[<?php echo intval( $idx ); ?>][notIncluded_raw]" rows="4"><?php echo esc_textarea( implode( "\n", $pkg['notIncluded'] ?? [] ) ); ?></textarea>
								</div>
							</div>

							<!-- Highlights Meta -->
							<h4 style="margin:14px 0 8px;">Package Quick Facts (<code>highlightsMeta</code>)</h4>
							<div class="cms-grid-4">
								<?php
								$hm_fields = [
									'accommodation' => 'Accommodation Style',
									'transfers'     => 'Transfers',
									'meals'         => 'Meals',
									'countries'     => 'Countries Visited',
									'bestFor'       => 'Best For',
									'difficulty'    => 'Pace / Difficulty',
									'season'        => 'Best Season',
								];
								foreach ( $hm_fields as $hmk => $hml ) :
									?>
									<div class="cms-field">
										<label><?php echo esc_html( $hml ); ?></label>
										<input type="text" name="packages[<?php echo intval( $idx ); ?>][highlightsMeta][<?php echo esc_attr( $hmk ); ?>]" value="<?php echo esc_attr( $h_meta[ $hmk ] ?? '' ); ?>">
									</div>
								<?php endforeach; ?>
							</div>

							<div class="cms-grid-2">
								<div class="cms-field">
									<label>Primary Package Cover Image</label>
									<div class="cms-media-picker">
										<div class="cms-media-preview">
											<?php if ( ! empty( $pkg['imageUrl'] ) ) : ?>
												<img src="<?php echo esc_url( $pkg['imageUrl'] ); ?>" alt="">
											<?php endif; ?>
										</div>
										<div class="cms-media-controls">
											<input type="text" name="packages[<?php echo intval( $idx ); ?>][imageUrl]" value="<?php echo esc_attr( $pkg['imageUrl'] ?? '' ); ?>" class="cms-media-url">
											<button type="button" class="button cms-pick-media">Select / Upload</button>
										</div>
									</div>
								</div>
								<div class="cms-field">
									<label>Included Experience IDs (Comma-separated) &amp; Related Package IDs</label>
									<input type="text" name="packages[<?php echo intval( $idx ); ?>][includedExperienceIds_csv]" value="<?php echo esc_attr( implode( ', ', $pkg['includedExperienceIds'] ?? [] ) ); ?>" placeholder="Included Experience IDs">
									<input type="text" name="packages[<?php echo intval( $idx ); ?>][relatedPackageIds_csv]" value="<?php echo esc_attr( implode( ', ', $pkg['relatedPackageIds'] ?? [] ) ); ?>" placeholder="Related Package IDs" style="margin-top:6px;">
								</div>
							</div>

							<!-- Interactive Multi-Photo Package Gallery Manager -->
							<div class="cms-field" style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:10px;padding:14px;margin-top:10px;">
								<div class="cms-flex-between" style="margin-bottom:10px;">
									<label style="margin:0;font-weight:700;">Package Photo Gallery (<?php echo count( $gallery ); ?> photos) — Add, Upload, Replace, Reorder &amp; Remove</label>
									<button type="button" class="button button-small cms-add-string-gallery-photo" data-input-name="packages[<?php echo intval( $idx ); ?>][galleryImages][]">
										<span class="dashicons dashicons-plus-alt2"></span> Add / Upload Gallery Photos
									</button>
								</div>
								<div class="cms-string-gallery-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:10px;">
									<?php foreach ( $gallery as $g_url ) : ?>
										<div class="cms-string-gallery-item" style="background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:8px;">
											<img src="<?php echo esc_url( $g_url ); ?>" alt="" style="width:100%;height:105px;object-fit:cover;border-radius:6px;display:block;margin-bottom:6px;">
											<input type="text" name="packages[<?php echo intval( $idx ); ?>][galleryImages][]" value="<?php echo esc_attr( $g_url ); ?>" class="cms-media-url" style="width:100%;font-size:11px;margin-bottom:6px;">
											<div style="display:flex;justify-content:space-between;gap:4px;">
												<button type="button" class="button button-small cms-pick-single-gallery-url">Replace</button>
												<button type="button" class="button button-small cms-move-up" title="Move Left">←</button>
												<button type="button" class="button button-small cms-move-down" title="Move Right">→</button>
												<button type="button" class="button-link-delete cms-remove-gallery-url">✕</button>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
							</div>

							<div class="cms-grid-3" style="margin-top:12px;">
								<div class="cms-field">
									<label>Detailed Itinerary (<code>detailedItinerary</code> JSON)</label>
									<textarea name="packages[<?php echo intval( $idx ); ?>][detailedItinerary_json]" rows="4" style="font-family:monospace;font-size:11px;"><?php echo esc_textarea( wp_json_encode( $pkg['detailedItinerary'] ?? [], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Recommended Hotels (<code>recommendedHotels</code> JSON)</label>
									<textarea name="packages[<?php echo intval( $idx ); ?>][recommendedHotels_json]" rows="4" style="font-family:monospace;font-size:11px;"><?php echo esc_textarea( wp_json_encode( $pkg['recommendedHotels'] ?? [], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Package FAQs (<code>faqs</code> JSON)</label>
									<textarea name="packages[<?php echo intval( $idx ); ?>][faqs_json]" rows="4" style="font-family:monospace;font-size:11px;"><?php echo esc_textarea( wp_json_encode( $pkg['faqs'] ?? [], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></textarea>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>5B. Packages Directory Page Settings (<code>/victoria-falls-packages</code>)</h2>
					<p>Edit the Packages Directory hero photo, headings, and labels.</p>
				</div>
			</div>
			<div class="cms-grid-3">
				<?php
				Outbound_CMS_Studio_Sections::render_structure_image( $structures, 'travel/PackagesDirectoryPage.fallsTour1', 'Packages Directory Hero Image' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/PackagesDirectoryPage.text2', 'Directory Hero Badge' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/PackagesDirectoryPage.text3', 'Directory Hero Heading' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/PackagesDirectoryPage.text4', 'Directory Hero Subtitle', true, 2 );
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * =========================================================================
	 * SECTION 6: GUIDES & ARTICLES
	 * =========================================================================
	 */
	public static function render_tab_guides( array $snapshot ): void {
		$guides     = $snapshot['guides'] ?? [];
		$hub_cats   = $snapshot['site']['guideCategories'] ?? [];
		$strings    = $snapshot['site']['editorial']['strings'] ?? [];
		$structures = $snapshot['site']['editorial']['structures'] ?? [];
		?>
		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>6A. Editorial Travel Guides &amp; Articles (<?php echo count( $guides ); ?>)</h2>
					<p>Manage long-form Victoria Falls travel guides, quick facts, chapters, content blocks, author attribution, and article SEO.</p>
				</div>
				<div style="display:flex;gap:10px;align-items:center;">
					<input type="search" class="cms-record-search" data-target="#cms-guides-list > .cms-accordion-item" placeholder="Search guides..." style="padding:7px 12px;border-radius:8px;border:1px solid #cbd5e1;">
				</div>
			</div>

			<div id="cms-guides-list" class="cms-accordion-list">
				<?php foreach ( $guides as $idx => $gde ) :
					$author = $gde['author'] ?? [];
					$seo    = $gde['seo'] ?? [];
					?>
					<div class="cms-accordion-item <?php echo 0 === $idx ? 'is-open' : ''; ?>" data-search="<?php echo esc_attr( strtolower( ( $gde['title'] ?? '' ) . ' ' . ( $gde['slug'] ?? '' ) . ' ' . ( $gde['category'] ?? '' ) ) ); ?>">
						<div class="cms-accordion-header">
							<div class="cms-acc-title-wrap">
								<?php if ( ! empty( $gde['heroImageUrl'] ) ) : ?>
									<img src="<?php echo esc_url( $gde['heroImageUrl'] ); ?>" class="cms-acc-thumb" alt="">
								<?php endif; ?>
								<div class="cms-acc-meta">
									<strong><?php echo esc_html( $gde['title'] ?? 'Untitled Guide' ); ?></strong>
									<span><?php echo esc_html( ( $gde['category'] ?? '' ) . ' • ' . ( $gde['readingTime'] ?? '' ) . ' • ' . count( $gde['sections'] ?? [] ) . ' chapters' ); ?></span>
								</div>
							</div>
							<div class="cms-acc-actions">
								<button type="button" class="button button-small cms-move-up" title="Move Up">↑</button>
								<button type="button" class="button button-small cms-move-down" title="Move Down">↓</button>
								<span class="dashicons dashicons-arrow-down-alt2 cms-acc-chevron"></span>
							</div>
						</div>

						<div class="cms-accordion-body">
							<input type="hidden" name="guides[<?php echo intval( $idx ); ?>][id]" value="<?php echo esc_attr( $gde['id'] ?? 'guide-' . ( $idx + 1 ) ); ?>">

							<div class="cms-grid-4">
								<div class="cms-field">
									<label>Article Title</label>
									<input type="text" name="guides[<?php echo intval( $idx ); ?>][title]" value="<?php echo esc_attr( $gde['title'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>URL Slug</label>
									<input type="text" name="guides[<?php echo intval( $idx ); ?>][slug]" value="<?php echo esc_attr( $gde['slug'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Category</label>
									<input type="text" name="guides[<?php echo intval( $idx ); ?>][category]" value="<?php echo esc_attr( $gde['category'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Reading Time</label>
									<input type="text" name="guides[<?php echo intval( $idx ); ?>][readingTime]" value="<?php echo esc_attr( $gde['readingTime'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Published Date</label>
									<input type="text" name="guides[<?php echo intval( $idx ); ?>][publishedDate]" value="<?php echo esc_attr( $gde['publishedDate'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Last Updated Date</label>
									<input type="text" name="guides[<?php echo intval( $idx ); ?>][lastUpdatedDate]" value="<?php echo esc_attr( $gde['lastUpdatedDate'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Author Name</label>
									<input type="text" name="guides[<?php echo intval( $idx ); ?>][author][name]" value="<?php echo esc_attr( $author['name'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>Author Role</label>
									<input type="text" name="guides[<?php echo intval( $idx ); ?>][author][role]" value="<?php echo esc_attr( $author['role'] ?? '' ); ?>">
								</div>
							</div>

							<div class="cms-field">
								<label>Article Subtitle / Excerpt</label>
								<textarea name="guides[<?php echo intval( $idx ); ?>][subtitle]" rows="2"><?php echo esc_textarea( $gde['subtitle'] ?? '' ); ?></textarea>
							</div>

							<div class="cms-grid-2">
								<div class="cms-field">
									<label>Hero Image</label>
									<div class="cms-media-picker">
										<div class="cms-media-preview">
											<?php if ( ! empty( $gde['heroImageUrl'] ) ) : ?>
												<img src="<?php echo esc_url( $gde['heroImageUrl'] ); ?>" alt="">
											<?php endif; ?>
										</div>
										<div class="cms-media-controls">
											<input type="text" name="guides[<?php echo intval( $idx ); ?>][heroImageUrl]" value="<?php echo esc_attr( $gde['heroImageUrl'] ?? '' ); ?>" class="cms-media-url">
											<button type="button" class="button cms-pick-media">Select / Upload</button>
										</div>
									</div>
								</div>
								<div class="cms-field">
									<label>Hero Image Alt Text &amp; Author Avatar URL</label>
									<input type="text" name="guides[<?php echo intval( $idx ); ?>][heroImageAlt]" value="<?php echo esc_attr( $gde['heroImageAlt'] ?? '' ); ?>" placeholder="Hero Alt Text">
									<input type="text" name="guides[<?php echo intval( $idx ); ?>][author][avatarUrl]" value="<?php echo esc_attr( $author['avatarUrl'] ?? '' ); ?>" placeholder="Author Avatar URL" style="margin-top:6px;">
								</div>
							</div>

							<div class="cms-grid-2">
								<div class="cms-field">
									<label>SEO Meta Title</label>
									<input type="text" name="guides[<?php echo intval( $idx ); ?>][seo][metaTitle]" value="<?php echo esc_attr( $seo['metaTitle'] ?? '' ); ?>">
								</div>
								<div class="cms-field">
									<label>SEO Meta Description</label>
									<input type="text" name="guides[<?php echo intval( $idx ); ?>][seo][metaDescription]" value="<?php echo esc_attr( $seo['metaDescription'] ?? '' ); ?>">
								</div>
							</div>

							<!-- Chapters Editor -->
							<?php if ( ! empty( $gde['sections'] ) ) : ?>
								<h4 style="margin:16px 0 8px;">Guide Chapters (<?php echo count( $gde['sections'] ); ?>)</h4>
								<div class="cms-grid-2">
									<?php foreach ( $gde['sections'] as $s_idx => $sec ) : ?>
										<div class="cms-subcard" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px;">
											<div class="cms-grid-2">
												<div class="cms-field">
													<label>TOC Title</label>
													<input type="text" name="guides[<?php echo intval( $idx ); ?>][sections][<?php echo intval( $s_idx ); ?>][tocTitle]" value="<?php echo esc_attr( $sec['tocTitle'] ?? '' ); ?>">
												</div>
												<div class="cms-field">
													<label>Chapter Heading</label>
													<input type="text" name="guides[<?php echo intval( $idx ); ?>][sections][<?php echo intval( $s_idx ); ?>][heading]" value="<?php echo esc_attr( $sec['heading'] ?? '' ); ?>">
												</div>
											</div>
											<?php
											foreach ( ( $sec['blocks'] ?? [] ) as $b_idx => $blk ) :
												if ( ( $blk['type'] ?? '' ) === 'text' && isset( $blk['content'] ) ) :
													?>
													<div class="cms-field" style="margin-top:6px;">
														<label>Paragraph Block #<?php echo intval( $b_idx + 1 ); ?></label>
														<textarea name="guides[<?php echo intval( $idx ); ?>][sections][<?php echo intval( $s_idx ); ?>][blocks][<?php echo intval( $b_idx ); ?>][content]" rows="2"><?php echo esc_textarea( $blk['content'] ); ?></textarea>
													</div>
													<?php
												endif;
											endforeach;
											?>
										</div>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>

							<div class="cms-grid-2" style="margin-top:12px;">
								<div class="cms-field">
									<label>Quick Facts (<code>quickFacts</code> JSON)</label>
									<textarea name="guides[<?php echo intval( $idx ); ?>][quickFacts_json]" rows="3" style="font-family:monospace;font-size:11px;"><?php echo esc_textarea( wp_json_encode( $gde['quickFacts'] ?? [], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></textarea>
								</div>
								<div class="cms-field">
									<label>Guide FAQs (<code>faqs</code> JSON)</label>
									<textarea name="guides[<?php echo intval( $idx ); ?>][faqs_json]" rows="3" style="font-family:monospace;font-size:11px;"><?php echo esc_textarea( wp_json_encode( $gde['faqs'] ?? [], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></textarea>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>6B. Guide Hub Categories &amp; Header Settings (<code>GuideHubView.tsx</code>)</h2>
					<p>Manage the Guide Hub categories (<code>site.guideCategories</code>) and specialist positioning banner.</p>
				</div>
			</div>
			<div class="cms-grid-3">
				<?php
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/guide/GuideHubView.text2', 'Guide Hub Eyebrow Badge' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/guide/GuideHubView.text3', 'Guide Hub Main Title' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/guide/GuideHubView.text4', 'Guide Hub Subtitle', true, 2 );
				?>
			</div>
			<div class="cms-field" style="margin-top:12px;">
				<label>Guide Hub Category Groups (<code>site.guideCategories</code> JSON)</label>
				<textarea name="guide_categories_json" rows="5" style="font-family:monospace;font-size:11px;"><?php echo esc_textarea( wp_json_encode( $hub_cats, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></textarea>
			</div>
		</div>
		<?php
	}

	/**
	 * =========================================================================
	 * SECTION 7: GALLERIES & MEDIA (Special Requirement 7)
	 * =========================================================================
	 */
	public static function render_tab_galleries( array $snapshot ): void {
		$album           = $snapshot['albums'][0] ?? [ 'slug' => 'client-memories', 'title' => 'Client Memories', 'featured' => true, 'images' => [] ];
		$images          = $album['images'] ?? [];
		$strings         = $snapshot['site']['editorial']['strings'] ?? [];
		$structures      = $snapshot['site']['editorial']['structures'] ?? [];
		$fungai_memories = $structures['travel/AboutPage.fungaiMemories'] ?? [];
		$boma_gallery    = $structures['travel/BomaExperiencePage.section3'] ?? [];
		$bungee_gallery  = $structures['travel/BungeeExperiencePage.section5'] ?? [];
		?>
		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>7A. Client Memories Gallery (<?php echo count( $images ); ?> Photographs)</h2>
					<p>Full gallery management for <code>/client-gallery</code> and the Homepage Client Gallery preview: upload via WordPress Media Library, replace, remove, reorder, edit captions &amp; alt text, select featured cover image, and toggle album visibility.</p>
				</div>
				<div style="display:flex;gap:10px;align-items:center;">
					<button type="button" class="button button-primary" id="cms-add-gallery-photo-btn">
						<span class="dashicons dashicons-plus-alt2"></span> Add / Upload Photographs
					</button>
				</div>
			</div>

			<div class="cms-grid-3" style="margin-bottom:18px;background:#f8fafc;border:1px solid #cbd5e1;border-radius:10px;padding:14px;">
				<div class="cms-field">
					<label>Album Title</label>
					<input type="text" name="album_meta[title]" value="<?php echo esc_attr( $album['title'] ?? 'Client Memories' ); ?>">
				</div>
				<div class="cms-field">
					<label>Album Slug / Category ID</label>
					<input type="text" name="album_meta[slug]" value="<?php echo esc_attr( $album['slug'] ?? 'client-memories' ); ?>">
				</div>
				<div class="cms-field cms-checkbox-field" style="display:flex;align-items:center;padding-top:18px;">
					<label style="font-weight:700;cursor:pointer;">
						<input type="checkbox" name="album_meta[featured]" value="1" <?php checked( ! isset( $album['featured'] ) || ! empty( $album['featured'] ) ); ?>>
						Album Visible on Frontend (Featured Gallery)
					</label>
				</div>
			</div>

			<div id="cms-gallery-grid" class="cms-gallery-grid">
				<?php foreach ( $images as $idx => $img ) : ?>
					<div class="cms-gallery-card">
						<div class="cms-gallery-thumb" style="position:relative;">
							<img src="<?php echo esc_url( $img['url'] ?? '' ); ?>" alt="<?php echo esc_attr( $img['alt'] ?? '' ); ?>">
							<?php if ( 0 === $idx ) : ?>
								<span style="position:absolute;top:8px;left:8px;background:#e67e22;color:#fff;font-size:10px;font-weight:700;padding:2px 8px;border-radius:999px;">★ Featured #1</span>
							<?php endif; ?>
						</div>
						<div class="cms-gallery-fields">
							<input type="hidden" name="gallery[<?php echo intval( $idx ); ?>][id]" value="<?php echo esc_attr( $img['id'] ?? 'photo-' . ( $idx + 1 ) ); ?>">
							<div class="cms-field">
								<label>Image URL</label>
								<input type="text" name="gallery[<?php echo intval( $idx ); ?>][url]" value="<?php echo esc_attr( $img['url'] ?? '' ); ?>" class="cms-media-url">
							</div>
							<div class="cms-field">
								<label>Alt Text (SEO &amp; Screen Readers)</label>
								<input type="text" name="gallery[<?php echo intval( $idx ); ?>][alt]" value="<?php echo esc_attr( $img['alt'] ?? '' ); ?>">
							</div>
							<div class="cms-field">
								<label>Caption (Displayed in Lightbox &amp; Cards)</label>
								<input type="text" name="gallery[<?php echo intval( $idx ); ?>][caption]" value="<?php echo esc_attr( $img['caption'] ?? '' ); ?>">
							</div>
							<div class="cms-gallery-card-actions" style="display:flex;justify-content:space-between;align-items:center;gap:4px;">
								<button type="button" class="button button-small cms-pick-gallery-img">Replace</button>
								<div style="display:flex;gap:3px;">
									<button type="button" class="button button-small cms-make-featured-photo" title="Make Featured (#1)">★</button>
									<button type="button" class="button button-small cms-move-up" title="Move Earlier">←</button>
									<button type="button" class="button button-small cms-move-down" title="Move Later">→</button>
								</div>
								<button type="button" class="button-link-delete cms-remove-gallery-img">Remove</button>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header cms-flex-between">
				<div>
					<h2>7B. About Page — Fungai &amp; Guest Memories Gallery (<?php echo count( $fungai_memories ); ?> Photos)</h2>
					<p>Manage the photo collection displayed on the About Us page (<code>travel/AboutPage.fungaiMemories</code>).</p>
				</div>
				<button type="button" class="button button-secondary" id="cms-add-fungai-photo-btn">
					<span class="dashicons dashicons-plus-alt2"></span> Add About Gallery Photo
				</button>
			</div>
			<div id="cms-fungai-gallery-grid" class="cms-gallery-grid">
				<?php foreach ( $fungai_memories as $idx => $fm ) : ?>
					<div class="cms-gallery-card">
						<div class="cms-gallery-thumb">
							<img src="<?php echo esc_url( $fm['src'] ?? '' ); ?>" alt="<?php echo esc_attr( $fm['alt'] ?? '' ); ?>">
						</div>
						<div class="cms-gallery-fields">
							<div class="cms-field">
								<label>Image URL</label>
								<input type="text" name="fungai_memories[<?php echo intval( $idx ); ?>][src]" value="<?php echo esc_attr( $fm['src'] ?? '' ); ?>" class="cms-media-url">
							</div>
							<div class="cms-field">
								<label>Alt Text / Caption</label>
								<input type="text" name="fungai_memories[<?php echo intval( $idx ); ?>][alt]" value="<?php echo esc_attr( $fm['alt'] ?? '' ); ?>">
							</div>
							<div class="cms-gallery-card-actions" style="display:flex;justify-content:space-between;align-items:center;">
								<button type="button" class="button button-small cms-pick-gallery-img">Replace</button>
								<div>
									<button type="button" class="button button-small cms-move-up">←</button>
									<button type="button" class="button button-small cms-move-down">→</button>
								</div>
								<button type="button" class="button-link-delete cms-remove-gallery-img">Remove</button>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cms-section-card">
			<div class="cms-section-header">
				<div>
					<h2>7C. Boma Dinner Gallery, Bungee Gallery &amp; Client Gallery Page Copy</h2>
					<p>Manage the photo collections on the Boma &amp; Bungee pages and headings on <code>/client-gallery</code>.</p>
				</div>
			</div>
			<div class="cms-grid-2">
				<div class="cms-field">
					<div class="cms-flex-between" style="margin-bottom:8px;">
						<label style="font-weight:700;">The Boma Dinner Gallery Photos (<?php echo count( $boma_gallery ); ?>)</label>
						<button type="button" class="button button-small cms-add-string-gallery-photo" data-input-name="boma_gallery[]">+ Add Photo</button>
					</div>
					<div class="cms-string-gallery-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;">
						<?php foreach ( $boma_gallery as $b_url ) : ?>
							<div class="cms-string-gallery-item" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:6px;">
								<img src="<?php echo esc_url( $b_url ); ?>" alt="" style="width:100%;height:85px;object-fit:cover;border-radius:5px;display:block;margin-bottom:5px;">
								<input type="text" name="boma_gallery[]" value="<?php echo esc_attr( $b_url ); ?>" class="cms-media-url" style="width:100%;font-size:10px;margin-bottom:5px;">
								<div style="display:flex;justify-content:space-between;">
									<button type="button" class="button button-small cms-pick-single-gallery-url">Replace</button>
									<button type="button" class="button button-small cms-move-up">←</button>
									<button type="button" class="button button-small cms-move-down">→</button>
									<button type="button" class="button-link-delete cms-remove-gallery-url">✕</button>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>

				<div class="cms-field">
					<div class="cms-flex-between" style="margin-bottom:8px;">
						<label style="font-weight:700;">Victoria Falls Bungee Gallery Photos (<?php echo count( $bungee_gallery ); ?>)</label>
						<button type="button" class="button button-small cms-add-string-gallery-photo" data-input-name="bungee_gallery[]">+ Add Photo</button>
					</div>
					<div class="cms-string-gallery-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;">
						<?php foreach ( $bungee_gallery as $bg_url ) : ?>
							<div class="cms-string-gallery-item" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:6px;">
								<img src="<?php echo esc_url( $bg_url ); ?>" alt="" style="width:100%;height:85px;object-fit:cover;border-radius:5px;display:block;margin-bottom:5px;">
								<input type="text" name="bungee_gallery[]" value="<?php echo esc_attr( $bg_url ); ?>" class="cms-media-url" style="width:100%;font-size:10px;margin-bottom:5px;">
								<div style="display:flex;justify-content:space-between;">
									<button type="button" class="button button-small cms-pick-single-gallery-url">Replace</button>
									<button type="button" class="button button-small cms-move-up">←</button>
									<button type="button" class="button button-small cms-move-down">→</button>
									<button type="button" class="button-link-delete cms-remove-gallery-url">✕</button>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>

			<div class="cms-grid-3" style="margin-top:16px;">
				<?php
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/ClientGallery.text6', 'Client Gallery Page Hero Badge' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/ClientGallery.text7', 'Client Gallery Page Main Heading' );
				Outbound_CMS_Studio_Sections::render_string_input( $strings, 'travel/ClientGallery.text8', 'Client Gallery Page Intro Paragraph', true, 2 );
				?>
			</div>
		</div>
		<?php
	}
}
endif;
